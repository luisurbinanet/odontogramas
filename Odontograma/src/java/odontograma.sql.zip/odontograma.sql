-- phpMyAdmin SQL Dump
-- version 2.10.2
-- http://www.phpmyadmin.net
-- 
-- Servidor: localhost
-- Tiempo de generación: 06-03-2012 a las 12:23:38
-- Versión del servidor: 5.0.45
-- Versión de PHP: 5.2.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Base de datos: `odontograma`
-- 

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `consulta`
-- 

CREATE TABLE `consulta` (
  `idMotivo` int(11) NOT NULL auto_increment,
  `motivo` varchar(45) default NULL,
  `Paciente_numId` int(11) NOT NULL,
  `Doctor_idDoctor` int(11) NOT NULL,
  PRIMARY KEY  (`idMotivo`),
  KEY `fk_Consulta_Paciente` (`Paciente_numId`),
  KEY `fk_Consulta_Doctor1` (`Doctor_idDoctor`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `consulta`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `doctor`
-- 

CREATE TABLE `doctor` (
  `idDoctor` int(11) NOT NULL,
  `usuario` varchar(45) default NULL,
  `nombre` varchar(45) default NULL,
  `password` varchar(45) default NULL,
  PRIMARY KEY  (`idDoctor`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Volcar la base de datos para la tabla `doctor`
-- 

INSERT INTO `doctor` VALUES (1143338386, 'Julio', 'Julio Cesar Barcos Espitaleta', '123456');

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `paciente`
-- 

CREATE TABLE `paciente` (
  `numId` int(11) NOT NULL,
  `nombre` varchar(45) default NULL,
  `direccion` varchar(45) default NULL,
  `numAfiliacion` varchar(45) default NULL,
  `telefono` varchar(45) default NULL,
  `ciudad` varchar(45) default NULL,
  `estadoCivil` varchar(45) default NULL,
  `edad` varchar(45) default NULL,
  `sexo` varchar(45) default NULL,
  `ocupacion` varchar(45) default NULL,
  PRIMARY KEY  (`numId`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Volcar la base de datos para la tabla `paciente`
-- 

