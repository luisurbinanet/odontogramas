-- phpMyAdmin SQL Dump
-- version 2.10.2
-- http://www.phpmyadmin.net
-- 
-- Servidor: localhost
-- Tiempo de generación: 19-05-2013 a las 18:21:57
-- Versión del servidor: 5.0.45
-- Versión de PHP: 5.2.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Base de datos: `odontogramas`
-- 

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `administrador`
-- 

CREATE TABLE `administrador` (
  `idAdmin` int(11) NOT NULL,
  `nombre` varchar(45) NOT NULL,
  `clave` varchar(45) NOT NULL,
  PRIMARY KEY  (`idAdmin`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Volcar la base de datos para la tabla `administrador`
-- 

INSERT INTO `administrador` VALUES (654321, 'Administrador', '123456');

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `comparacion`
-- 

CREATE TABLE `comparacion` (
  `diente1` varchar(250) NOT NULL,
  `diente2` varchar(250) default NULL,
  `comentario` varchar(1000) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Volcar la base de datos para la tabla `comparacion`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `consulta`
-- 

CREATE TABLE `consulta` (
  `iddatosConsulta` int(11) NOT NULL auto_increment,
  `motivoConsulta` varchar(1000) default NULL,
  `historiaActualEnfermedad` varchar(1000) default NULL,
  `observaciones` varchar(255) default NULL,
  `otros` varchar(255) default NULL,
  `ultimaVisitaOdon` date default NULL,
  `motivo` varchar(255) default NULL,
  `paciente_idpersona` varchar(45) NOT NULL,
  `fechaConsulta` date default NULL,
  `pronostico` varchar(45) default NULL,
  `medico_idmedico` int(11) NOT NULL,
  `docente_iddocente` varchar(45) default NULL,
  `antOdon` varchar(500) default NULL,
  `procedencia` varchar(200) default NULL,
  PRIMARY KEY  (`iddatosConsulta`),
  KEY `fk_datosConsulta_paciente1` (`paciente_idpersona`),
  KEY `fk_datosConsulta_medico1` (`medico_idmedico`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=23 ;

-- 
-- Volcar la base de datos para la tabla `consulta`
-- 

INSERT INTO `consulta` VALUES (21, 'xx3', 'xx3', 'xxx3', 'xx3', '2013-05-11', 'xx3', '1047565684', '2013-05-18', 'Regular', 123456, NULL, 'xx3', 'xx3');
INSERT INTO `consulta` VALUES (22, 'xx', 'xx', 'xx', 'xx', '2013-05-18', 'xx', '1047565684', '2013-05-19', 'Bueno', 123456, 'xx', 'xx', 'xx');

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `controltratamiento`
-- 

CREATE TABLE `controltratamiento` (
  `idcontroltratamiento` int(11) NOT NULL auto_increment,
  `fecha` varchar(45) default NULL,
  `historiaClinica_idhistoriaClinica` int(11) NOT NULL,
  PRIMARY KEY  (`idcontroltratamiento`),
  KEY `fk_controltratamiento_historiaClinica1_idx` (`historiaClinica_idhistoriaClinica`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=20 ;

-- 
-- Volcar la base de datos para la tabla `controltratamiento`
-- 

INSERT INTO `controltratamiento` VALUES (14, '2013-05-10', 6);
INSERT INTO `controltratamiento` VALUES (8, 'null', 5);
INSERT INTO `controltratamiento` VALUES (16, '2013-05-19', 6);
INSERT INTO `controltratamiento` VALUES (18, '2013-05-19', 6);
INSERT INTO `controltratamiento` VALUES (17, '2013-05-01', 6);
INSERT INTO `controltratamiento` VALUES (19, '2013-05-19', 7);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `controltratamiento_has_tratamiento`
-- 

CREATE TABLE `controltratamiento_has_tratamiento` (
  `controltratamiento_idcontroltratamiento` int(11) NOT NULL,
  `tratamiento_idtratamiento` int(11) NOT NULL,
  PRIMARY KEY  (`controltratamiento_idcontroltratamiento`,`tratamiento_idtratamiento`),
  KEY `fk_controltratamiento_has_tratamiento_tratamiento1_idx` (`tratamiento_idtratamiento`),
  KEY `fk_controltratamiento_has_tratamiento_controltratamiento1_idx` (`controltratamiento_idcontroltratamiento`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Volcar la base de datos para la tabla `controltratamiento_has_tratamiento`
-- 

INSERT INTO `controltratamiento_has_tratamiento` VALUES (7, 316);
INSERT INTO `controltratamiento_has_tratamiento` VALUES (7, 402);
INSERT INTO `controltratamiento_has_tratamiento` VALUES (9, 915);
INSERT INTO `controltratamiento_has_tratamiento` VALUES (10, 915);
INSERT INTO `controltratamiento_has_tratamiento` VALUES (11, 301);
INSERT INTO `controltratamiento_has_tratamiento` VALUES (12, 301);
INSERT INTO `controltratamiento_has_tratamiento` VALUES (13, 915);
INSERT INTO `controltratamiento_has_tratamiento` VALUES (14, 103);
INSERT INTO `controltratamiento_has_tratamiento` VALUES (15, 702);
INSERT INTO `controltratamiento_has_tratamiento` VALUES (16, 111);
INSERT INTO `controltratamiento_has_tratamiento` VALUES (16, 513);
INSERT INTO `controltratamiento_has_tratamiento` VALUES (17, 1002);
INSERT INTO `controltratamiento_has_tratamiento` VALUES (18, 513);
INSERT INTO `controltratamiento_has_tratamiento` VALUES (19, 201);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `curso`
-- 

CREATE TABLE `curso` (
  `idcurso` int(11) NOT NULL auto_increment,
  `nombre` varchar(255) default NULL,
  `codigo` varchar(45) default NULL,
  `estado` varchar(45) default NULL,
  `anio` varchar(45) default NULL,
  `periodo` varchar(45) default NULL,
  PRIMARY KEY  (`idcurso`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

-- 
-- Volcar la base de datos para la tabla `curso`
-- 

INSERT INTO `curso` VALUES (1, 'Endodoncia-I', '676767', 'activado', '2012', '02');

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `datosbasicos`
-- 

CREATE TABLE `datosbasicos` (
  `iddatosBasicos` int(11) NOT NULL auto_increment,
  `nombre` varchar(255) default NULL,
  PRIMARY KEY  (`iddatosBasicos`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=20 ;

-- 
-- Volcar la base de datos para la tabla `datosbasicos`
-- 

INSERT INTO `datosbasicos` VALUES (1, 'Tratamiento Medico ');
INSERT INTO `datosbasicos` VALUES (2, 'Ingestion Medicamentos ');
INSERT INTO `datosbasicos` VALUES (3, 'Reacciones Alergicas ');
INSERT INTO `datosbasicos` VALUES (4, 'Anestesia ');
INSERT INTO `datosbasicos` VALUES (5, 'Antibioticos ');
INSERT INTO `datosbasicos` VALUES (6, 'Hemorragias ');
INSERT INTO `datosbasicos` VALUES (7, 'Irradiaciones ');
INSERT INTO `datosbasicos` VALUES (8, 'Sinusitis ');
INSERT INTO `datosbasicos` VALUES (9, 'Enfermedades Respiratorias ');
INSERT INTO `datosbasicos` VALUES (10, 'Cardiopatias');
INSERT INTO `datosbasicos` VALUES (11, 'Diabetes ');
INSERT INTO `datosbasicos` VALUES (12, 'Fiebre Reumatica ');
INSERT INTO `datosbasicos` VALUES (13, 'Hepatitia ');
INSERT INTO `datosbasicos` VALUES (14, 'Hipertension ');
INSERT INTO `datosbasicos` VALUES (15, 'Embarazo ');
INSERT INTO `datosbasicos` VALUES (16, 'Enfermedades Renales ');
INSERT INTO `datosbasicos` VALUES (17, 'Enfermedades Gastroinstestinales ');
INSERT INTO `datosbasicos` VALUES (18, 'Organos de los Sentidos ');
INSERT INTO `datosbasicos` VALUES (19, 'Enfermedades Infectocontagiosas ');

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `datosconsulta_has_datosbasicos`
-- 

CREATE TABLE `datosconsulta_has_datosbasicos` (
  `datosConsulta_iddatosConsulta` int(11) NOT NULL,
  `datosBasicos_iddatosBasicos` int(11) NOT NULL,
  `valor` varchar(45) default NULL,
  `idConsulta_datosBasicos` int(11) NOT NULL auto_increment,
  PRIMARY KEY  (`idConsulta_datosBasicos`),
  KEY `fk_datosConsulta_has_datosBasicos_datosBasicos1` (`datosBasicos_iddatosBasicos`),
  KEY `fk_datosConsulta_has_datosBasicos_datosConsulta1` (`datosConsulta_iddatosConsulta`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=324 ;

-- 
-- Volcar la base de datos para la tabla `datosconsulta_has_datosbasicos`
-- 

INSERT INTO `datosconsulta_has_datosbasicos` VALUES (22, 19, 'no sabe', 323);
INSERT INTO `datosconsulta_has_datosbasicos` VALUES (22, 18, 'no sabe', 322);
INSERT INTO `datosconsulta_has_datosbasicos` VALUES (22, 17, 'no sabe', 321);
INSERT INTO `datosconsulta_has_datosbasicos` VALUES (22, 16, 'no sabe', 320);
INSERT INTO `datosconsulta_has_datosbasicos` VALUES (22, 15, 'no sabe', 319);
INSERT INTO `datosconsulta_has_datosbasicos` VALUES (22, 14, 'no sabe', 318);
INSERT INTO `datosconsulta_has_datosbasicos` VALUES (22, 13, 'no sabe', 317);
INSERT INTO `datosconsulta_has_datosbasicos` VALUES (22, 12, 'no sabe', 316);
INSERT INTO `datosconsulta_has_datosbasicos` VALUES (22, 11, 'no sabe', 315);
INSERT INTO `datosconsulta_has_datosbasicos` VALUES (22, 10, 'no sabe', 314);
INSERT INTO `datosconsulta_has_datosbasicos` VALUES (22, 9, 'no sabe', 313);
INSERT INTO `datosconsulta_has_datosbasicos` VALUES (22, 8, 'no sabe', 312);
INSERT INTO `datosconsulta_has_datosbasicos` VALUES (22, 7, 'no sabe', 311);
INSERT INTO `datosconsulta_has_datosbasicos` VALUES (22, 6, 'no sabe', 310);
INSERT INTO `datosconsulta_has_datosbasicos` VALUES (22, 5, 'no sabe', 309);
INSERT INTO `datosconsulta_has_datosbasicos` VALUES (22, 4, 'no sabe', 308);
INSERT INTO `datosconsulta_has_datosbasicos` VALUES (22, 3, 'no', 307);
INSERT INTO `datosconsulta_has_datosbasicos` VALUES (22, 2, 'no sabe', 306);
INSERT INTO `datosconsulta_has_datosbasicos` VALUES (22, 1, 'no sabe', 305);
INSERT INTO `datosconsulta_has_datosbasicos` VALUES (21, 19, 'no sabe', 304);
INSERT INTO `datosconsulta_has_datosbasicos` VALUES (21, 18, 'no sabe', 303);
INSERT INTO `datosconsulta_has_datosbasicos` VALUES (21, 17, 'no sabe', 302);
INSERT INTO `datosconsulta_has_datosbasicos` VALUES (21, 16, 'no sabe', 301);
INSERT INTO `datosconsulta_has_datosbasicos` VALUES (21, 15, 'no sabe', 300);
INSERT INTO `datosconsulta_has_datosbasicos` VALUES (21, 14, 'no sabe', 299);
INSERT INTO `datosconsulta_has_datosbasicos` VALUES (21, 13, 'no sabe', 298);
INSERT INTO `datosconsulta_has_datosbasicos` VALUES (21, 12, 'no sabe', 297);
INSERT INTO `datosconsulta_has_datosbasicos` VALUES (21, 11, 'no sabe', 296);
INSERT INTO `datosconsulta_has_datosbasicos` VALUES (21, 10, 'no sabe', 295);
INSERT INTO `datosconsulta_has_datosbasicos` VALUES (21, 9, 'no sabe', 294);
INSERT INTO `datosconsulta_has_datosbasicos` VALUES (21, 8, 'no sabe', 293);
INSERT INTO `datosconsulta_has_datosbasicos` VALUES (21, 7, 'no sabe', 292);
INSERT INTO `datosconsulta_has_datosbasicos` VALUES (21, 6, 'no sabe', 291);
INSERT INTO `datosconsulta_has_datosbasicos` VALUES (21, 5, 'no sabe', 290);
INSERT INTO `datosconsulta_has_datosbasicos` VALUES (21, 4, 'no sabe', 289);
INSERT INTO `datosconsulta_has_datosbasicos` VALUES (21, 3, 'no sabe', 288);
INSERT INTO `datosconsulta_has_datosbasicos` VALUES (21, 2, 'no sabe', 287);
INSERT INTO `datosconsulta_has_datosbasicos` VALUES (21, 1, 'si', 286);
INSERT INTO `datosconsulta_has_datosbasicos` VALUES (21, 19, 'no sabe', 285);
INSERT INTO `datosconsulta_has_datosbasicos` VALUES (21, 18, 'no sabe', 284);
INSERT INTO `datosconsulta_has_datosbasicos` VALUES (21, 17, 'no sabe', 283);
INSERT INTO `datosconsulta_has_datosbasicos` VALUES (21, 16, 'no sabe', 282);
INSERT INTO `datosconsulta_has_datosbasicos` VALUES (21, 15, 'no sabe', 281);
INSERT INTO `datosconsulta_has_datosbasicos` VALUES (21, 14, 'no sabe', 280);
INSERT INTO `datosconsulta_has_datosbasicos` VALUES (21, 13, 'no sabe', 279);
INSERT INTO `datosconsulta_has_datosbasicos` VALUES (21, 12, 'no sabe', 278);
INSERT INTO `datosconsulta_has_datosbasicos` VALUES (21, 11, 'no sabe', 277);
INSERT INTO `datosconsulta_has_datosbasicos` VALUES (21, 10, 'no sabe', 276);
INSERT INTO `datosconsulta_has_datosbasicos` VALUES (21, 9, 'no sabe', 275);
INSERT INTO `datosconsulta_has_datosbasicos` VALUES (21, 8, 'no sabe', 274);
INSERT INTO `datosconsulta_has_datosbasicos` VALUES (21, 7, 'no sabe', 273);
INSERT INTO `datosconsulta_has_datosbasicos` VALUES (21, 6, 'no sabe', 272);
INSERT INTO `datosconsulta_has_datosbasicos` VALUES (21, 5, 'no sabe', 271);
INSERT INTO `datosconsulta_has_datosbasicos` VALUES (21, 4, 'no sabe', 270);
INSERT INTO `datosconsulta_has_datosbasicos` VALUES (21, 3, 'no sabe', 269);
INSERT INTO `datosconsulta_has_datosbasicos` VALUES (21, 2, 'no sabe', 268);
INSERT INTO `datosconsulta_has_datosbasicos` VALUES (21, 1, 'si', 267);
INSERT INTO `datosconsulta_has_datosbasicos` VALUES (21, 19, 'si', 266);
INSERT INTO `datosconsulta_has_datosbasicos` VALUES (21, 18, 'no', 265);
INSERT INTO `datosconsulta_has_datosbasicos` VALUES (21, 17, 'no sabe', 264);
INSERT INTO `datosconsulta_has_datosbasicos` VALUES (21, 16, 'no sabe', 263);
INSERT INTO `datosconsulta_has_datosbasicos` VALUES (21, 15, 'no sabe', 262);
INSERT INTO `datosconsulta_has_datosbasicos` VALUES (21, 14, 'no sabe', 261);
INSERT INTO `datosconsulta_has_datosbasicos` VALUES (21, 13, 'no sabe', 260);
INSERT INTO `datosconsulta_has_datosbasicos` VALUES (21, 12, 'no sabe', 259);
INSERT INTO `datosconsulta_has_datosbasicos` VALUES (21, 11, 'no sabe', 258);
INSERT INTO `datosconsulta_has_datosbasicos` VALUES (21, 10, 'no sabe', 257);
INSERT INTO `datosconsulta_has_datosbasicos` VALUES (21, 9, 'no sabe', 256);
INSERT INTO `datosconsulta_has_datosbasicos` VALUES (21, 8, 'no sabe', 255);
INSERT INTO `datosconsulta_has_datosbasicos` VALUES (21, 7, 'no sabe', 254);
INSERT INTO `datosconsulta_has_datosbasicos` VALUES (21, 6, 'no sabe', 253);
INSERT INTO `datosconsulta_has_datosbasicos` VALUES (21, 5, 'no sabe', 252);
INSERT INTO `datosconsulta_has_datosbasicos` VALUES (21, 4, 'no sabe', 251);
INSERT INTO `datosconsulta_has_datosbasicos` VALUES (21, 3, 'no sabe', 250);
INSERT INTO `datosconsulta_has_datosbasicos` VALUES (21, 2, 'no sabe', 249);
INSERT INTO `datosconsulta_has_datosbasicos` VALUES (21, 1, 'no sabe', 248);
INSERT INTO `datosconsulta_has_datosbasicos` VALUES (19, 19, 'no sabe', 171);
INSERT INTO `datosconsulta_has_datosbasicos` VALUES (19, 18, 'no sabe', 170);
INSERT INTO `datosconsulta_has_datosbasicos` VALUES (19, 17, 'no sabe', 169);
INSERT INTO `datosconsulta_has_datosbasicos` VALUES (19, 16, 'no sabe', 168);
INSERT INTO `datosconsulta_has_datosbasicos` VALUES (19, 15, 'no sabe', 167);
INSERT INTO `datosconsulta_has_datosbasicos` VALUES (19, 14, 'no sabe', 166);
INSERT INTO `datosconsulta_has_datosbasicos` VALUES (19, 13, 'no sabe', 165);
INSERT INTO `datosconsulta_has_datosbasicos` VALUES (19, 12, 'no sabe', 164);
INSERT INTO `datosconsulta_has_datosbasicos` VALUES (19, 11, 'no sabe', 163);
INSERT INTO `datosconsulta_has_datosbasicos` VALUES (19, 10, 'no sabe', 162);
INSERT INTO `datosconsulta_has_datosbasicos` VALUES (19, 9, 'no sabe', 161);
INSERT INTO `datosconsulta_has_datosbasicos` VALUES (19, 8, 'no sabe', 160);
INSERT INTO `datosconsulta_has_datosbasicos` VALUES (19, 7, 'no sabe', 159);
INSERT INTO `datosconsulta_has_datosbasicos` VALUES (19, 6, 'no sabe', 158);
INSERT INTO `datosconsulta_has_datosbasicos` VALUES (19, 5, 'no sabe', 157);
INSERT INTO `datosconsulta_has_datosbasicos` VALUES (19, 4, 'no sabe', 156);
INSERT INTO `datosconsulta_has_datosbasicos` VALUES (19, 3, 'no sabe', 155);
INSERT INTO `datosconsulta_has_datosbasicos` VALUES (19, 2, 'no sabe', 154);
INSERT INTO `datosconsulta_has_datosbasicos` VALUES (19, 1, 'no sabe', 153);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `datosconsulta_has_diagnostico`
-- 

CREATE TABLE `datosconsulta_has_diagnostico` (
  `datosConsulta_iddatosConsulta` int(11) NOT NULL,
  `diagnostico_iddiagnostico` int(11) NOT NULL,
  PRIMARY KEY  (`datosConsulta_iddatosConsulta`,`diagnostico_iddiagnostico`),
  KEY `fk_datosConsulta_has_diagnostico_diagnostico1` (`diagnostico_iddiagnostico`),
  KEY `fk_datosConsulta_has_diagnostico_datosConsulta1` (`datosConsulta_iddatosConsulta`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Volcar la base de datos para la tabla `datosconsulta_has_diagnostico`
-- 

INSERT INTO `datosconsulta_has_diagnostico` VALUES (21, 227200);
INSERT INTO `datosconsulta_has_diagnostico` VALUES (22, 237503);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `datosconsulta_has_diente`
-- 

CREATE TABLE `datosconsulta_has_diente` (
  `Iddatosconsulta_has_diente` int(11) NOT NULL auto_increment,
  `datosConsulta_iddatosConsulta` int(11) NOT NULL,
  `diente_iddiente` int(11) NOT NULL,
  `cara` varchar(45) default NULL,
  `enfermedad` varchar(45) default NULL,
  `realizar` varchar(45) NOT NULL,
  PRIMARY KEY  (`Iddatosconsulta_has_diente`),
  KEY `fk_datosConsulta_has_diente_diente1` (`diente_iddiente`),
  KEY `fk_datosConsulta_has_diente_datosConsulta1` (`datosConsulta_iddatosConsulta`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1317 ;

-- 
-- Volcar la base de datos para la tabla `datosconsulta_has_diente`
-- 

INSERT INTO `datosconsulta_has_diente` VALUES (1316, 22, 64, 'Palatina', 'Ausente', 'Si');
INSERT INTO `datosconsulta_has_diente` VALUES (1315, 22, 64, 'Oclusal', 'Ausente', 'Si');
INSERT INTO `datosconsulta_has_diente` VALUES (1314, 22, 64, 'Distal', 'Ausente', 'Si');
INSERT INTO `datosconsulta_has_diente` VALUES (1313, 22, 64, 'Mesial', 'Ausente', 'Si');
INSERT INTO `datosconsulta_has_diente` VALUES (1312, 22, 64, 'Vestibular', 'Ausente', 'Si');
INSERT INTO `datosconsulta_has_diente` VALUES (1311, 22, 15, 'Palatina', 'Ausente', 'Si');
INSERT INTO `datosconsulta_has_diente` VALUES (1310, 22, 15, 'Oclusal', 'Ausente', 'Si');
INSERT INTO `datosconsulta_has_diente` VALUES (1309, 22, 15, 'Distal', 'Ausente', 'Si');
INSERT INTO `datosconsulta_has_diente` VALUES (1308, 22, 15, 'Mesial', 'Ausente', 'Si');
INSERT INTO `datosconsulta_has_diente` VALUES (1307, 22, 15, 'Vestibular', 'Ausente', 'Si');
INSERT INTO `datosconsulta_has_diente` VALUES (1306, 21, 64, 'Palatina', 'Ausente', 'No');
INSERT INTO `datosconsulta_has_diente` VALUES (1305, 21, 64, 'Oclusal', 'Ausente', 'No');
INSERT INTO `datosconsulta_has_diente` VALUES (1304, 21, 64, 'Distal', 'Ausente', 'No');
INSERT INTO `datosconsulta_has_diente` VALUES (1303, 21, 64, 'Mesial', 'Ausente', 'No');
INSERT INTO `datosconsulta_has_diente` VALUES (1302, 21, 64, 'Vestibular', 'Ausente', 'No');
INSERT INTO `datosconsulta_has_diente` VALUES (1301, 21, 16, 'Palatina', 'Corona completa', 'No');
INSERT INTO `datosconsulta_has_diente` VALUES (1300, 21, 16, 'Oclusal', 'Corona completa', 'No');
INSERT INTO `datosconsulta_has_diente` VALUES (1299, 21, 16, 'Distal', 'Corona completa', 'No');
INSERT INTO `datosconsulta_has_diente` VALUES (1298, 21, 16, 'Mesial', 'Corona completa', 'No');
INSERT INTO `datosconsulta_has_diente` VALUES (1296, 21, 16, 'Vestibular', 'Caries o recidiva', 'Si');
INSERT INTO `datosconsulta_has_diente` VALUES (1297, 21, 16, 'Vestibular', 'Corona completa', 'No');

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `datosconsulta_has_plantratamiento`
-- 

CREATE TABLE `datosconsulta_has_plantratamiento` (
  `datosConsulta_iddatosConsulta` int(11) NOT NULL,
  `planTratamiento_idplanTratamiento` int(11) NOT NULL,
  PRIMARY KEY  (`datosConsulta_iddatosConsulta`,`planTratamiento_idplanTratamiento`),
  KEY `fk_datosConsulta_has_planTratamiento_planTratamiento1` (`planTratamiento_idplanTratamiento`),
  KEY `fk_datosConsulta_has_planTratamiento_datosConsulta1` (`datosConsulta_iddatosConsulta`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Volcar la base de datos para la tabla `datosconsulta_has_plantratamiento`
-- 

INSERT INTO `datosconsulta_has_plantratamiento` VALUES (21, 1);
INSERT INTO `datosconsulta_has_plantratamiento` VALUES (22, 1);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `datosconsulta_has_tratamiento`
-- 

CREATE TABLE `datosconsulta_has_tratamiento` (
  `datosConsulta_iddatosConsulta` int(11) NOT NULL,
  `tratamiento_idtratamiento` int(11) NOT NULL,
  PRIMARY KEY  (`datosConsulta_iddatosConsulta`,`tratamiento_idtratamiento`),
  KEY `fk_datosConsulta_has_tratamiento_tratamiento1` (`tratamiento_idtratamiento`),
  KEY `fk_datosConsulta_has_tratamiento_datosConsulta1` (`datosConsulta_iddatosConsulta`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Volcar la base de datos para la tabla `datosconsulta_has_tratamiento`
-- 

INSERT INTO `datosconsulta_has_tratamiento` VALUES (21, 504);
INSERT INTO `datosconsulta_has_tratamiento` VALUES (22, 201);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `departamentos`
-- 

CREATE TABLE `departamentos` (
  `codigo` int(11) NOT NULL,
  `nombre` varchar(45) default NULL,
  PRIMARY KEY  (`codigo`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Volcar la base de datos para la tabla `departamentos`
-- 

INSERT INTO `departamentos` VALUES (5, 'Antioquia');
INSERT INTO `departamentos` VALUES (8, 'Atlántico');
INSERT INTO `departamentos` VALUES (13, 'Bolívar');
INSERT INTO `departamentos` VALUES (15, 'Boyacá');
INSERT INTO `departamentos` VALUES (17, 'Caldas');
INSERT INTO `departamentos` VALUES (18, 'Caquetá');
INSERT INTO `departamentos` VALUES (19, 'Cauca');
INSERT INTO `departamentos` VALUES (20, 'Cesar');
INSERT INTO `departamentos` VALUES (23, 'Córdoba');
INSERT INTO `departamentos` VALUES (25, 'Cundinamarca');
INSERT INTO `departamentos` VALUES (27, 'Chocó');
INSERT INTO `departamentos` VALUES (41, 'Huila');
INSERT INTO `departamentos` VALUES (44, 'La Guajira');
INSERT INTO `departamentos` VALUES (47, 'Magdalena');
INSERT INTO `departamentos` VALUES (50, 'Meta');
INSERT INTO `departamentos` VALUES (52, 'Nariño');
INSERT INTO `departamentos` VALUES (54, 'Norte de Santander');
INSERT INTO `departamentos` VALUES (63, 'Quindío');
INSERT INTO `departamentos` VALUES (66, 'Risaralda');
INSERT INTO `departamentos` VALUES (68, 'Santander');
INSERT INTO `departamentos` VALUES (70, 'Sucre');
INSERT INTO `departamentos` VALUES (73, 'Tolima');
INSERT INTO `departamentos` VALUES (76, 'Valle del Cauca');
INSERT INTO `departamentos` VALUES (81, 'Arauca');
INSERT INTO `departamentos` VALUES (85, 'Casanare');
INSERT INTO `departamentos` VALUES (86, 'Putumayo');
INSERT INTO `departamentos` VALUES (88, 'San Andrés');
INSERT INTO `departamentos` VALUES (91, 'Amazonas');
INSERT INTO `departamentos` VALUES (94, 'Guainía');
INSERT INTO `departamentos` VALUES (95, 'Guaviare');
INSERT INTO `departamentos` VALUES (97, 'Vaupés');
INSERT INTO `departamentos` VALUES (99, 'Vichada');

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `diagnostico`
-- 

CREATE TABLE `diagnostico` (
  `iddiagnostico` int(11) NOT NULL auto_increment,
  `codigo` varchar(45) default NULL,
  `diagnostico` varchar(255) default NULL,
  PRIMARY KEY  (`iddiagnostico`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=973401 ;

-- 
-- Volcar la base de datos para la tabla `diagnostico`
-- 

INSERT INTO `diagnostico` VALUES (227101, '227101', 'REPARACION DE FISTULA  OROANTRAL Y/U ORONASAL');
INSERT INTO `diagnostico` VALUES (227200, '227200', 'ELEVACION DEL PISO DEL SENO MAXILAR  ');
INSERT INTO `diagnostico` VALUES (230101, '230101', 'EXODONCIA DE DIENTES PERMANENTES UNIRRADICULARES.');
INSERT INTO `diagnostico` VALUES (230102, '230102', 'EXODONCIA DE DIENTES PERMANENTES MULTIRRADICULARES.');
INSERT INTO `diagnostico` VALUES (230201, '230201', 'EXODONCIA DE DIENTES TEMPORALES UNIRRADICULARES.');
INSERT INTO `diagnostico` VALUES (230202, '230202', 'EXODONCIA DE DIENTES TEMPORALES MULTIRRADICULARES.');
INSERT INTO `diagnostico` VALUES (231100, '231100', 'EXODONCIA QUIRURGICA UNIRRADICULAR  ');
INSERT INTO `diagnostico` VALUES (231200, '231200', 'EXODONCIA QUIRURGICA MULTIRRADICULAR.  ');
INSERT INTO `diagnostico` VALUES (231301, '231301', 'EXODONCIA DE DIENTE  INCLUIDO');
INSERT INTO `diagnostico` VALUES (231302, '231302', 'EXODONCIA DE INCLUIDOS EN POSICIÓN ECTÓPICA CON ABORDAJE INTRAORAL   (POR DIENTE)');
INSERT INTO `diagnostico` VALUES (231303, '231303', 'EXODONCIA DE INCLUIDOS EN POSICIÓN ECTÓPICA CON ABORDAJE EXTRAORAL(POR DIENTE)');
INSERT INTO `diagnostico` VALUES (231400, '231400', 'EXODONCIAS  MÚLTIPLES CON ALVEOLOPLASTIA POR CUADRANTE  ');
INSERT INTO `diagnostico` VALUES (231500, '231500', 'COLGAJO DESPLAZADO PARA ABORDAJE DE DIENTE RETENIDO (VENTANA QUIRURGICA)  ');
INSERT INTO `diagnostico` VALUES (232101, '232101', 'OBTURACIÓN DENTAL POR SUPERFICIE  CON  AMALGAMA');
INSERT INTO `diagnostico` VALUES (232102, '232102', 'OBTURACIÓN DENTAL POR SUPERFICIE CON  RESINA DE FOTOCURADO');
INSERT INTO `diagnostico` VALUES (232103, '232103', 'OBTURACIÓN DENTAL POR SUPERFICIE CON  IONÓMERO DE VIDRIO');
INSERT INTO `diagnostico` VALUES (232200, '232200', 'OBTURACION TEMPORAL POR DIENTE  ');
INSERT INTO `diagnostico` VALUES (232300, '232300', 'COLOCACIÓN DE PIN MILIMÉTRICO  ');
INSERT INTO `diagnostico` VALUES (232401, '232401', 'RECONSTRUCCIÓN DE ÁNGULO INCISAL CON RESINA DE FOTOCURADO');
INSERT INTO `diagnostico` VALUES (232402, '232402', 'RECONSTRUCCIÓN  TERCIO INCISAL CON RESINA DE FOTOCURADO');
INSERT INTO `diagnostico` VALUES (233100, '233100', 'RESTAURACION DE  DIENTES MEDIANTE INCRUSTACION METALICA  ');
INSERT INTO `diagnostico` VALUES (233200, '233200', 'RESTAURACION DE  DIENTES MEDIANTE INCRUSTACION NO  METALICA  ');
INSERT INTO `diagnostico` VALUES (234101, '234101', 'COLOCACION O APLICACIÓN DE CORONA EN ACERO INOXIDABLE ( PARA DIENTES TEMPORALES)');
INSERT INTO `diagnostico` VALUES (234102, '234102', 'COLOCACION O APLICACIÓN DE CORONA EN POLICARBOXILATO  (PARA DIENTES TEMPORALES)');
INSERT INTO `diagnostico` VALUES (234103, '234103', 'COLOCACION O APLICACIÓN DE CORONA EN FORMA PLÁSTICA');
INSERT INTO `diagnostico` VALUES (234104, '234104', 'COLOCACION O APLICACIÓN DE CORONA ACRÍLICA TERMOCURADA');
INSERT INTO `diagnostico` VALUES (236300, '236300', 'IMPLANTE DENTAL ALOPLASTICO (OSEOINTEGRACION)  ');
INSERT INTO `diagnostico` VALUES (237101, '237101', 'PULPOTOMÍA ');
INSERT INTO `diagnostico` VALUES (237102, '237102', 'PULPECTOMIA');
INSERT INTO `diagnostico` VALUES (237200, '237200', 'APEXIFICACIÓN O APEXOGENESIS  ');
INSERT INTO `diagnostico` VALUES (237301, '237301', 'TERAPIA DE CONDUCTO RADICULAR EN DIENTES UNIRRADICULARES PERMANENTES');
INSERT INTO `diagnostico` VALUES (237302, '237302', 'TERAPIA DE CONDUCTO RADICULAR EN DIENTES BIRRADICULARES PERMANENTES');
INSERT INTO `diagnostico` VALUES (237303, '237303', 'TERAPIA DE CONDUCTO RADICULAR EN DIENTES MULTIRRADICULARES PERMANENTES');
INSERT INTO `diagnostico` VALUES (237304, '237304', 'TERAPIA DE CONDUCTO RADICULAR EN DIENTES TEMPORALES UNIRRADICULARES');
INSERT INTO `diagnostico` VALUES (237305, '237305', 'TERAPIA DE CONDUCTO RADICULAR EN DIENTES TEMPORALES MULTIRRADICULARES');
INSERT INTO `diagnostico` VALUES (237401, '237401', 'CURETAJE APICAL CON APICECTOMIA Y OBTURACION RETROGADA [CIRUGIA PERIRRADICULAR]');
INSERT INTO `diagnostico` VALUES (237501, '237501', 'PROCEDIMIENTO CORRECTIVO EN RESORCION RADICULAR (INTERNA Y EXTERNA)');
INSERT INTO `diagnostico` VALUES (237503, '237503', 'RECUBRIMIENTO PULPAR DIRECTO');
INSERT INTO `diagnostico` VALUES (237504, '237504', 'RECUBRIMIENTO PULPAR INDIRECTO');
INSERT INTO `diagnostico` VALUES (237505, '237505', 'PRUEBAS DE VITALIDAD PULPAR');
INSERT INTO `diagnostico` VALUES (237601, '237601', 'FISTULIZACION QUIRURGICA POR TREPANACION Y DRENAJE');
INSERT INTO `diagnostico` VALUES (237602, '237602', 'FISTULIZACION QUIRURGICA POR INCISION');
INSERT INTO `diagnostico` VALUES (237901, '237901', 'BLANQUEAMIENTO DENTAL [INTRINSECO] POR CAUSAS ENDODONTICAS (POR DIENTE)');
INSERT INTO `diagnostico` VALUES (240200, '240200', 'DETARTRAJE SUBGINGIVAL  (POR CUADRANTE)  ');
INSERT INTO `diagnostico` VALUES (240300, '240300', 'ALISADO RADICULAR CAMPO CERRADO ( POR SEXTANTE )  ');
INSERT INTO `diagnostico` VALUES (240500, '240500', 'ADAPTACION DE PLACA NEURO MIORELAJANTE  ');
INSERT INTO `diagnostico` VALUES (242201, '242201', 'CURETAJE A CAMPO ABIERTO POR SEXTANTE');
INSERT INTO `diagnostico` VALUES (242204, '242204', 'AUMENTO DE REBORDE PARCIALMENTE EDENTULO ( SIN MATERIAL)');
INSERT INTO `diagnostico` VALUES (242205, '242205', 'AUMENTO DE REBORDE PARCIALMENTE EDENTULO ( CON MATERIAL)');
INSERT INTO `diagnostico` VALUES (242300, '242300', 'PLASTIAS PREPROTESICAS ( AUMENTO DE CORONA CLINICA )  ');
INSERT INTO `diagnostico` VALUES (242400, '242400', 'REPARACION O PLASTIA PERIODONTAL REGENERATIVA ( INJERTOS - MEMBRANAS )  ');
INSERT INTO `diagnostico` VALUES (243101, '243101', 'EXTIRPACIÓN DE LESIÓN BENIGNA ENCAPSULADA EN ENCÍA HASTA DE TRES CENTÍMETROS');
INSERT INTO `diagnostico` VALUES (243400, '243400', 'GINGIVECTOMIA  ');
INSERT INTO `diagnostico` VALUES (244101, '244101', 'ENUCLEACIÓN DE QUISTE (ODONTOGÉNICO O NO ODONTOGÉNICO) HASTA DE  TRES CENTÍMETROS DE DIÁMETRO');
INSERT INTO `diagnostico` VALUES (244102, '244102', 'ENUCLEACIÓN DE QUISTE (ODONTOGÉNICO O NO ODONTOGÉNICO) DE MÁS DE TRES CENTÍMETROS DE DIÁMETRO');
INSERT INTO `diagnostico` VALUES (244103, '244103', 'RESECCIÓN DE TUMOR BENIGNO  O MALIGNO ODONTOGÉNICO');
INSERT INTO `diagnostico` VALUES (245100, '245100', 'REGULARIZACIÓN DE REBORDES POR CUADRANTE  ');
INSERT INTO `diagnostico` VALUES (245200, '245200', 'ALVEOLECTOMÍA (INTERRADICULAR - INTRASEPTAL - RADICAL - SIMPLE CON INJERTO O IMPLANTE) NCOC');
INSERT INTO `diagnostico` VALUES (247100, '247100', 'COLOCACIÓN DE APARATOLOGÍA  FIJA PARA ORTODONCIA (ARCADA)  ');
INSERT INTO `diagnostico` VALUES (247201, '247201', 'COLOCACIÓN DE APARATOLOGÍA REMOVIBLE INTRAORAL PARA  ORTODONCIA  (ARCADA)');
INSERT INTO `diagnostico` VALUES (247202, '247202', 'COLOCACIÓN DE APARATOLOGÍA REMOVIBLE  EXTRAORAL PARA  ORTODONCIA  (ARCADA)');
INSERT INTO `diagnostico` VALUES (247300, '247300', 'COLOCACION DE APARATOS DE RETENCION  ');
INSERT INTO `diagnostico` VALUES (247401, '247401', 'FERULIZACION RIGIDA ( SUPERIOR Y/O INFERIOR)');
INSERT INTO `diagnostico` VALUES (247402, '247402', 'FERULIZACION SEMIRIGIDA ( SUPERIOR Y/O INFERIOR)');
INSERT INTO `diagnostico` VALUES (248100, '248100', 'CIERRE DE DIASTEMA (ALVEOLAR; DENTAL)  ');
INSERT INTO `diagnostico` VALUES (248200, '248200', 'AJUSTAMIENTO OCLUSAL  ');
INSERT INTO `diagnostico` VALUES (248400, '248400', 'REPARACIÓN DE APARATOLOGIA FIJA O REMOVIBLE  ');
INSERT INTO `diagnostico` VALUES (248800, '248800', 'MASCARA FACIAL TERAPEUTICA NCOC');
INSERT INTO `diagnostico` VALUES (249101, '249101', 'CONTROL DE HEMORRAGIA DENTAL POS QUIRURGICA  ');
INSERT INTO `diagnostico` VALUES (250201, '250201', 'BIOPSIA EN CUÑA O POR TRUCUT DE LENGUA');
INSERT INTO `diagnostico` VALUES (251000, '251000', 'RESECCIÓN DE LESIÓN SUPERFICIAL EN LA LENGUA  ');
INSERT INTO `diagnostico` VALUES (255100, '255100', 'SUTURA DE LACERACIÓN DE LENGUA (GLOSORRAFIA)  ');
INSERT INTO `diagnostico` VALUES (261201, '261201', 'BIOPSIA ESCIONAL DE GLANDULA SALIVAR MENOR  (CON CONDUCTO SALIVAL)');
INSERT INTO `diagnostico` VALUES (262901, '262901', 'RESECCIÓN DE MUCOCELE DE GLANDULA SALIVAL');
INSERT INTO `diagnostico` VALUES (272301, '272301', 'BIOPSIA INCISIONAL DE LABIO');
INSERT INTO `diagnostico` VALUES (272302, '272302', 'BIOPSIA ESCISIONAL DE LABIO');
INSERT INTO `diagnostico` VALUES (274100, '274100', 'FRENILLECTOMIA LABIAL NCOC');
INSERT INTO `diagnostico` VALUES (274301, '274301', 'RESECCIÓN DE LESIÓN BENIGNA DE LA MUCOSA ORAL HASTA DE DOS CENTIMETROS DE DIÁMETRO');
INSERT INTO `diagnostico` VALUES (274302, '274302', 'RESECCIÓN DE LESIÓN BENIGNA DE LA MUCOSA ORAL MAYOR DE  DOS CENTIMETROS DE DIÁMETRO');
INSERT INTO `diagnostico` VALUES (274901, '274901', 'REMOCIÓN DE CUERPO EXTRAÑO EN TEJIDOS BLANDOS DE LA BOCA');
INSERT INTO `diagnostico` VALUES (274902, '274902', 'RESECCION  DE BRIDAS INTRAORALES');
INSERT INTO `diagnostico` VALUES (275101, '275101', 'SUTURA O REPARACIÓN DE HERIDA HASTA DE CINCO CENTÍMETROS EN  LABIOS');
INSERT INTO `diagnostico` VALUES (275102, '275102', 'SUTURA O REPARACIÓN DE HERIDA DE MÁS DE CINCO CENTÍMETROS EN  LABIOS');
INSERT INTO `diagnostico` VALUES (275801, '275801', 'PROFUNDIZACION O DESCENSO DE PISO DE BOCA CON DESINSERCION DE MILOHIODEO Y/O GENIHIODEO');
INSERT INTO `diagnostico` VALUES (275901, '275901', 'PROFUNDIZACION  DE SURCO VESTIBULAR CON INJERTO MUCOSO');
INSERT INTO `diagnostico` VALUES (767705, '767705', 'REDUCCION Y FIJACION DE LUXACION  DENTO ALVEOLAR QUE COMPROMETE HASTA TRES DIENTES');
INSERT INTO `diagnostico` VALUES (767706, '767706', 'REDUCCION Y FIJACION DE LUXACION DENTO ALVEOLAR QUE COMPROMETE MAS DE TRES DIENTES');
INSERT INTO `diagnostico` VALUES (893106, '893106', 'CONTROL DE ORTODONCIA FIJA/REMOVIBLE  O TRATAMIENTO ORTOPÉDICO FUNCIONAL  Y  MECÁNICO');
INSERT INTO `diagnostico` VALUES (893107, '893107', 'ELABORACIÓN Y ADAPTACIÓN DE APARATO ORTOPEDICO');
INSERT INTO `diagnostico` VALUES (893108, '893108', 'SESION DE CONTROL DE CRECIMIENTO Y DESARROLLO DENTO-MAXILOFACIAL');
INSERT INTO `diagnostico` VALUES (935500, '935500', 'APLICACIÓN DE ALAMBRE DENTAL  ');
INSERT INTO `diagnostico` VALUES (973400, '973400', 'EXTRACCION DE  APARATOLOGIA ORTODONTICA FIJA  ');

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `diente`
-- 

CREATE TABLE `diente` (
  `iddiente` int(11) NOT NULL,
  `nombre` varchar(45) default NULL,
  PRIMARY KEY  (`iddiente`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Volcar la base de datos para la tabla `diente`
-- 

INSERT INTO `diente` VALUES (11, '11');
INSERT INTO `diente` VALUES (12, '12');
INSERT INTO `diente` VALUES (13, '13');
INSERT INTO `diente` VALUES (14, '14');
INSERT INTO `diente` VALUES (15, '15');
INSERT INTO `diente` VALUES (16, '16');
INSERT INTO `diente` VALUES (17, '17');
INSERT INTO `diente` VALUES (18, '18');
INSERT INTO `diente` VALUES (21, '21');
INSERT INTO `diente` VALUES (22, '22');
INSERT INTO `diente` VALUES (23, '23');
INSERT INTO `diente` VALUES (24, '24');
INSERT INTO `diente` VALUES (25, '25');
INSERT INTO `diente` VALUES (26, '26');
INSERT INTO `diente` VALUES (27, '27');
INSERT INTO `diente` VALUES (28, '28');
INSERT INTO `diente` VALUES (31, '31');
INSERT INTO `diente` VALUES (32, '32');
INSERT INTO `diente` VALUES (33, '33');
INSERT INTO `diente` VALUES (34, '34');
INSERT INTO `diente` VALUES (35, '35');
INSERT INTO `diente` VALUES (36, '36');
INSERT INTO `diente` VALUES (37, '37');
INSERT INTO `diente` VALUES (38, '38');
INSERT INTO `diente` VALUES (41, '41');
INSERT INTO `diente` VALUES (42, '42');
INSERT INTO `diente` VALUES (43, '43');
INSERT INTO `diente` VALUES (44, '44');
INSERT INTO `diente` VALUES (45, '45');
INSERT INTO `diente` VALUES (46, '46');
INSERT INTO `diente` VALUES (47, '47');
INSERT INTO `diente` VALUES (48, '48');
INSERT INTO `diente` VALUES (51, '51');
INSERT INTO `diente` VALUES (52, '52');
INSERT INTO `diente` VALUES (53, '53');
INSERT INTO `diente` VALUES (54, '54');
INSERT INTO `diente` VALUES (55, '55');
INSERT INTO `diente` VALUES (61, '61');
INSERT INTO `diente` VALUES (62, '62');
INSERT INTO `diente` VALUES (63, '63');
INSERT INTO `diente` VALUES (64, '64');
INSERT INTO `diente` VALUES (65, '65');
INSERT INTO `diente` VALUES (71, '71');
INSERT INTO `diente` VALUES (72, '72');
INSERT INTO `diente` VALUES (73, '73');
INSERT INTO `diente` VALUES (74, '74');
INSERT INTO `diente` VALUES (75, '75');
INSERT INTO `diente` VALUES (81, '81');
INSERT INTO `diente` VALUES (82, '82');
INSERT INTO `diente` VALUES (83, '83');
INSERT INTO `diente` VALUES (84, '84');
INSERT INTO `diente` VALUES (85, '85');

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `docente`
-- 

CREATE TABLE `docente` (
  `iddocente` int(11) NOT NULL,
  `nombre` varchar(255) default NULL,
  `clave` varchar(45) default NULL,
  `codigo` varchar(45) default NULL,
  `estado` varchar(45) default NULL,
  PRIMARY KEY  (`iddocente`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Volcar la base de datos para la tabla `docente`
-- 

INSERT INTO `docente` VALUES (768695, 'docenM', '123456', 'xx', 'inactivo');
INSERT INTO `docente` VALUES (877847, 'docenteY', '123456', 'xx', 'activo');
INSERT INTO `docente` VALUES (7563234, 'DocenteX', '123456', 'xx', 'activo');
INSERT INTO `docente` VALUES (8656445, 'docenteB', '123456', 'wre', 'inactivo');
INSERT INTO `docente` VALUES (73245345, 'andres', '123456', 'xx2', 'inactivo');
INSERT INTO `docente` VALUES (76675665, 'docenteA', '123456', '1232344', 'activo');
INSERT INTO `docente` VALUES (756838423, '34435', '34543543', 'xx', 'activo');

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `docente_has_curso`
-- 

CREATE TABLE `docente_has_curso` (
  `docente_iddocente` int(11) NOT NULL,
  `curso_idcurso` int(11) NOT NULL,
  PRIMARY KEY  (`docente_iddocente`,`curso_idcurso`),
  KEY `fk_docente_has_curso_curso1` (`curso_idcurso`),
  KEY `fk_docente_has_curso_docente1` (`docente_iddocente`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Volcar la base de datos para la tabla `docente_has_curso`
-- 

INSERT INTO `docente_has_curso` VALUES (76675665, 1);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `docente_has_medico`
-- 

CREATE TABLE `docente_has_medico` (
  `docente_iddocente` int(11) NOT NULL,
  `medico_idmedico` int(11) NOT NULL,
  PRIMARY KEY  (`docente_iddocente`,`medico_idmedico`),
  KEY `fk_docente_has_medico_medico1` (`medico_idmedico`),
  KEY `fk_docente_has_medico_docente1` (`docente_iddocente`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Volcar la base de datos para la tabla `docente_has_medico`
-- 

INSERT INTO `docente_has_medico` VALUES (76675665, 123456);
INSERT INTO `docente_has_medico` VALUES (76675665, 6543554);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `evolucion`
-- 

CREATE TABLE `evolucion` (
  `idevolucion` int(11) NOT NULL auto_increment,
  `fecha` varchar(30) default NULL,
  `reciboPago` varchar(45) default NULL,
  `abono` int(11) default NULL,
  `saldo` varchar(45) default NULL,
  `idconsulta` int(11) NOT NULL,
  PRIMARY KEY  (`idevolucion`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10 ;

-- 
-- Volcar la base de datos para la tabla `evolucion`
-- 

INSERT INTO `evolucion` VALUES (7, '2013-05-19', '456', 500, '1', 21);
INSERT INTO `evolucion` VALUES (9, '2013-05-19', '1', 5000, '1', 22);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `evolucion_has_tratamiento`
-- 

CREATE TABLE `evolucion_has_tratamiento` (
  `idEvolucionX` int(11) NOT NULL,
  `idTratamientoX` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Volcar la base de datos para la tabla `evolucion_has_tratamiento`
-- 

INSERT INTO `evolucion_has_tratamiento` VALUES (9, 201);
INSERT INTO `evolucion_has_tratamiento` VALUES (7, 513);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `examenfisicoestomatologico`
-- 

CREATE TABLE `examenfisicoestomatologico` (
  `idexamenFisicoEstomatologico` int(11) NOT NULL auto_increment,
  `temperatura` varchar(45) default NULL,
  `pulso` varchar(45) default NULL,
  `tensionArterial` varchar(45) default NULL,
  `higieneOral` varchar(45) default NULL,
  `sedaDental` varchar(45) default NULL,
  `cepilloDentalUso` varchar(45) default NULL,
  `vecesAlDia` varchar(45) default NULL,
  `enjuagesBsinFluor` varchar(45) default NULL,
  `enjuagesBconFluor` varchar(45) default NULL,
  `habitosYvicios` varchar(45) default NULL,
  `datosConsulta_iddatosConsulta` int(11) NOT NULL,
  `frecuenciaRes` varchar(45) default NULL,
  `frecuenciaHabito` varchar(45) default NULL,
  `evolucionHabito` varchar(45) default NULL,
  `extraoral` varchar(500) default NULL,
  PRIMARY KEY  (`idexamenFisicoEstomatologico`),
  KEY `fk_examenFisicoEstomatologico_datosConsulta1` (`datosConsulta_iddatosConsulta`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10 ;

-- 
-- Volcar la base de datos para la tabla `examenfisicoestomatologico`
-- 

INSERT INTO `examenfisicoestomatologico` VALUES (8, '40', '40', '40', 'Buena', 'Si', 'Si', '4', 'Si', 'Si', 'Tabacos', 21, '5', '30 vez al dia', '3 años', 'un examen');
INSERT INTO `examenfisicoestomatologico` VALUES (9, '45', '45', '45', 'Buena', 'Si', 'Si', '5', 'Si', 'Si', 'Tabacos', 22, '45', '30 a dia', '15 años', '45');

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `historiaclinica`
-- 

CREATE TABLE `historiaclinica` (
  `idhistoriaClinica` int(11) NOT NULL auto_increment,
  `estadoActual` varchar(255) default NULL,
  `dolor` varchar(255) default NULL,
  `diente` varchar(255) default NULL,
  `tejidosVecinos` varchar(255) default NULL,
  `termicaFrio` varchar(255) default NULL,
  `evaluaciones` varchar(255) default NULL,
  `observaciones` varchar(255) default NULL,
  `etiologia` varchar(255) default NULL,
  `consulta_iddatosConsulta` int(11) NOT NULL,
  `corona` varchar(255) default NULL,
  `raiz` varchar(255) default NULL,
  `periapical` varchar(255) default NULL,
  PRIMARY KEY  (`idhistoriaClinica`),
  KEY `fk_historiaClinica_Consulta1_idx` (`consulta_iddatosConsulta`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

-- 
-- Volcar la base de datos para la tabla `historiaclinica`
-- 

INSERT INTO `historiaclinica` VALUES (6, 'no se', 'Provocado ', 'se ve feo', 'estan bien', 'no pasa nada', 'bn', 'bn', 'bn', 21, 'bn', 'bn', 'bn');
INSERT INTO `historiaclinica` VALUES (7, 'xx', 'Provocado ', 'xx', 'xx', 'ok', 'xx', 'xx', 'xx', 22, 'xx', 'xx', 'xx');

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `historiaclinica_has_diagnostico`
-- 

CREATE TABLE `historiaclinica_has_diagnostico` (
  `historiaClinica_idhistoriaClinica` int(11) NOT NULL,
  `diagnostico_iddiagnostico` int(11) NOT NULL,
  PRIMARY KEY  (`historiaClinica_idhistoriaClinica`,`diagnostico_iddiagnostico`),
  KEY `fk_historiaClinica_has_diagnostico_diagnostico1_idx` (`diagnostico_iddiagnostico`),
  KEY `fk_historiaClinica_has_diagnostico_historiaClinica1_idx` (`historiaClinica_idhistoriaClinica`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Volcar la base de datos para la tabla `historiaclinica_has_diagnostico`
-- 

INSERT INTO `historiaclinica_has_diagnostico` VALUES (6, 243400);
INSERT INTO `historiaclinica_has_diagnostico` VALUES (7, 237602);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `historiaclinica_has_tratamiento`
-- 

CREATE TABLE `historiaclinica_has_tratamiento` (
  `historiaClinica_idhistoriaClinica` int(11) NOT NULL,
  `tratamiento_idtratamiento` int(11) NOT NULL,
  PRIMARY KEY  (`historiaClinica_idhistoriaClinica`,`tratamiento_idtratamiento`),
  KEY `fk_historiaClinica_has_tratamiento_tratamiento1_idx` (`tratamiento_idtratamiento`),
  KEY `fk_historiaClinica_has_tratamiento_historiaClinica1_idx` (`historiaClinica_idhistoriaClinica`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Volcar la base de datos para la tabla `historiaclinica_has_tratamiento`
-- 

INSERT INTO `historiaclinica_has_tratamiento` VALUES (6, 915);
INSERT INTO `historiaclinica_has_tratamiento` VALUES (7, 209);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `interconsulta`
-- 

CREATE TABLE `interconsulta` (
  `idinterconsulta` int(11) NOT NULL,
  `interconsulta` varchar(45) default NULL,
  PRIMARY KEY  (`idinterconsulta`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Volcar la base de datos para la tabla `interconsulta`
-- 

INSERT INTO `interconsulta` VALUES (1, 'Semiologia');
INSERT INTO `interconsulta` VALUES (2, 'Promocion y Prevencion');
INSERT INTO `interconsulta` VALUES (3, 'Operatoria');
INSERT INTO `interconsulta` VALUES (4, 'Endodoncia');
INSERT INTO `interconsulta` VALUES (5, 'Periodoncia');
INSERT INTO `interconsulta` VALUES (6, 'Cirugia');
INSERT INTO `interconsulta` VALUES (7, 'Odontopedriatia');
INSERT INTO `interconsulta` VALUES (8, 'Rehabilitacion');
INSERT INTO `interconsulta` VALUES (9, 'Ortodoncia');
INSERT INTO `interconsulta` VALUES (10, 'Otros');

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `interconsulta_has_datosconsulta`
-- 

CREATE TABLE `interconsulta_has_datosconsulta` (
  `interconsulta_idinterconsulta` int(11) NOT NULL,
  `datosConsulta_iddatosConsulta` int(11) NOT NULL,
  PRIMARY KEY  (`interconsulta_idinterconsulta`,`datosConsulta_iddatosConsulta`),
  KEY `fk_interconsulta_has_datosConsulta_datosConsulta1` (`datosConsulta_iddatosConsulta`),
  KEY `fk_interconsulta_has_datosConsulta_interconsulta1` (`interconsulta_idinterconsulta`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Volcar la base de datos para la tabla `interconsulta_has_datosconsulta`
-- 

INSERT INTO `interconsulta_has_datosconsulta` VALUES (1, 21);
INSERT INTO `interconsulta_has_datosconsulta` VALUES (3, 22);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `medico`
-- 

CREATE TABLE `medico` (
  `idmedico` int(11) NOT NULL,
  `nombreUsuario` varchar(45) default NULL,
  `clave` varchar(45) default NULL,
  `direccion` varchar(255) default NULL,
  `telefono` varchar(45) default NULL,
  PRIMARY KEY  (`idmedico`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Volcar la base de datos para la tabla `medico`
-- 

INSERT INTO `medico` VALUES (123456, 'Julio Barcos', '123456', 'Blas de lezo', '686868');
INSERT INTO `medico` VALUES (6543554, 'Juan pereira', '6543554', 'barrio santa monica', '6565656');

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `medico_has_curso`
-- 

CREATE TABLE `medico_has_curso` (
  `medico_idmedico` int(11) NOT NULL,
  `curso_idcurso` int(11) NOT NULL,
  PRIMARY KEY  (`medico_idmedico`,`curso_idcurso`),
  KEY `fk_medico_has_curso_curso1` (`curso_idcurso`),
  KEY `fk_medico_has_curso_medico1` (`medico_idmedico`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Volcar la base de datos para la tabla `medico_has_curso`
-- 

INSERT INTO `medico_has_curso` VALUES (123456, 1);
INSERT INTO `medico_has_curso` VALUES (6543554, 1);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `medico_has_paciente`
-- 

CREATE TABLE `medico_has_paciente` (
  `medico_idmedico` int(11) NOT NULL,
  `paciente_idpersona` varchar(45) NOT NULL,
  KEY `fk_medico_has_paciente_paciente1` (`paciente_idpersona`),
  KEY `fk_medico_has_paciente_medico1` (`medico_idmedico`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Volcar la base de datos para la tabla `medico_has_paciente`
-- 

INSERT INTO `medico_has_paciente` VALUES (123456, '1047565684');
INSERT INTO `medico_has_paciente` VALUES (123456, '98765432');

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `municipios`
-- 

CREATE TABLE `municipios` (
  `codigo` int(11) NOT NULL,
  `nombre` varchar(45) default NULL,
  `departamentos_codigo1` int(11) NOT NULL,
  PRIMARY KEY  (`codigo`),
  KEY `fk_municipios_departamentos1` (`departamentos_codigo1`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Volcar la base de datos para la tabla `municipios`
-- 

INSERT INTO `municipios` VALUES (5001, 'Medellín', 5);
INSERT INTO `municipios` VALUES (5002, 'Abejorral', 5);
INSERT INTO `municipios` VALUES (5004, 'Abriaquí', 5);
INSERT INTO `municipios` VALUES (5021, 'Alejandria', 5);
INSERT INTO `municipios` VALUES (5030, 'Amagá', 5);
INSERT INTO `municipios` VALUES (5031, 'Amalfi', 5);
INSERT INTO `municipios` VALUES (5034, 'Andes', 5);
INSERT INTO `municipios` VALUES (5036, 'Angelópolis', 5);
INSERT INTO `municipios` VALUES (5038, 'Angostura', 5);
INSERT INTO `municipios` VALUES (5040, 'Anorí', 5);
INSERT INTO `municipios` VALUES (5042, 'Santa Fé de Antioquia', 5);
INSERT INTO `municipios` VALUES (5044, 'Anzá', 5);
INSERT INTO `municipios` VALUES (5045, 'Apartadó', 5);
INSERT INTO `municipios` VALUES (5051, 'Arboletes', 5);
INSERT INTO `municipios` VALUES (5055, 'Argelia', 5);
INSERT INTO `municipios` VALUES (5059, 'Armenia', 5);
INSERT INTO `municipios` VALUES (5079, 'Barbosa', 5);
INSERT INTO `municipios` VALUES (5086, 'Belmira', 5);
INSERT INTO `municipios` VALUES (5088, 'Bello', 5);
INSERT INTO `municipios` VALUES (5091, 'Betania', 5);
INSERT INTO `municipios` VALUES (5093, 'Betulia', 5);
INSERT INTO `municipios` VALUES (5101, 'Bolívar', 5);
INSERT INTO `municipios` VALUES (5107, 'Briceño', 5);
INSERT INTO `municipios` VALUES (5113, 'Burítica', 5);
INSERT INTO `municipios` VALUES (5120, 'Cáceres', 5);
INSERT INTO `municipios` VALUES (5125, 'Caicedo', 5);
INSERT INTO `municipios` VALUES (5129, 'Caldas', 5);
INSERT INTO `municipios` VALUES (5134, 'Campamento', 5);
INSERT INTO `municipios` VALUES (5138, 'Cañasgordas', 5);
INSERT INTO `municipios` VALUES (5142, 'Caracolí', 5);
INSERT INTO `municipios` VALUES (5145, 'Caramanta', 5);
INSERT INTO `municipios` VALUES (5147, 'Carepa', 5);
INSERT INTO `municipios` VALUES (5148, 'Carmen de Viboral', 5);
INSERT INTO `municipios` VALUES (5150, 'Carolina', 5);
INSERT INTO `municipios` VALUES (5154, 'Caucasia', 5);
INSERT INTO `municipios` VALUES (5172, 'Chigorodó', 5);
INSERT INTO `municipios` VALUES (5190, 'Cisneros', 5);
INSERT INTO `municipios` VALUES (5197, 'Cocorná', 5);
INSERT INTO `municipios` VALUES (5206, 'Concepción', 5);
INSERT INTO `municipios` VALUES (5209, 'Concordia', 5);
INSERT INTO `municipios` VALUES (5212, 'Copacabana', 5);
INSERT INTO `municipios` VALUES (5234, 'Dabeiba', 5);
INSERT INTO `municipios` VALUES (5237, 'Don Matías', 5);
INSERT INTO `municipios` VALUES (5240, 'Ebéjico', 5);
INSERT INTO `municipios` VALUES (5250, 'El Bagre', 5);
INSERT INTO `municipios` VALUES (5264, 'Entrerríos', 5);
INSERT INTO `municipios` VALUES (5266, 'Envigado', 5);
INSERT INTO `municipios` VALUES (5282, 'Fredonia', 5);
INSERT INTO `municipios` VALUES (5284, 'Frontino', 5);
INSERT INTO `municipios` VALUES (5306, 'Giraldo', 5);
INSERT INTO `municipios` VALUES (5308, 'Girardota', 5);
INSERT INTO `municipios` VALUES (5310, 'Gómez Plata', 5);
INSERT INTO `municipios` VALUES (5313, 'Granada', 5);
INSERT INTO `municipios` VALUES (5315, 'Guadalupe', 5);
INSERT INTO `municipios` VALUES (5318, 'Guarne', 5);
INSERT INTO `municipios` VALUES (5321, 'Guatapé', 5);
INSERT INTO `municipios` VALUES (5347, 'Heliconia', 5);
INSERT INTO `municipios` VALUES (5353, 'Hispania', 5);
INSERT INTO `municipios` VALUES (5360, 'Itagüí', 5);
INSERT INTO `municipios` VALUES (5361, 'Ituango', 5);
INSERT INTO `municipios` VALUES (5364, 'Jardín', 5);
INSERT INTO `municipios` VALUES (5368, 'Jericó', 5);
INSERT INTO `municipios` VALUES (5376, 'La Ceja', 5);
INSERT INTO `municipios` VALUES (5380, 'La Estrella', 5);
INSERT INTO `municipios` VALUES (5390, 'La Pintada', 5);
INSERT INTO `municipios` VALUES (5400, 'La Unión', 5);
INSERT INTO `municipios` VALUES (5411, 'Liborina', 5);
INSERT INTO `municipios` VALUES (5425, 'Maceo', 5);
INSERT INTO `municipios` VALUES (5440, 'Marinilla', 5);
INSERT INTO `municipios` VALUES (5467, 'Montebello', 5);
INSERT INTO `municipios` VALUES (5475, 'Murindó', 5);
INSERT INTO `municipios` VALUES (5480, 'Mutatá', 5);
INSERT INTO `municipios` VALUES (5483, 'Nariño', 5);
INSERT INTO `municipios` VALUES (5490, 'Necoclí', 5);
INSERT INTO `municipios` VALUES (5495, 'Nechí', 5);
INSERT INTO `municipios` VALUES (5501, 'Olaya', 5);
INSERT INTO `municipios` VALUES (5541, 'Peñol', 5);
INSERT INTO `municipios` VALUES (5543, 'Peque', 5);
INSERT INTO `municipios` VALUES (5576, 'Pueblorrico', 5);
INSERT INTO `municipios` VALUES (5579, 'Puerto Berrío', 5);
INSERT INTO `municipios` VALUES (5585, 'Puerto Nare', 5);
INSERT INTO `municipios` VALUES (5591, 'Puerto Triunfo', 5);
INSERT INTO `municipios` VALUES (5604, 'Remedios', 5);
INSERT INTO `municipios` VALUES (5607, 'Retiro', 5);
INSERT INTO `municipios` VALUES (5615, 'Ríonegro', 5);
INSERT INTO `municipios` VALUES (5628, 'Sabanalarga', 5);
INSERT INTO `municipios` VALUES (5631, 'Sabaneta', 5);
INSERT INTO `municipios` VALUES (5642, 'Salgar', 5);
INSERT INTO `municipios` VALUES (5647, 'San Andrés de Cuerquía', 5);
INSERT INTO `municipios` VALUES (5649, 'San Carlos', 5);
INSERT INTO `municipios` VALUES (5652, 'San Francisco', 5);
INSERT INTO `municipios` VALUES (5656, 'San Jerónimo', 5);
INSERT INTO `municipios` VALUES (5658, 'San José de Montaña', 5);
INSERT INTO `municipios` VALUES (5659, 'San Juan de Urabá', 5);
INSERT INTO `municipios` VALUES (5660, 'San Luís', 5);
INSERT INTO `municipios` VALUES (5664, 'San Pedro', 5);
INSERT INTO `municipios` VALUES (5665, 'San Pedro de Urabá', 5);
INSERT INTO `municipios` VALUES (5667, 'San Rafael', 5);
INSERT INTO `municipios` VALUES (5670, 'San Roque', 5);
INSERT INTO `municipios` VALUES (5674, 'San Vicente', 5);
INSERT INTO `municipios` VALUES (5679, 'Santa Bárbara', 5);
INSERT INTO `municipios` VALUES (5686, 'Santa Rosa de Osos', 5);
INSERT INTO `municipios` VALUES (5690, 'Santo Domingo', 5);
INSERT INTO `municipios` VALUES (5697, 'Santuario', 5);
INSERT INTO `municipios` VALUES (5736, 'Segovia', 5);
INSERT INTO `municipios` VALUES (5756, 'Sonsón', 5);
INSERT INTO `municipios` VALUES (5761, 'Sopetrán', 5);
INSERT INTO `municipios` VALUES (5789, 'Támesis', 5);
INSERT INTO `municipios` VALUES (5790, 'Tarazá', 5);
INSERT INTO `municipios` VALUES (5792, 'Tarso', 5);
INSERT INTO `municipios` VALUES (5809, 'Titiribí', 5);
INSERT INTO `municipios` VALUES (5819, 'Toledo', 5);
INSERT INTO `municipios` VALUES (5837, 'Turbo', 5);
INSERT INTO `municipios` VALUES (5842, 'Uramita', 5);
INSERT INTO `municipios` VALUES (5847, 'Urrao', 5);
INSERT INTO `municipios` VALUES (5854, 'Valdivia', 5);
INSERT INTO `municipios` VALUES (5856, 'Valparaiso', 5);
INSERT INTO `municipios` VALUES (5858, 'Vegachí', 5);
INSERT INTO `municipios` VALUES (5861, 'Venecia', 5);
INSERT INTO `municipios` VALUES (5873, 'Vigía del Fuerte', 5);
INSERT INTO `municipios` VALUES (5885, 'Yalí', 5);
INSERT INTO `municipios` VALUES (5887, 'Yarumal', 5);
INSERT INTO `municipios` VALUES (5890, 'Yolombó', 5);
INSERT INTO `municipios` VALUES (5893, 'Yondó (Casabe)', 5);
INSERT INTO `municipios` VALUES (5895, 'Zaragoza', 5);
INSERT INTO `municipios` VALUES (8001, 'Barranquilla', 8);
INSERT INTO `municipios` VALUES (8078, 'Baranoa', 8);
INSERT INTO `municipios` VALUES (8132, 'Juan de Acosta', 8);
INSERT INTO `municipios` VALUES (8137, 'Campo de la Cruz', 8);
INSERT INTO `municipios` VALUES (8141, 'Candelaria', 8);
INSERT INTO `municipios` VALUES (8296, 'Galapa', 8);
INSERT INTO `municipios` VALUES (8421, 'Luruaco', 8);
INSERT INTO `municipios` VALUES (8433, 'Malambo', 8);
INSERT INTO `municipios` VALUES (8436, 'Manatí', 8);
INSERT INTO `municipios` VALUES (8520, 'Palmar de Varela', 8);
INSERT INTO `municipios` VALUES (8549, 'Piojo', 8);
INSERT INTO `municipios` VALUES (8558, 'Polonuevo', 8);
INSERT INTO `municipios` VALUES (8560, 'Ponedera', 8);
INSERT INTO `municipios` VALUES (8573, 'Puerto Colombia', 8);
INSERT INTO `municipios` VALUES (8606, 'Repelón', 8);
INSERT INTO `municipios` VALUES (8634, 'Sabanagrande', 8);
INSERT INTO `municipios` VALUES (8638, 'Sabanalarga', 8);
INSERT INTO `municipios` VALUES (8675, 'Santa Lucía', 8);
INSERT INTO `municipios` VALUES (8685, 'Santo Tomás', 8);
INSERT INTO `municipios` VALUES (8758, 'Soledad', 8);
INSERT INTO `municipios` VALUES (8770, 'Suan', 8);
INSERT INTO `municipios` VALUES (8832, 'Tubará', 8);
INSERT INTO `municipios` VALUES (8849, 'Usiacuri', 8);
INSERT INTO `municipios` VALUES (11001, 'Bogotá D.C.', 25);
INSERT INTO `municipios` VALUES (13001, 'Cartagena', 13);
INSERT INTO `municipios` VALUES (13006, 'Achí', 13);
INSERT INTO `municipios` VALUES (13030, 'Altos del Rosario', 13);
INSERT INTO `municipios` VALUES (13042, 'Arenal', 13);
INSERT INTO `municipios` VALUES (13052, 'Arjona', 13);
INSERT INTO `municipios` VALUES (13062, 'Arroyohondo', 13);
INSERT INTO `municipios` VALUES (13074, 'Barranco de Loba', 13);
INSERT INTO `municipios` VALUES (13140, 'Calamar', 13);
INSERT INTO `municipios` VALUES (13160, 'Cantagallo', 13);
INSERT INTO `municipios` VALUES (13188, 'Cicuco', 13);
INSERT INTO `municipios` VALUES (13212, 'Córdoba', 13);
INSERT INTO `municipios` VALUES (13222, 'Clemencia', 13);
INSERT INTO `municipios` VALUES (13244, 'El Carmen de Bolívar', 13);
INSERT INTO `municipios` VALUES (13248, 'El Guamo', 13);
INSERT INTO `municipios` VALUES (13268, 'El Peñon', 13);
INSERT INTO `municipios` VALUES (13300, 'Hatillo de Loba', 13);
INSERT INTO `municipios` VALUES (13430, 'Magangué', 13);
INSERT INTO `municipios` VALUES (13433, 'Mahates', 13);
INSERT INTO `municipios` VALUES (13440, 'Margarita', 13);
INSERT INTO `municipios` VALUES (13442, 'María la Baja', 13);
INSERT INTO `municipios` VALUES (13458, 'Montecristo', 13);
INSERT INTO `municipios` VALUES (13468, 'Mompós', 13);
INSERT INTO `municipios` VALUES (13473, 'Morales', 13);
INSERT INTO `municipios` VALUES (13490, 'Norosí', 13);
INSERT INTO `municipios` VALUES (13549, 'Pinillos', 13);
INSERT INTO `municipios` VALUES (13580, 'Regidor', 13);
INSERT INTO `municipios` VALUES (13600, 'Río Viejo', 13);
INSERT INTO `municipios` VALUES (13620, 'San Cristobal', 13);
INSERT INTO `municipios` VALUES (13647, 'San Estanislao', 13);
INSERT INTO `municipios` VALUES (13650, 'San Fernando', 13);
INSERT INTO `municipios` VALUES (13654, 'San Jacinto', 13);
INSERT INTO `municipios` VALUES (13655, 'San Jacinto del Cauca', 13);
INSERT INTO `municipios` VALUES (13657, 'San Juan de Nepomuceno', 13);
INSERT INTO `municipios` VALUES (13667, 'San Martín de Loba', 13);
INSERT INTO `municipios` VALUES (13670, 'San Pablo', 13);
INSERT INTO `municipios` VALUES (13673, 'Santa Catalina', 13);
INSERT INTO `municipios` VALUES (13683, 'Santa Rosa', 13);
INSERT INTO `municipios` VALUES (13688, 'Santa Rosa del Sur', 13);
INSERT INTO `municipios` VALUES (13744, 'Simití', 13);
INSERT INTO `municipios` VALUES (13760, 'Soplaviento', 13);
INSERT INTO `municipios` VALUES (13780, 'Talaigua Nuevo', 13);
INSERT INTO `municipios` VALUES (13810, 'Tiquisio (Puerto Rico)', 13);
INSERT INTO `municipios` VALUES (13836, 'Turbaco', 13);
INSERT INTO `municipios` VALUES (13838, 'Turbaná', 13);
INSERT INTO `municipios` VALUES (13873, 'Villanueva', 13);
INSERT INTO `municipios` VALUES (13894, 'Zambrano', 13);
INSERT INTO `municipios` VALUES (15001, 'Tunja', 15);
INSERT INTO `municipios` VALUES (15022, 'Almeida', 15);
INSERT INTO `municipios` VALUES (15047, 'Aquitania', 15);
INSERT INTO `municipios` VALUES (15051, 'Arcabuco', 15);
INSERT INTO `municipios` VALUES (15087, 'Belén', 15);
INSERT INTO `municipios` VALUES (15090, 'Berbeo', 15);
INSERT INTO `municipios` VALUES (15092, 'Beteitiva', 15);
INSERT INTO `municipios` VALUES (15097, 'Boavita', 15);
INSERT INTO `municipios` VALUES (15104, 'Boyacá', 15);
INSERT INTO `municipios` VALUES (15106, 'Briceño', 15);
INSERT INTO `municipios` VALUES (15109, 'Buenavista', 15);
INSERT INTO `municipios` VALUES (15114, 'Busbanza', 15);
INSERT INTO `municipios` VALUES (15131, 'Caldas', 15);
INSERT INTO `municipios` VALUES (15135, 'Campohermoso', 15);
INSERT INTO `municipios` VALUES (15162, 'Cerinza', 15);
INSERT INTO `municipios` VALUES (15172, 'Chinavita', 15);
INSERT INTO `municipios` VALUES (15176, 'Chiquinquirá', 15);
INSERT INTO `municipios` VALUES (15180, 'Chiscas', 15);
INSERT INTO `municipios` VALUES (15183, 'Chita', 15);
INSERT INTO `municipios` VALUES (15185, 'Chitaraque', 15);
INSERT INTO `municipios` VALUES (15187, 'Chivatá', 15);
INSERT INTO `municipios` VALUES (15189, 'Ciénaga', 15);
INSERT INTO `municipios` VALUES (15204, 'Cómbita', 15);
INSERT INTO `municipios` VALUES (15212, 'Coper', 15);
INSERT INTO `municipios` VALUES (15215, 'Corrales', 15);
INSERT INTO `municipios` VALUES (15218, 'Covarachía', 15);
INSERT INTO `municipios` VALUES (15223, 'Cubará', 15);
INSERT INTO `municipios` VALUES (15224, 'Cucaita', 15);
INSERT INTO `municipios` VALUES (15226, 'Cuitiva', 15);
INSERT INTO `municipios` VALUES (15232, 'Chíquiza', 15);
INSERT INTO `municipios` VALUES (15236, 'Chívor', 15);
INSERT INTO `municipios` VALUES (15238, 'Duitama', 15);
INSERT INTO `municipios` VALUES (15244, 'El Cocuy', 15);
INSERT INTO `municipios` VALUES (15248, 'El Espino', 15);
INSERT INTO `municipios` VALUES (15272, 'Firavitoba', 15);
INSERT INTO `municipios` VALUES (15276, 'Floresta', 15);
INSERT INTO `municipios` VALUES (15293, 'Gachantivá', 15);
INSERT INTO `municipios` VALUES (15296, 'Gámeza', 15);
INSERT INTO `municipios` VALUES (15299, 'Garagoa', 15);
INSERT INTO `municipios` VALUES (15317, 'Guacamayas', 15);
INSERT INTO `municipios` VALUES (15322, 'Guateque', 15);
INSERT INTO `municipios` VALUES (15325, 'Guayatá', 15);
INSERT INTO `municipios` VALUES (15332, 'Guicán', 15);
INSERT INTO `municipios` VALUES (15362, 'Izá', 15);
INSERT INTO `municipios` VALUES (15367, 'Jenesano', 15);
INSERT INTO `municipios` VALUES (15368, 'Jericó', 15);
INSERT INTO `municipios` VALUES (15377, 'Labranzagrande', 15);
INSERT INTO `municipios` VALUES (15380, 'La Capilla', 15);
INSERT INTO `municipios` VALUES (15401, 'La Victoria', 15);
INSERT INTO `municipios` VALUES (15403, 'La Uvita', 15);
INSERT INTO `municipios` VALUES (15407, 'Villa de Leiva', 15);
INSERT INTO `municipios` VALUES (15425, 'Macanal', 15);
INSERT INTO `municipios` VALUES (15442, 'Maripí', 15);
INSERT INTO `municipios` VALUES (15455, 'Miraflores', 15);
INSERT INTO `municipios` VALUES (15464, 'Mongua', 15);
INSERT INTO `municipios` VALUES (15466, 'Monguí', 15);
INSERT INTO `municipios` VALUES (15469, 'Moniquirá', 15);
INSERT INTO `municipios` VALUES (15476, 'Motavita', 15);
INSERT INTO `municipios` VALUES (15480, 'Muzo', 15);
INSERT INTO `municipios` VALUES (15491, 'Nobsa', 15);
INSERT INTO `municipios` VALUES (15494, 'Nuevo Colón', 15);
INSERT INTO `municipios` VALUES (15500, 'Oicatá', 15);
INSERT INTO `municipios` VALUES (15507, 'Otanche', 15);
INSERT INTO `municipios` VALUES (15511, 'Pachavita', 15);
INSERT INTO `municipios` VALUES (15514, 'Páez', 15);
INSERT INTO `municipios` VALUES (15516, 'Paipa', 15);
INSERT INTO `municipios` VALUES (15518, 'Pajarito', 15);
INSERT INTO `municipios` VALUES (15522, 'Panqueba', 15);
INSERT INTO `municipios` VALUES (15531, 'Pauna', 15);
INSERT INTO `municipios` VALUES (15532, 'Paya', 15);
INSERT INTO `municipios` VALUES (15537, 'Paz de Río', 15);
INSERT INTO `municipios` VALUES (15542, 'Pesca', 15);
INSERT INTO `municipios` VALUES (15550, 'Pisva', 15);
INSERT INTO `municipios` VALUES (15572, 'Puerto Boyacá', 15);
INSERT INTO `municipios` VALUES (15580, 'Quipama', 15);
INSERT INTO `municipios` VALUES (15599, 'Ramiriquí', 15);
INSERT INTO `municipios` VALUES (15600, 'Ráquira', 15);
INSERT INTO `municipios` VALUES (15621, 'Rondón', 15);
INSERT INTO `municipios` VALUES (15632, 'Saboyá', 15);
INSERT INTO `municipios` VALUES (15638, 'Sáchica', 15);
INSERT INTO `municipios` VALUES (15646, 'Samacá', 15);
INSERT INTO `municipios` VALUES (15660, 'San Eduardo', 15);
INSERT INTO `municipios` VALUES (15664, 'San José de Pare', 15);
INSERT INTO `municipios` VALUES (15667, 'San Luís de Gaceno', 15);
INSERT INTO `municipios` VALUES (15673, 'San Mateo', 15);
INSERT INTO `municipios` VALUES (15676, 'San Miguel de Sema', 15);
INSERT INTO `municipios` VALUES (15681, 'San Pablo de Borbur', 15);
INSERT INTO `municipios` VALUES (15686, 'Santana', 15);
INSERT INTO `municipios` VALUES (15690, 'Santa María', 15);
INSERT INTO `municipios` VALUES (15693, 'Santa Rosa de Viterbo', 15);
INSERT INTO `municipios` VALUES (15696, 'Santa Sofía', 15);
INSERT INTO `municipios` VALUES (15720, 'Sativanorte', 15);
INSERT INTO `municipios` VALUES (15723, 'Sativasur', 15);
INSERT INTO `municipios` VALUES (15740, 'Siachoque', 15);
INSERT INTO `municipios` VALUES (15753, 'Soatá', 15);
INSERT INTO `municipios` VALUES (15755, 'Socotá', 15);
INSERT INTO `municipios` VALUES (15757, 'Socha', 15);
INSERT INTO `municipios` VALUES (15759, 'Sogamoso', 15);
INSERT INTO `municipios` VALUES (15761, 'Somondoco', 15);
INSERT INTO `municipios` VALUES (15762, 'Sora', 15);
INSERT INTO `municipios` VALUES (15763, 'Sotaquirá', 15);
INSERT INTO `municipios` VALUES (15764, 'Soracá', 15);
INSERT INTO `municipios` VALUES (15774, 'Susacón', 15);
INSERT INTO `municipios` VALUES (15776, 'Sutamarchán', 15);
INSERT INTO `municipios` VALUES (15778, 'Sutatenza', 15);
INSERT INTO `municipios` VALUES (15790, 'Tasco', 15);
INSERT INTO `municipios` VALUES (15798, 'Tenza', 15);
INSERT INTO `municipios` VALUES (15804, 'Tibaná', 15);
INSERT INTO `municipios` VALUES (15806, 'Tibasosa', 15);
INSERT INTO `municipios` VALUES (15808, 'Tinjacá', 15);
INSERT INTO `municipios` VALUES (15810, 'Tipacoque', 15);
INSERT INTO `municipios` VALUES (15814, 'Toca', 15);
INSERT INTO `municipios` VALUES (15816, 'Toguí', 15);
INSERT INTO `municipios` VALUES (15820, 'Topagá', 15);
INSERT INTO `municipios` VALUES (15822, 'Tota', 15);
INSERT INTO `municipios` VALUES (15832, 'Tunungua', 15);
INSERT INTO `municipios` VALUES (15835, 'Turmequé', 15);
INSERT INTO `municipios` VALUES (15837, 'Tuta', 15);
INSERT INTO `municipios` VALUES (15839, 'Tutasá', 15);
INSERT INTO `municipios` VALUES (15842, 'Úmbita', 15);
INSERT INTO `municipios` VALUES (15861, 'Ventaquemada', 15);
INSERT INTO `municipios` VALUES (15879, 'Viracachá', 15);
INSERT INTO `municipios` VALUES (15897, 'Zetaquirá', 15);
INSERT INTO `municipios` VALUES (17001, 'Manizales', 17);
INSERT INTO `municipios` VALUES (17013, 'Aguadas', 17);
INSERT INTO `municipios` VALUES (17042, 'Anserma', 17);
INSERT INTO `municipios` VALUES (17050, 'Aranzazu', 17);
INSERT INTO `municipios` VALUES (17088, 'Belalcázar', 17);
INSERT INTO `municipios` VALUES (17174, 'Chinchiná', 17);
INSERT INTO `municipios` VALUES (17272, 'Filadelfia', 17);
INSERT INTO `municipios` VALUES (17380, 'La Dorada', 17);
INSERT INTO `municipios` VALUES (17388, 'La Merced', 17);
INSERT INTO `municipios` VALUES (17433, 'Manzanares', 17);
INSERT INTO `municipios` VALUES (17442, 'Marmato', 17);
INSERT INTO `municipios` VALUES (17444, 'Marquetalia', 17);
INSERT INTO `municipios` VALUES (17446, 'Marulanda', 17);
INSERT INTO `municipios` VALUES (17486, 'Neira', 17);
INSERT INTO `municipios` VALUES (17495, 'Norcasia', 17);
INSERT INTO `municipios` VALUES (17513, 'Pácora', 17);
INSERT INTO `municipios` VALUES (17524, 'Palestina', 17);
INSERT INTO `municipios` VALUES (17541, 'Pensilvania', 17);
INSERT INTO `municipios` VALUES (17614, 'Río Sucio', 17);
INSERT INTO `municipios` VALUES (17616, 'Risaralda', 17);
INSERT INTO `municipios` VALUES (17653, 'Salamina', 17);
INSERT INTO `municipios` VALUES (17662, 'Samaná', 17);
INSERT INTO `municipios` VALUES (17665, 'San José', 17);
INSERT INTO `municipios` VALUES (17777, 'Supía', 17);
INSERT INTO `municipios` VALUES (17867, 'La Victoria', 17);
INSERT INTO `municipios` VALUES (17873, 'Villamaría', 17);
INSERT INTO `municipios` VALUES (17877, 'Viterbo', 17);
INSERT INTO `municipios` VALUES (18001, 'Florencia', 18);
INSERT INTO `municipios` VALUES (18029, 'Albania', 18);
INSERT INTO `municipios` VALUES (18094, 'Belén de los Andaquíes', 18);
INSERT INTO `municipios` VALUES (18150, 'Cartagena del Chairá', 18);
INSERT INTO `municipios` VALUES (18205, 'Curillo', 18);
INSERT INTO `municipios` VALUES (18247, 'El Doncello', 18);
INSERT INTO `municipios` VALUES (18256, 'El Paujil', 18);
INSERT INTO `municipios` VALUES (18410, 'La Montañita', 18);
INSERT INTO `municipios` VALUES (18460, 'Milán', 18);
INSERT INTO `municipios` VALUES (18479, 'Morelia', 18);
INSERT INTO `municipios` VALUES (18592, 'Puerto Rico', 18);
INSERT INTO `municipios` VALUES (18610, 'San José del Fragua', 18);
INSERT INTO `municipios` VALUES (18753, 'San Vicente del Caguán', 18);
INSERT INTO `municipios` VALUES (18765, 'Solano', 18);
INSERT INTO `municipios` VALUES (18785, 'Solita', 18);
INSERT INTO `municipios` VALUES (18860, 'Valparaiso', 18);
INSERT INTO `municipios` VALUES (19001, 'Popayán', 19);
INSERT INTO `municipios` VALUES (19022, 'Almaguer', 19);
INSERT INTO `municipios` VALUES (19050, 'Argelia', 19);
INSERT INTO `municipios` VALUES (19075, 'Balboa', 19);
INSERT INTO `municipios` VALUES (19100, 'Bolívar', 19);
INSERT INTO `municipios` VALUES (19110, 'Buenos Aires', 19);
INSERT INTO `municipios` VALUES (19130, 'Cajibío', 19);
INSERT INTO `municipios` VALUES (19137, 'Caldono', 19);
INSERT INTO `municipios` VALUES (19142, 'Caloto', 19);
INSERT INTO `municipios` VALUES (19212, 'Corinto', 19);
INSERT INTO `municipios` VALUES (19256, 'El Tambo', 19);
INSERT INTO `municipios` VALUES (19290, 'Florencia', 19);
INSERT INTO `municipios` VALUES (19300, 'Guachené', 19);
INSERT INTO `municipios` VALUES (19318, 'Guapí', 19);
INSERT INTO `municipios` VALUES (19355, 'Inzá', 19);
INSERT INTO `municipios` VALUES (19364, 'Jambaló', 19);
INSERT INTO `municipios` VALUES (19392, 'La Sierra', 19);
INSERT INTO `municipios` VALUES (19397, 'La Vega', 19);
INSERT INTO `municipios` VALUES (19418, 'López (Micay)', 19);
INSERT INTO `municipios` VALUES (19450, 'Mercaderes', 19);
INSERT INTO `municipios` VALUES (19455, 'Miranda', 19);
INSERT INTO `municipios` VALUES (19473, 'Morales', 19);
INSERT INTO `municipios` VALUES (19513, 'Padilla', 19);
INSERT INTO `municipios` VALUES (19517, 'Páez (Belalcazar)', 19);
INSERT INTO `municipios` VALUES (19532, 'Patía (El Bordo)', 19);
INSERT INTO `municipios` VALUES (19533, 'Piamonte', 19);
INSERT INTO `municipios` VALUES (19548, 'Piendamó', 19);
INSERT INTO `municipios` VALUES (19573, 'Puerto Tejada', 19);
INSERT INTO `municipios` VALUES (19585, 'Puracé (Coconuco)', 19);
INSERT INTO `municipios` VALUES (19622, 'Rosas', 19);
INSERT INTO `municipios` VALUES (19693, 'San Sebastián', 19);
INSERT INTO `municipios` VALUES (19698, 'Santander de Quilichao', 19);
INSERT INTO `municipios` VALUES (19701, 'Santa Rosa', 19);
INSERT INTO `municipios` VALUES (19743, 'Silvia', 19);
INSERT INTO `municipios` VALUES (19760, 'Sotara (Paispamba)', 19);
INSERT INTO `municipios` VALUES (19780, 'Suárez', 19);
INSERT INTO `municipios` VALUES (19785, 'Sucre', 19);
INSERT INTO `municipios` VALUES (19807, 'Timbío', 19);
INSERT INTO `municipios` VALUES (19809, 'Timbiquí', 19);
INSERT INTO `municipios` VALUES (19821, 'Toribío', 19);
INSERT INTO `municipios` VALUES (19824, 'Totoró', 19);
INSERT INTO `municipios` VALUES (19845, 'Villa Rica', 19);
INSERT INTO `municipios` VALUES (20001, 'Valledupar', 20);
INSERT INTO `municipios` VALUES (20011, 'Aguachica', 20);
INSERT INTO `municipios` VALUES (20013, 'Agustín Codazzi', 20);
INSERT INTO `municipios` VALUES (20032, 'Astrea', 20);
INSERT INTO `municipios` VALUES (20045, 'Becerríl', 20);
INSERT INTO `municipios` VALUES (20060, 'Bosconia', 20);
INSERT INTO `municipios` VALUES (20175, 'Chimichagua', 20);
INSERT INTO `municipios` VALUES (20178, 'Chiriguaná', 20);
INSERT INTO `municipios` VALUES (20228, 'Curumaní', 20);
INSERT INTO `municipios` VALUES (20238, 'El Copey', 20);
INSERT INTO `municipios` VALUES (20250, 'El Paso', 20);
INSERT INTO `municipios` VALUES (20295, 'Gamarra', 20);
INSERT INTO `municipios` VALUES (20310, 'Gonzalez', 20);
INSERT INTO `municipios` VALUES (20383, 'La Gloria', 20);
INSERT INTO `municipios` VALUES (20400, 'La Jagua de Ibirico', 20);
INSERT INTO `municipios` VALUES (20443, 'Manaure Balcón del Cesar', 20);
INSERT INTO `municipios` VALUES (20517, 'Pailitas', 20);
INSERT INTO `municipios` VALUES (20550, 'Pelaya', 20);
INSERT INTO `municipios` VALUES (20570, 'Pueblo Bello', 20);
INSERT INTO `municipios` VALUES (20614, 'Río de oro', 20);
INSERT INTO `municipios` VALUES (20621, 'La Paz (Robles)', 20);
INSERT INTO `municipios` VALUES (20710, 'San Alberto', 20);
INSERT INTO `municipios` VALUES (20750, 'San Diego', 20);
INSERT INTO `municipios` VALUES (20770, 'San Martín', 20);
INSERT INTO `municipios` VALUES (20787, 'Tamalameque', 20);
INSERT INTO `municipios` VALUES (23001, 'Monteria', 23);
INSERT INTO `municipios` VALUES (23068, 'Ayapel', 23);
INSERT INTO `municipios` VALUES (23079, 'Buenavista', 23);
INSERT INTO `municipios` VALUES (23090, 'Canalete', 23);
INSERT INTO `municipios` VALUES (23162, 'Cereté', 23);
INSERT INTO `municipios` VALUES (23168, 'Chimá', 23);
INSERT INTO `municipios` VALUES (23182, 'Chinú', 23);
INSERT INTO `municipios` VALUES (23189, 'Ciénaga de Oro', 23);
INSERT INTO `municipios` VALUES (23300, 'Cotorra', 23);
INSERT INTO `municipios` VALUES (23350, 'La Apartada y La Frontera', 23);
INSERT INTO `municipios` VALUES (23417, 'Lorica', 23);
INSERT INTO `municipios` VALUES (23419, 'Los Córdobas', 23);
INSERT INTO `municipios` VALUES (23464, 'Momil', 23);
INSERT INTO `municipios` VALUES (23466, 'Montelíbano', 23);
INSERT INTO `municipios` VALUES (23500, 'Moñitos', 23);
INSERT INTO `municipios` VALUES (23555, 'Planeta Rica', 23);
INSERT INTO `municipios` VALUES (23570, 'Pueblo Nuevo', 23);
INSERT INTO `municipios` VALUES (23574, 'Puerto Escondido', 23);
INSERT INTO `municipios` VALUES (23580, 'Puerto Libertador', 23);
INSERT INTO `municipios` VALUES (23586, 'Purísima', 23);
INSERT INTO `municipios` VALUES (23660, 'Sahagún', 23);
INSERT INTO `municipios` VALUES (23670, 'San Andrés Sotavento', 23);
INSERT INTO `municipios` VALUES (23672, 'San Antero', 23);
INSERT INTO `municipios` VALUES (23675, 'San Bernardo del Viento', 23);
INSERT INTO `municipios` VALUES (23678, 'San Carlos', 23);
INSERT INTO `municipios` VALUES (23682, 'San José de Uré', 23);
INSERT INTO `municipios` VALUES (23686, 'San Pelayo', 23);
INSERT INTO `municipios` VALUES (23807, 'Tierralta', 23);
INSERT INTO `municipios` VALUES (23815, 'Tuchín', 23);
INSERT INTO `municipios` VALUES (23855, 'Valencia', 23);
INSERT INTO `municipios` VALUES (25001, 'Agua de Dios', 25);
INSERT INTO `municipios` VALUES (25019, 'Albán', 25);
INSERT INTO `municipios` VALUES (25035, 'Anapoima', 25);
INSERT INTO `municipios` VALUES (25040, 'Anolaima', 25);
INSERT INTO `municipios` VALUES (25053, 'Arbeláez', 25);
INSERT INTO `municipios` VALUES (25086, 'Beltrán', 25);
INSERT INTO `municipios` VALUES (25095, 'Bituima', 25);
INSERT INTO `municipios` VALUES (25099, 'Bojacá', 25);
INSERT INTO `municipios` VALUES (25120, 'Cabrera', 25);
INSERT INTO `municipios` VALUES (25123, 'Cachipay', 25);
INSERT INTO `municipios` VALUES (25126, 'Cajicá', 25);
INSERT INTO `municipios` VALUES (25148, 'Caparrapí', 25);
INSERT INTO `municipios` VALUES (25151, 'Cáqueza', 25);
INSERT INTO `municipios` VALUES (25154, 'Carmen de Carupa', 25);
INSERT INTO `municipios` VALUES (25168, 'Chaguaní', 25);
INSERT INTO `municipios` VALUES (25175, 'Chía', 25);
INSERT INTO `municipios` VALUES (25178, 'Chipaque', 25);
INSERT INTO `municipios` VALUES (25181, 'Choachí', 25);
INSERT INTO `municipios` VALUES (25183, 'Chocontá', 25);
INSERT INTO `municipios` VALUES (25200, 'Cogua', 25);
INSERT INTO `municipios` VALUES (25214, 'Cota', 25);
INSERT INTO `municipios` VALUES (25224, 'Cucunubá', 25);
INSERT INTO `municipios` VALUES (25245, 'El Colegio', 25);
INSERT INTO `municipios` VALUES (25258, 'El Peñón', 25);
INSERT INTO `municipios` VALUES (25260, 'El Rosal', 25);
INSERT INTO `municipios` VALUES (25269, 'Facatativá', 25);
INSERT INTO `municipios` VALUES (25279, 'Fómeque', 25);
INSERT INTO `municipios` VALUES (25281, 'Fosca', 25);
INSERT INTO `municipios` VALUES (25286, 'Funza', 25);
INSERT INTO `municipios` VALUES (25288, 'Fúquene', 25);
INSERT INTO `municipios` VALUES (25290, 'Fusagasugá', 25);
INSERT INTO `municipios` VALUES (25293, 'Gachalá', 25);
INSERT INTO `municipios` VALUES (25295, 'Gachancipá', 25);
INSERT INTO `municipios` VALUES (25297, 'Gachetá', 25);
INSERT INTO `municipios` VALUES (25299, 'Gama', 25);
INSERT INTO `municipios` VALUES (25307, 'Girardot', 25);
INSERT INTO `municipios` VALUES (25312, 'Granada', 25);
INSERT INTO `municipios` VALUES (25317, 'Guachetá', 25);
INSERT INTO `municipios` VALUES (25320, 'Guaduas', 25);
INSERT INTO `municipios` VALUES (25322, 'Guasca', 25);
INSERT INTO `municipios` VALUES (25324, 'Guataquí', 25);
INSERT INTO `municipios` VALUES (25326, 'Guatavita', 25);
INSERT INTO `municipios` VALUES (25328, 'Guayabal de Siquima', 25);
INSERT INTO `municipios` VALUES (25335, 'Guayabetal', 25);
INSERT INTO `municipios` VALUES (25339, 'Gutiérrez', 25);
INSERT INTO `municipios` VALUES (25368, 'Jerusalén', 25);
INSERT INTO `municipios` VALUES (25372, 'Junín', 25);
INSERT INTO `municipios` VALUES (25377, 'La Calera', 25);
INSERT INTO `municipios` VALUES (25386, 'La Mesa', 25);
INSERT INTO `municipios` VALUES (25394, 'La Palma', 25);
INSERT INTO `municipios` VALUES (25398, 'La Peña', 25);
INSERT INTO `municipios` VALUES (25402, 'La Vega', 25);
INSERT INTO `municipios` VALUES (25407, 'Lenguazaque', 25);
INSERT INTO `municipios` VALUES (25426, 'Machetá', 25);
INSERT INTO `municipios` VALUES (25430, 'Madrid', 25);
INSERT INTO `municipios` VALUES (25436, 'Manta', 25);
INSERT INTO `municipios` VALUES (25438, 'Medina', 25);
INSERT INTO `municipios` VALUES (25473, 'Mosquera', 25);
INSERT INTO `municipios` VALUES (25483, 'Nariño', 25);
INSERT INTO `municipios` VALUES (25486, 'Nemocón', 25);
INSERT INTO `municipios` VALUES (25488, 'Nilo', 25);
INSERT INTO `municipios` VALUES (25489, 'Nimaima', 25);
INSERT INTO `municipios` VALUES (25491, 'Nocaima', 25);
INSERT INTO `municipios` VALUES (25506, 'Venecia (Ospina Pérez)', 25);
INSERT INTO `municipios` VALUES (25513, 'Pacho', 25);
INSERT INTO `municipios` VALUES (25518, 'Paime', 25);
INSERT INTO `municipios` VALUES (25524, 'Pandi', 25);
INSERT INTO `municipios` VALUES (25530, 'Paratebueno', 25);
INSERT INTO `municipios` VALUES (25535, 'Pasca', 25);
INSERT INTO `municipios` VALUES (25572, 'Puerto Salgar', 25);
INSERT INTO `municipios` VALUES (25580, 'Pulí', 25);
INSERT INTO `municipios` VALUES (25592, 'Quebradanegra', 25);
INSERT INTO `municipios` VALUES (25594, 'Quetame', 25);
INSERT INTO `municipios` VALUES (25596, 'Quipile', 25);
INSERT INTO `municipios` VALUES (25599, 'Apulo', 25);
INSERT INTO `municipios` VALUES (25612, 'Ricaurte', 25);
INSERT INTO `municipios` VALUES (25645, 'San Antonio de Tequendama', 25);
INSERT INTO `municipios` VALUES (25649, 'San Bernardo', 25);
INSERT INTO `municipios` VALUES (25653, 'San Cayetano', 25);
INSERT INTO `municipios` VALUES (25658, 'San Francisco', 25);
INSERT INTO `municipios` VALUES (25662, 'San Juan de Río Seco', 25);
INSERT INTO `municipios` VALUES (25718, 'Sasaima', 25);
INSERT INTO `municipios` VALUES (25736, 'Sesquilé', 25);
INSERT INTO `municipios` VALUES (25740, 'Sibaté', 25);
INSERT INTO `municipios` VALUES (25743, 'Silvania', 25);
INSERT INTO `municipios` VALUES (25745, 'Simijaca', 25);
INSERT INTO `municipios` VALUES (25754, 'Soacha', 25);
INSERT INTO `municipios` VALUES (25758, 'Sopó', 25);
INSERT INTO `municipios` VALUES (25769, 'Subachoque', 25);
INSERT INTO `municipios` VALUES (25772, 'Suesca', 25);
INSERT INTO `municipios` VALUES (25777, 'Supatá', 25);
INSERT INTO `municipios` VALUES (25779, 'Susa', 25);
INSERT INTO `municipios` VALUES (25781, 'Sutatausa', 25);
INSERT INTO `municipios` VALUES (25785, 'Tabio', 25);
INSERT INTO `municipios` VALUES (25793, 'Tausa', 25);
INSERT INTO `municipios` VALUES (25797, 'Tena', 25);
INSERT INTO `municipios` VALUES (25799, 'Tenjo', 25);
INSERT INTO `municipios` VALUES (25805, 'Tibacuy', 25);
INSERT INTO `municipios` VALUES (25807, 'Tibirita', 25);
INSERT INTO `municipios` VALUES (25815, 'Tocaima', 25);
INSERT INTO `municipios` VALUES (25817, 'Tocancipá', 25);
INSERT INTO `municipios` VALUES (25823, 'Topaipí', 25);
INSERT INTO `municipios` VALUES (25839, 'Ubalá', 25);
INSERT INTO `municipios` VALUES (25841, 'Ubaque', 25);
INSERT INTO `municipios` VALUES (25843, 'Ubaté', 25);
INSERT INTO `municipios` VALUES (25845, 'Une', 25);
INSERT INTO `municipios` VALUES (25851, 'Útica', 25);
INSERT INTO `municipios` VALUES (25862, 'Vergara', 25);
INSERT INTO `municipios` VALUES (25867, 'Viani', 25);
INSERT INTO `municipios` VALUES (25871, 'Villagómez', 25);
INSERT INTO `municipios` VALUES (25873, 'Villapinzón', 25);
INSERT INTO `municipios` VALUES (25875, 'Villeta', 25);
INSERT INTO `municipios` VALUES (25878, 'Viotá', 25);
INSERT INTO `municipios` VALUES (25885, 'Yacopí', 25);
INSERT INTO `municipios` VALUES (25888, 'Zipacón', 25);
INSERT INTO `municipios` VALUES (25899, 'Zipaquirá', 25);
INSERT INTO `municipios` VALUES (27001, 'Quibdó', 27);
INSERT INTO `municipios` VALUES (27006, 'Acandí', 27);
INSERT INTO `municipios` VALUES (27025, 'Alto Baudó (Pie de Pato)', 27);
INSERT INTO `municipios` VALUES (27050, 'Atrato (Yuto)', 27);
INSERT INTO `municipios` VALUES (27073, 'Bagadó', 27);
INSERT INTO `municipios` VALUES (27075, 'Bahía Solano (Mútis)', 27);
INSERT INTO `municipios` VALUES (27077, 'Bajo Baudó (Pizarro)', 27);
INSERT INTO `municipios` VALUES (27086, 'Belén de Bajirá', 27);
INSERT INTO `municipios` VALUES (27099, 'Bojayá (Bellavista)', 27);
INSERT INTO `municipios` VALUES (27135, 'Cantón de San Pablo', 27);
INSERT INTO `municipios` VALUES (27150, 'Carmen del Darién (CURBARADÓ)', 27);
INSERT INTO `municipios` VALUES (27160, 'Cértegui', 27);
INSERT INTO `municipios` VALUES (27205, 'Condoto', 27);
INSERT INTO `municipios` VALUES (27245, 'El Carmen de Atrato', 27);
INSERT INTO `municipios` VALUES (27250, 'Santa Genoveva de Docorodó', 27);
INSERT INTO `municipios` VALUES (27361, 'Istmina', 27);
INSERT INTO `municipios` VALUES (27372, 'Juradó', 27);
INSERT INTO `municipios` VALUES (27413, 'Lloró', 27);
INSERT INTO `municipios` VALUES (27425, 'Medio Atrato', 27);
INSERT INTO `municipios` VALUES (27430, 'Medio Baudó', 27);
INSERT INTO `municipios` VALUES (27450, 'Medio San Juan (ANDAGOYA)', 27);
INSERT INTO `municipios` VALUES (27491, 'Novita', 27);
INSERT INTO `municipios` VALUES (27495, 'Nuquí', 27);
INSERT INTO `municipios` VALUES (27580, 'Río Iró', 27);
INSERT INTO `municipios` VALUES (27600, 'Río Quito', 27);
INSERT INTO `municipios` VALUES (27615, 'Ríosucio', 27);
INSERT INTO `municipios` VALUES (27660, 'San José del Palmar', 27);
INSERT INTO `municipios` VALUES (27745, 'Sipí', 27);
INSERT INTO `municipios` VALUES (27787, 'Tadó', 27);
INSERT INTO `municipios` VALUES (27800, 'Unguía', 27);
INSERT INTO `municipios` VALUES (27810, 'Unión Panamericana (ÁNIMAS)', 27);
INSERT INTO `municipios` VALUES (41001, 'Neiva', 41);
INSERT INTO `municipios` VALUES (41006, 'Acevedo', 41);
INSERT INTO `municipios` VALUES (41013, 'Agrado', 41);
INSERT INTO `municipios` VALUES (41016, 'Aipe', 41);
INSERT INTO `municipios` VALUES (41020, 'Algeciras', 41);
INSERT INTO `municipios` VALUES (41026, 'Altamira', 41);
INSERT INTO `municipios` VALUES (41078, 'Baraya', 41);
INSERT INTO `municipios` VALUES (41132, 'Campoalegre', 41);
INSERT INTO `municipios` VALUES (41206, 'Colombia', 41);
INSERT INTO `municipios` VALUES (41244, 'Elías', 41);
INSERT INTO `municipios` VALUES (41298, 'Garzón', 41);
INSERT INTO `municipios` VALUES (41306, 'Gigante', 41);
INSERT INTO `municipios` VALUES (41319, 'Guadalupe', 41);
INSERT INTO `municipios` VALUES (41349, 'Hobo', 41);
INSERT INTO `municipios` VALUES (41357, 'Íquira', 41);
INSERT INTO `municipios` VALUES (41359, 'Isnos', 41);
INSERT INTO `municipios` VALUES (41378, 'La Argentina', 41);
INSERT INTO `municipios` VALUES (41396, 'La Plata', 41);
INSERT INTO `municipios` VALUES (41483, 'Nátaga', 41);
INSERT INTO `municipios` VALUES (41503, 'Oporapa', 41);
INSERT INTO `municipios` VALUES (41518, 'Paicol', 41);
INSERT INTO `municipios` VALUES (41524, 'Palermo', 41);
INSERT INTO `municipios` VALUES (41530, 'Palestina', 41);
INSERT INTO `municipios` VALUES (41548, 'Pital', 41);
INSERT INTO `municipios` VALUES (41551, 'Pitalito', 41);
INSERT INTO `municipios` VALUES (41615, 'Rivera', 41);
INSERT INTO `municipios` VALUES (41660, 'Saladoblanco', 41);
INSERT INTO `municipios` VALUES (41668, 'San Agustín', 41);
INSERT INTO `municipios` VALUES (41676, 'Santa María', 41);
INSERT INTO `municipios` VALUES (41770, 'Suaza', 41);
INSERT INTO `municipios` VALUES (41791, 'Tarqui', 41);
INSERT INTO `municipios` VALUES (41797, 'Tesalia', 41);
INSERT INTO `municipios` VALUES (41799, 'Tello', 41);
INSERT INTO `municipios` VALUES (41801, 'Teruel', 41);
INSERT INTO `municipios` VALUES (41807, 'Timaná', 41);
INSERT INTO `municipios` VALUES (41872, 'Villavieja', 41);
INSERT INTO `municipios` VALUES (41885, 'Yaguará', 41);
INSERT INTO `municipios` VALUES (44001, 'Riohacha', 44);
INSERT INTO `municipios` VALUES (44035, 'Albania', 44);
INSERT INTO `municipios` VALUES (44078, 'Barrancas', 44);
INSERT INTO `municipios` VALUES (44090, 'Dibulla', 44);
INSERT INTO `municipios` VALUES (44098, 'Distracción', 44);
INSERT INTO `municipios` VALUES (44110, 'El Molino', 44);
INSERT INTO `municipios` VALUES (44279, 'Fonseca', 44);
INSERT INTO `municipios` VALUES (44378, 'Hatonuevo', 44);
INSERT INTO `municipios` VALUES (44420, 'La Jagua del Pilar', 44);
INSERT INTO `municipios` VALUES (44430, 'Maicao', 44);
INSERT INTO `municipios` VALUES (44560, 'Manaure', 44);
INSERT INTO `municipios` VALUES (44650, 'San Juan del Cesar', 44);
INSERT INTO `municipios` VALUES (44847, 'Uribia', 44);
INSERT INTO `municipios` VALUES (44855, 'Urumita', 44);
INSERT INTO `municipios` VALUES (44874, 'Villanueva', 44);
INSERT INTO `municipios` VALUES (47001, 'Santa Marta', 47);
INSERT INTO `municipios` VALUES (47030, 'Algarrobo', 47);
INSERT INTO `municipios` VALUES (47053, 'Aracataca', 47);
INSERT INTO `municipios` VALUES (47058, 'Ariguaní (El Difícil)', 47);
INSERT INTO `municipios` VALUES (47161, 'Cerro San Antonio', 47);
INSERT INTO `municipios` VALUES (47170, 'Chivolo', 47);
INSERT INTO `municipios` VALUES (47189, 'Ciénaga', 47);
INSERT INTO `municipios` VALUES (47205, 'Concordia', 47);
INSERT INTO `municipios` VALUES (47245, 'El Banco', 47);
INSERT INTO `municipios` VALUES (47258, 'El Piñon', 47);
INSERT INTO `municipios` VALUES (47268, 'El Retén', 47);
INSERT INTO `municipios` VALUES (47288, 'Fundación', 47);
INSERT INTO `municipios` VALUES (47318, 'Guamal', 47);
INSERT INTO `municipios` VALUES (47441, 'Pedraza', 47);
INSERT INTO `municipios` VALUES (47460, 'Nueva Granada', 47);
INSERT INTO `municipios` VALUES (47545, 'Pijiño', 47);
INSERT INTO `municipios` VALUES (47551, 'Pivijay', 47);
INSERT INTO `municipios` VALUES (47555, 'Plato', 47);
INSERT INTO `municipios` VALUES (47570, 'Puebloviejo', 47);
INSERT INTO `municipios` VALUES (47605, 'Remolino', 47);
INSERT INTO `municipios` VALUES (47660, 'Sabanas de San Angel (SAN ANGEL)', 47);
INSERT INTO `municipios` VALUES (47675, 'Salamina', 47);
INSERT INTO `municipios` VALUES (47692, 'San Sebastián de Buenavista', 47);
INSERT INTO `municipios` VALUES (47703, 'San Zenón', 47);
INSERT INTO `municipios` VALUES (47707, 'Santa Ana', 47);
INSERT INTO `municipios` VALUES (47720, 'Santa Bárbara de Pinto', 47);
INSERT INTO `municipios` VALUES (47745, 'Sitionuevo', 47);
INSERT INTO `municipios` VALUES (47798, 'Tenerife', 47);
INSERT INTO `municipios` VALUES (47960, 'Zapayán (PUNTA DE PIEDRAS)', 47);
INSERT INTO `municipios` VALUES (47980, 'Zona Bananera (PRADO - SEVILLA)', 47);
INSERT INTO `municipios` VALUES (50001, 'Villavicencio', 50);
INSERT INTO `municipios` VALUES (50006, 'Acacías', 50);
INSERT INTO `municipios` VALUES (50110, 'Barranca de Upía', 50);
INSERT INTO `municipios` VALUES (50124, 'Cabuyaro', 50);
INSERT INTO `municipios` VALUES (50150, 'Castilla la Nueva', 50);
INSERT INTO `municipios` VALUES (50223, 'Cubarral', 50);
INSERT INTO `municipios` VALUES (50226, 'Cumaral', 50);
INSERT INTO `municipios` VALUES (50245, 'El Calvario', 50);
INSERT INTO `municipios` VALUES (50251, 'El Castillo', 50);
INSERT INTO `municipios` VALUES (50270, 'El Dorado', 50);
INSERT INTO `municipios` VALUES (50287, 'Fuente de Oro', 50);
INSERT INTO `municipios` VALUES (50313, 'Granada', 50);
INSERT INTO `municipios` VALUES (50318, 'Guamal', 50);
INSERT INTO `municipios` VALUES (50325, 'Mapiripan', 50);
INSERT INTO `municipios` VALUES (50330, 'Mesetas', 50);
INSERT INTO `municipios` VALUES (50350, 'La Macarena', 50);
INSERT INTO `municipios` VALUES (50370, 'Uribe', 50);
INSERT INTO `municipios` VALUES (50400, 'Lejanías', 50);
INSERT INTO `municipios` VALUES (50450, 'Puerto Concordia', 50);
INSERT INTO `municipios` VALUES (50568, 'Puerto Gaitán', 50);
INSERT INTO `municipios` VALUES (50573, 'Puerto López', 50);
INSERT INTO `municipios` VALUES (50577, 'Puerto Lleras', 50);
INSERT INTO `municipios` VALUES (50590, 'Puerto Rico', 50);
INSERT INTO `municipios` VALUES (50606, 'Restrepo', 50);
INSERT INTO `municipios` VALUES (50680, 'San Carlos de Guaroa', 50);
INSERT INTO `municipios` VALUES (50683, 'San Juan de Arama', 50);
INSERT INTO `municipios` VALUES (50686, 'San Juanito', 50);
INSERT INTO `municipios` VALUES (50689, 'San Martín', 50);
INSERT INTO `municipios` VALUES (50711, 'Vista Hermosa', 50);
INSERT INTO `municipios` VALUES (52001, 'San Juan de Pasto', 52);
INSERT INTO `municipios` VALUES (52019, 'Albán (San José)', 52);
INSERT INTO `municipios` VALUES (52022, 'Aldana', 52);
INSERT INTO `municipios` VALUES (52036, 'Ancuya', 52);
INSERT INTO `municipios` VALUES (52051, 'Arboleda (Berruecos)', 52);
INSERT INTO `municipios` VALUES (52079, 'Barbacoas', 52);
INSERT INTO `municipios` VALUES (52083, 'Belén', 52);
INSERT INTO `municipios` VALUES (52110, 'Buesaco', 52);
INSERT INTO `municipios` VALUES (52203, 'Colón (Génova)', 52);
INSERT INTO `municipios` VALUES (52207, 'Consaca', 52);
INSERT INTO `municipios` VALUES (52210, 'Contadero', 52);
INSERT INTO `municipios` VALUES (52215, 'Córdoba', 52);
INSERT INTO `municipios` VALUES (52224, 'Cuaspud (Carlosama)', 52);
INSERT INTO `municipios` VALUES (52227, 'Cumbal', 52);
INSERT INTO `municipios` VALUES (52233, 'Cumbitara', 52);
INSERT INTO `municipios` VALUES (52240, 'Chachaguí', 52);
INSERT INTO `municipios` VALUES (52250, 'El Charco', 52);
INSERT INTO `municipios` VALUES (52254, 'El Peñol', 52);
INSERT INTO `municipios` VALUES (52256, 'El Rosario', 52);
INSERT INTO `municipios` VALUES (52258, 'El Tablón de Gómez', 52);
INSERT INTO `municipios` VALUES (52260, 'El Tambo', 52);
INSERT INTO `municipios` VALUES (52287, 'Funes', 52);
INSERT INTO `municipios` VALUES (52317, 'Guachucal', 52);
INSERT INTO `municipios` VALUES (52320, 'Guaitarilla', 52);
INSERT INTO `municipios` VALUES (52323, 'Gualmatán', 52);
INSERT INTO `municipios` VALUES (52352, 'Iles', 52);
INSERT INTO `municipios` VALUES (52354, 'Imúes', 52);
INSERT INTO `municipios` VALUES (52356, 'Ipiales', 52);
INSERT INTO `municipios` VALUES (52378, 'La Cruz', 52);
INSERT INTO `municipios` VALUES (52381, 'La Florida', 52);
INSERT INTO `municipios` VALUES (52385, 'La Llanada', 52);
INSERT INTO `municipios` VALUES (52390, 'La Tola', 52);
INSERT INTO `municipios` VALUES (52399, 'La Unión', 52);
INSERT INTO `municipios` VALUES (52405, 'Leiva', 52);
INSERT INTO `municipios` VALUES (52411, 'Linares', 52);
INSERT INTO `municipios` VALUES (52418, 'Sotomayor (Los Andes)', 52);
INSERT INTO `municipios` VALUES (52427, 'Magüi (Payán)', 52);
INSERT INTO `municipios` VALUES (52435, 'Mallama (Piedrancha)', 52);
INSERT INTO `municipios` VALUES (52473, 'Mosquera', 52);
INSERT INTO `municipios` VALUES (52480, 'Nariño', 52);
INSERT INTO `municipios` VALUES (52490, 'Olaya Herrera', 52);
INSERT INTO `municipios` VALUES (52506, 'Ospina', 52);
INSERT INTO `municipios` VALUES (52520, 'Francisco Pizarro', 52);
INSERT INTO `municipios` VALUES (52540, 'Policarpa', 52);
INSERT INTO `municipios` VALUES (52560, 'Potosí', 52);
INSERT INTO `municipios` VALUES (52565, 'Providencia', 52);
INSERT INTO `municipios` VALUES (52573, 'Puerres', 52);
INSERT INTO `municipios` VALUES (52585, 'Pupiales', 52);
INSERT INTO `municipios` VALUES (52612, 'Ricaurte', 52);
INSERT INTO `municipios` VALUES (52621, 'Roberto Payán (San José)', 52);
INSERT INTO `municipios` VALUES (52678, 'Samaniego', 52);
INSERT INTO `municipios` VALUES (52683, 'Sandoná', 52);
INSERT INTO `municipios` VALUES (52685, 'San Bernardo', 52);
INSERT INTO `municipios` VALUES (52687, 'San Lorenzo', 52);
INSERT INTO `municipios` VALUES (52693, 'San Pablo', 52);
INSERT INTO `municipios` VALUES (52694, 'San Pedro de Cartago', 52);
INSERT INTO `municipios` VALUES (52695, 'Santa Bárbara (Iscuandé)', 52);
INSERT INTO `municipios` VALUES (52699, 'Guachavés', 52);
INSERT INTO `municipios` VALUES (52720, 'Sapuyes', 52);
INSERT INTO `municipios` VALUES (52786, 'Taminango', 52);
INSERT INTO `municipios` VALUES (52788, 'Tangua', 52);
INSERT INTO `municipios` VALUES (52835, 'Tumaco', 52);
INSERT INTO `municipios` VALUES (52838, 'Túquerres', 52);
INSERT INTO `municipios` VALUES (52885, 'Yacuanquer', 52);
INSERT INTO `municipios` VALUES (54001, 'Cúcuta', 54);
INSERT INTO `municipios` VALUES (54003, 'Ábrego', 54);
INSERT INTO `municipios` VALUES (54051, 'Arboledas', 54);
INSERT INTO `municipios` VALUES (54099, 'Bochalema', 54);
INSERT INTO `municipios` VALUES (54109, 'Bucarasica', 54);
INSERT INTO `municipios` VALUES (54125, 'Cácota', 54);
INSERT INTO `municipios` VALUES (54128, 'Cáchira', 54);
INSERT INTO `municipios` VALUES (54172, 'Chinácota', 54);
INSERT INTO `municipios` VALUES (54174, 'Chitagá', 54);
INSERT INTO `municipios` VALUES (54206, 'Convención', 54);
INSERT INTO `municipios` VALUES (54223, 'Cucutilla', 54);
INSERT INTO `municipios` VALUES (54239, 'Durania', 54);
INSERT INTO `municipios` VALUES (54245, 'El Carmen', 54);
INSERT INTO `municipios` VALUES (54250, 'El Tarra', 54);
INSERT INTO `municipios` VALUES (54261, 'El Zulia', 54);
INSERT INTO `municipios` VALUES (54313, 'Gramalote', 54);
INSERT INTO `municipios` VALUES (54344, 'Hacarí', 54);
INSERT INTO `municipios` VALUES (54347, 'Herrán', 54);
INSERT INTO `municipios` VALUES (54377, 'Labateca', 54);
INSERT INTO `municipios` VALUES (54385, 'La Esperanza', 54);
INSERT INTO `municipios` VALUES (54398, 'La Playa', 54);
INSERT INTO `municipios` VALUES (54405, 'Los Patios', 54);
INSERT INTO `municipios` VALUES (54418, 'Lourdes', 54);
INSERT INTO `municipios` VALUES (54480, 'Mutiscua', 54);
INSERT INTO `municipios` VALUES (54498, 'Ocaña', 54);
INSERT INTO `municipios` VALUES (54518, 'Pamplona', 54);
INSERT INTO `municipios` VALUES (54520, 'Pamplonita', 54);
INSERT INTO `municipios` VALUES (54553, 'Puerto Santander', 54);
INSERT INTO `municipios` VALUES (54599, 'Ragonvalia', 54);
INSERT INTO `municipios` VALUES (54660, 'Salazar', 54);
INSERT INTO `municipios` VALUES (54670, 'San Calixto', 54);
INSERT INTO `municipios` VALUES (54673, 'San Cayetano', 54);
INSERT INTO `municipios` VALUES (54680, 'Santiago', 54);
INSERT INTO `municipios` VALUES (54720, 'Sardinata', 54);
INSERT INTO `municipios` VALUES (54743, 'Silos', 54);
INSERT INTO `municipios` VALUES (54800, 'Teorama', 54);
INSERT INTO `municipios` VALUES (54810, 'Tibú', 54);
INSERT INTO `municipios` VALUES (54820, 'Toledo', 54);
INSERT INTO `municipios` VALUES (54871, 'Villa Caro', 54);
INSERT INTO `municipios` VALUES (54874, 'Villa del Rosario', 54);
INSERT INTO `municipios` VALUES (63001, 'Armenia', 63);
INSERT INTO `municipios` VALUES (63111, 'Buenavista', 63);
INSERT INTO `municipios` VALUES (63130, 'Calarcá', 63);
INSERT INTO `municipios` VALUES (63190, 'Circasia', 63);
INSERT INTO `municipios` VALUES (63212, 'Cordobá', 63);
INSERT INTO `municipios` VALUES (63272, 'Filandia', 63);
INSERT INTO `municipios` VALUES (63302, 'Génova', 63);
INSERT INTO `municipios` VALUES (63401, 'La Tebaida', 63);
INSERT INTO `municipios` VALUES (63470, 'Montenegro', 63);
INSERT INTO `municipios` VALUES (63548, 'Pijao', 63);
INSERT INTO `municipios` VALUES (63594, 'Quimbaya', 63);
INSERT INTO `municipios` VALUES (63690, 'Salento', 63);
INSERT INTO `municipios` VALUES (66001, 'Pereira', 66);
INSERT INTO `municipios` VALUES (66045, 'Apía', 66);
INSERT INTO `municipios` VALUES (66075, 'Balboa', 66);
INSERT INTO `municipios` VALUES (66088, 'Belén de Umbría', 66);
INSERT INTO `municipios` VALUES (66170, 'Dos Quebradas', 66);
INSERT INTO `municipios` VALUES (66318, 'Guática', 66);
INSERT INTO `municipios` VALUES (66383, 'La Celia', 66);
INSERT INTO `municipios` VALUES (66400, 'La Virginia', 66);
INSERT INTO `municipios` VALUES (66440, 'Marsella', 66);
INSERT INTO `municipios` VALUES (66456, 'Mistrató', 66);
INSERT INTO `municipios` VALUES (66572, 'Pueblo Rico', 66);
INSERT INTO `municipios` VALUES (66594, 'Quinchía', 66);
INSERT INTO `municipios` VALUES (66682, 'Santa Rosa de Cabal', 66);
INSERT INTO `municipios` VALUES (66687, 'Santuario', 66);
INSERT INTO `municipios` VALUES (68001, 'Bucaramanga', 68);
INSERT INTO `municipios` VALUES (68013, 'Aguada', 68);
INSERT INTO `municipios` VALUES (68020, 'Albania', 68);
INSERT INTO `municipios` VALUES (68051, 'Aratoca', 68);
INSERT INTO `municipios` VALUES (68077, 'Barbosa', 68);
INSERT INTO `municipios` VALUES (68079, 'Barichara', 68);
INSERT INTO `municipios` VALUES (68081, 'Barrancabermeja', 68);
INSERT INTO `municipios` VALUES (68092, 'Betulia', 68);
INSERT INTO `municipios` VALUES (68101, 'Bolívar', 68);
INSERT INTO `municipios` VALUES (68121, 'Cabrera', 68);
INSERT INTO `municipios` VALUES (68132, 'California', 68);
INSERT INTO `municipios` VALUES (68147, 'Capitanejo', 68);
INSERT INTO `municipios` VALUES (68152, 'Carcasí', 68);
INSERT INTO `municipios` VALUES (68160, 'Cepita', 68);
INSERT INTO `municipios` VALUES (68162, 'Cerrito', 68);
INSERT INTO `municipios` VALUES (68167, 'Charalá', 68);
INSERT INTO `municipios` VALUES (68169, 'Charta', 68);
INSERT INTO `municipios` VALUES (68176, 'Chima', 68);
INSERT INTO `municipios` VALUES (68179, 'Chipatá', 68);
INSERT INTO `municipios` VALUES (68190, 'Cimitarra', 68);
INSERT INTO `municipios` VALUES (68207, 'Concepción', 68);
INSERT INTO `municipios` VALUES (68209, 'Confines', 68);
INSERT INTO `municipios` VALUES (68211, 'Contratación', 68);
INSERT INTO `municipios` VALUES (68217, 'Coromoro', 68);
INSERT INTO `municipios` VALUES (68229, 'Curití', 68);
INSERT INTO `municipios` VALUES (68235, 'El Carmen', 68);
INSERT INTO `municipios` VALUES (68245, 'El Guacamayo', 68);
INSERT INTO `municipios` VALUES (68250, 'El Peñon', 68);
INSERT INTO `municipios` VALUES (68255, 'El Playón', 68);
INSERT INTO `municipios` VALUES (68264, 'Encino', 68);
INSERT INTO `municipios` VALUES (68266, 'Enciso', 68);
INSERT INTO `municipios` VALUES (68271, 'Florián', 68);
INSERT INTO `municipios` VALUES (68276, 'Floridablanca', 68);
INSERT INTO `municipios` VALUES (68296, 'Galán', 68);
INSERT INTO `municipios` VALUES (68298, 'Gámbita', 68);
INSERT INTO `municipios` VALUES (68306, 'Girón', 68);
INSERT INTO `municipios` VALUES (68318, 'Guaca', 68);
INSERT INTO `municipios` VALUES (68320, 'Guadalupe', 68);
INSERT INTO `municipios` VALUES (68322, 'Guapota', 68);
INSERT INTO `municipios` VALUES (68324, 'Guavatá', 68);
INSERT INTO `municipios` VALUES (68327, 'Guepsa', 68);
INSERT INTO `municipios` VALUES (68344, 'Hato', 68);
INSERT INTO `municipios` VALUES (68368, 'Jesús María', 68);
INSERT INTO `municipios` VALUES (68370, 'Jordán', 68);
INSERT INTO `municipios` VALUES (68377, 'La Belleza', 68);
INSERT INTO `municipios` VALUES (68385, 'Landázuri', 68);
INSERT INTO `municipios` VALUES (68397, 'La Paz', 68);
INSERT INTO `municipios` VALUES (68406, 'Lebrija', 68);
INSERT INTO `municipios` VALUES (68418, 'Los Santos', 68);
INSERT INTO `municipios` VALUES (68425, 'Macaravita', 68);
INSERT INTO `municipios` VALUES (68432, 'Málaga', 68);
INSERT INTO `municipios` VALUES (68444, 'Matanza', 68);
INSERT INTO `municipios` VALUES (68464, 'Mogotes', 68);
INSERT INTO `municipios` VALUES (68468, 'Molagavita', 68);
INSERT INTO `municipios` VALUES (68498, 'Ocamonte', 68);
INSERT INTO `municipios` VALUES (68500, 'Oiba', 68);
INSERT INTO `municipios` VALUES (68502, 'Onzaga', 68);
INSERT INTO `municipios` VALUES (68522, 'Palmar', 68);
INSERT INTO `municipios` VALUES (68524, 'Palmas del Socorro', 68);
INSERT INTO `municipios` VALUES (68533, 'Páramo', 68);
INSERT INTO `municipios` VALUES (68547, 'Pie de Cuesta', 68);
INSERT INTO `municipios` VALUES (68549, 'Pinchote', 68);
INSERT INTO `municipios` VALUES (68572, 'Puente Nacional', 68);
INSERT INTO `municipios` VALUES (68573, 'Puerto Parra', 68);
INSERT INTO `municipios` VALUES (68575, 'Puerto Wilches', 68);
INSERT INTO `municipios` VALUES (68615, 'Rio Negro', 68);
INSERT INTO `municipios` VALUES (68655, 'Sabana de Torres', 68);
INSERT INTO `municipios` VALUES (68669, 'San Andrés', 68);
INSERT INTO `municipios` VALUES (68673, 'San Benito', 68);
INSERT INTO `municipios` VALUES (68679, 'San Gíl', 68);
INSERT INTO `municipios` VALUES (68682, 'San Joaquín', 68);
INSERT INTO `municipios` VALUES (68684, 'San Miguel', 68);
INSERT INTO `municipios` VALUES (68686, 'San José de Miranda', 68);
INSERT INTO `municipios` VALUES (68689, 'San Vicente del Chucurí', 68);
INSERT INTO `municipios` VALUES (68705, 'Santa Bárbara', 68);
INSERT INTO `municipios` VALUES (68720, 'Santa Helena del Opón', 68);
INSERT INTO `municipios` VALUES (68745, 'Simacota', 68);
INSERT INTO `municipios` VALUES (68755, 'Socorro', 68);
INSERT INTO `municipios` VALUES (68770, 'Suaita', 68);
INSERT INTO `municipios` VALUES (68773, 'Sucre', 68);
INSERT INTO `municipios` VALUES (68780, 'Suratá', 68);
INSERT INTO `municipios` VALUES (68820, 'Tona', 68);
INSERT INTO `municipios` VALUES (68855, 'Valle de San José', 68);
INSERT INTO `municipios` VALUES (68861, 'Vélez', 68);
INSERT INTO `municipios` VALUES (68867, 'Vetas', 68);
INSERT INTO `municipios` VALUES (68872, 'Villanueva', 68);
INSERT INTO `municipios` VALUES (68895, 'Zapatoca', 68);
INSERT INTO `municipios` VALUES (70001, 'Sincelejo', 70);
INSERT INTO `municipios` VALUES (70110, 'Buenavista', 70);
INSERT INTO `municipios` VALUES (70124, 'Caimito', 70);
INSERT INTO `municipios` VALUES (70204, 'Colosó (Ricaurte)', 70);
INSERT INTO `municipios` VALUES (70215, 'Corozal', 70);
INSERT INTO `municipios` VALUES (70221, 'Coveñas', 70);
INSERT INTO `municipios` VALUES (70230, 'Chalán', 70);
INSERT INTO `municipios` VALUES (70233, 'El Roble', 70);
INSERT INTO `municipios` VALUES (70235, 'Galeras (Nueva Granada)', 70);
INSERT INTO `municipios` VALUES (70265, 'Guaranda', 70);
INSERT INTO `municipios` VALUES (70400, 'La Unión', 70);
INSERT INTO `municipios` VALUES (70418, 'Los Palmitos', 70);
INSERT INTO `municipios` VALUES (70429, 'Majagual', 70);
INSERT INTO `municipios` VALUES (70473, 'Morroa', 70);
INSERT INTO `municipios` VALUES (70508, 'Ovejas', 70);
INSERT INTO `municipios` VALUES (70523, 'Palmito', 70);
INSERT INTO `municipios` VALUES (70670, 'Sampués', 70);
INSERT INTO `municipios` VALUES (70678, 'San Benito Abad', 70);
INSERT INTO `municipios` VALUES (70702, 'San Juan de Betulia', 70);
INSERT INTO `municipios` VALUES (70708, 'San Marcos', 70);
INSERT INTO `municipios` VALUES (70713, 'San Onofre', 70);
INSERT INTO `municipios` VALUES (70717, 'San Pedro', 70);
INSERT INTO `municipios` VALUES (70742, 'Sincé', 70);
INSERT INTO `municipios` VALUES (70771, 'Sucre', 70);
INSERT INTO `municipios` VALUES (70820, 'Tolú', 70);
INSERT INTO `municipios` VALUES (70823, 'Tolú Viejo', 70);
INSERT INTO `municipios` VALUES (73001, 'Ibagué', 73);
INSERT INTO `municipios` VALUES (73024, 'Alpujarra', 73);
INSERT INTO `municipios` VALUES (73026, 'Alvarado', 73);
INSERT INTO `municipios` VALUES (73030, 'Ambalema', 73);
INSERT INTO `municipios` VALUES (73043, 'Anzoátegui', 73);
INSERT INTO `municipios` VALUES (73055, 'Armero (Guayabal)', 73);
INSERT INTO `municipios` VALUES (73067, 'Ataco', 73);
INSERT INTO `municipios` VALUES (73124, 'Cajamarca', 73);
INSERT INTO `municipios` VALUES (73148, 'Carmen de Apicalá', 73);
INSERT INTO `municipios` VALUES (73152, 'Casabianca', 73);
INSERT INTO `municipios` VALUES (73168, 'Chaparral', 73);
INSERT INTO `municipios` VALUES (73200, 'Coello', 73);
INSERT INTO `municipios` VALUES (73217, 'Coyaima', 73);
INSERT INTO `municipios` VALUES (73226, 'Cunday', 73);
INSERT INTO `municipios` VALUES (73236, 'Dolores', 73);
INSERT INTO `municipios` VALUES (73268, 'Espinal', 73);
INSERT INTO `municipios` VALUES (73270, 'Falan', 73);
INSERT INTO `municipios` VALUES (73275, 'Flandes', 73);
INSERT INTO `municipios` VALUES (73283, 'Fresno', 73);
INSERT INTO `municipios` VALUES (73319, 'Guamo', 73);
INSERT INTO `municipios` VALUES (73347, 'Herveo', 73);
INSERT INTO `municipios` VALUES (73349, 'Honda', 73);
INSERT INTO `municipios` VALUES (73352, 'Icononzo', 73);
INSERT INTO `municipios` VALUES (73408, 'Lérida', 73);
INSERT INTO `municipios` VALUES (73411, 'Líbano', 73);
INSERT INTO `municipios` VALUES (73443, 'Mariquita', 73);
INSERT INTO `municipios` VALUES (73449, 'Melgar', 73);
INSERT INTO `municipios` VALUES (73461, 'Murillo', 73);
INSERT INTO `municipios` VALUES (73483, 'Natagaima', 73);
INSERT INTO `municipios` VALUES (73504, 'Ortega', 73);
INSERT INTO `municipios` VALUES (73520, 'Palocabildo', 73);
INSERT INTO `municipios` VALUES (73547, 'Piedras', 73);
INSERT INTO `municipios` VALUES (73555, 'Planadas', 73);
INSERT INTO `municipios` VALUES (73563, 'Prado', 73);
INSERT INTO `municipios` VALUES (73585, 'Purificación', 73);
INSERT INTO `municipios` VALUES (73616, 'Rioblanco', 73);
INSERT INTO `municipios` VALUES (73622, 'Roncesvalles', 73);
INSERT INTO `municipios` VALUES (73624, 'Rovira', 73);
INSERT INTO `municipios` VALUES (73671, 'Saldaña', 73);
INSERT INTO `municipios` VALUES (73675, 'San Antonio', 73);
INSERT INTO `municipios` VALUES (73678, 'San Luis', 73);
INSERT INTO `municipios` VALUES (73686, 'Santa Isabel', 73);
INSERT INTO `municipios` VALUES (73770, 'Suárez', 73);
INSERT INTO `municipios` VALUES (73854, 'Valle de San Juan', 73);
INSERT INTO `municipios` VALUES (73861, 'Venadillo', 73);
INSERT INTO `municipios` VALUES (73870, 'Villahermosa', 73);
INSERT INTO `municipios` VALUES (73873, 'Villarrica', 73);
INSERT INTO `municipios` VALUES (76001, 'Calí', 76);
INSERT INTO `municipios` VALUES (76020, 'Alcalá', 76);
INSERT INTO `municipios` VALUES (76036, 'Andalucía', 76);
INSERT INTO `municipios` VALUES (76041, 'Ansermanuevo', 76);
INSERT INTO `municipios` VALUES (76054, 'Argelia', 76);
INSERT INTO `municipios` VALUES (76100, 'Bolívar', 76);
INSERT INTO `municipios` VALUES (76109, 'Buenaventura', 76);
INSERT INTO `municipios` VALUES (76111, 'Buga', 76);
INSERT INTO `municipios` VALUES (76113, 'Bugalagrande', 76);
INSERT INTO `municipios` VALUES (76122, 'Caicedonia', 76);
INSERT INTO `municipios` VALUES (76126, 'Calima (Darién)', 76);
INSERT INTO `municipios` VALUES (76130, 'Candelaria', 76);
INSERT INTO `municipios` VALUES (76147, 'Cartago', 76);
INSERT INTO `municipios` VALUES (76233, 'Dagua', 76);
INSERT INTO `municipios` VALUES (76243, 'El Águila', 76);
INSERT INTO `municipios` VALUES (76246, 'El Cairo', 76);
INSERT INTO `municipios` VALUES (76248, 'El Cerrito', 76);
INSERT INTO `municipios` VALUES (76250, 'El Dovio', 76);
INSERT INTO `municipios` VALUES (76275, 'Florida', 76);
INSERT INTO `municipios` VALUES (76306, 'Ginebra', 76);
INSERT INTO `municipios` VALUES (76318, 'Guacarí', 76);
INSERT INTO `municipios` VALUES (76364, 'Jamundí', 76);
INSERT INTO `municipios` VALUES (76400, 'La Unión', 76);
INSERT INTO `municipios` VALUES (76403, 'La Victoria', 76);
INSERT INTO `municipios` VALUES (76497, 'Obando', 76);
INSERT INTO `municipios` VALUES (76520, 'Palmira', 76);
INSERT INTO `municipios` VALUES (76563, 'Pradera', 76);
INSERT INTO `municipios` VALUES (76606, 'Restrepo', 76);
INSERT INTO `municipios` VALUES (76616, 'Riofrío', 76);
INSERT INTO `municipios` VALUES (76622, 'Roldanillo', 76);
INSERT INTO `municipios` VALUES (76670, 'San Pedro', 76);
INSERT INTO `municipios` VALUES (76677, 'La Cumbre', 76);
INSERT INTO `municipios` VALUES (76736, 'Sevilla', 76);
INSERT INTO `municipios` VALUES (76823, 'Toro', 76);
INSERT INTO `municipios` VALUES (76828, 'Trujillo', 76);
INSERT INTO `municipios` VALUES (76834, 'Tulúa', 76);
INSERT INTO `municipios` VALUES (76845, 'Ulloa', 76);
INSERT INTO `municipios` VALUES (76863, 'Versalles', 76);
INSERT INTO `municipios` VALUES (76869, 'Vijes', 76);
INSERT INTO `municipios` VALUES (76890, 'Yotoco', 76);
INSERT INTO `municipios` VALUES (76892, 'Yumbo', 76);
INSERT INTO `municipios` VALUES (76895, 'Zarzal', 76);
INSERT INTO `municipios` VALUES (81001, 'Arauca', 81);
INSERT INTO `municipios` VALUES (81065, 'Arauquita', 81);
INSERT INTO `municipios` VALUES (81220, 'Cravo Norte', 81);
INSERT INTO `municipios` VALUES (81300, 'Fortúl', 81);
INSERT INTO `municipios` VALUES (81591, 'Puerto Rondón', 81);
INSERT INTO `municipios` VALUES (81736, 'Saravena', 81);
INSERT INTO `municipios` VALUES (81794, 'Tame', 81);
INSERT INTO `municipios` VALUES (85001, 'Yopal', 85);
INSERT INTO `municipios` VALUES (85010, 'Aguazul', 85);
INSERT INTO `municipios` VALUES (85015, 'Chámeza', 85);
INSERT INTO `municipios` VALUES (85125, 'Hato Corozal', 85);
INSERT INTO `municipios` VALUES (85136, 'La Salina', 85);
INSERT INTO `municipios` VALUES (85139, 'Maní', 85);
INSERT INTO `municipios` VALUES (85162, 'Monterrey', 85);
INSERT INTO `municipios` VALUES (85225, 'Nunchía', 85);
INSERT INTO `municipios` VALUES (85230, 'Orocué', 85);
INSERT INTO `municipios` VALUES (85250, 'Paz de Ariporo', 85);
INSERT INTO `municipios` VALUES (85263, 'Pore', 85);
INSERT INTO `municipios` VALUES (85279, 'Recetor', 85);
INSERT INTO `municipios` VALUES (85300, 'Sabanalarga', 85);
INSERT INTO `municipios` VALUES (85315, 'Sácama', 85);
INSERT INTO `municipios` VALUES (85325, 'San Luís de Palenque', 85);
INSERT INTO `municipios` VALUES (85400, 'Támara', 85);
INSERT INTO `municipios` VALUES (85410, 'Tauramena', 85);
INSERT INTO `municipios` VALUES (85430, 'Trinidad', 85);
INSERT INTO `municipios` VALUES (85440, 'Villanueva', 85);
INSERT INTO `municipios` VALUES (86001, 'Mocoa', 86);
INSERT INTO `municipios` VALUES (86219, 'Colón', 86);
INSERT INTO `municipios` VALUES (86320, 'Orito', 86);
INSERT INTO `municipios` VALUES (86568, 'Puerto Asís', 86);
INSERT INTO `municipios` VALUES (86569, 'Puerto Caicedo', 86);
INSERT INTO `municipios` VALUES (86571, 'Puerto Guzmán', 86);
INSERT INTO `municipios` VALUES (86573, 'Puerto Leguízamo', 86);
INSERT INTO `municipios` VALUES (86749, 'Sibundoy', 86);
INSERT INTO `municipios` VALUES (86755, 'San Francisco', 86);
INSERT INTO `municipios` VALUES (86757, 'San Miguel', 86);
INSERT INTO `municipios` VALUES (86760, 'Santiago', 86);
INSERT INTO `municipios` VALUES (86865, 'Valle del Guamuez', 86);
INSERT INTO `municipios` VALUES (86885, 'Villagarzón', 86);
INSERT INTO `municipios` VALUES (88564, 'Providencia', 88);
INSERT INTO `municipios` VALUES (91001, 'Leticia', 91);
INSERT INTO `municipios` VALUES (91540, 'Puerto Nariño', 91);
INSERT INTO `municipios` VALUES (94001, 'Inírida', 94);
INSERT INTO `municipios` VALUES (95001, 'San José del Guaviare', 95);
INSERT INTO `municipios` VALUES (95015, 'Calamar', 95);
INSERT INTO `municipios` VALUES (95025, 'El Retorno', 95);
INSERT INTO `municipios` VALUES (95200, 'Miraflores', 95);
INSERT INTO `municipios` VALUES (97001, 'Mitú', 97);
INSERT INTO `municipios` VALUES (97161, 'Carurú', 97);
INSERT INTO `municipios` VALUES (97666, 'Taraira', 97);
INSERT INTO `municipios` VALUES (99001, 'Puerto Carreño', 99);
INSERT INTO `municipios` VALUES (99524, 'La Primavera', 99);
INSERT INTO `municipios` VALUES (99624, 'Santa Rosalía', 99);
INSERT INTO `municipios` VALUES (99773, 'Cumaribo', 99);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `paciente`
-- 

CREATE TABLE `paciente` (
  `idpersona` varchar(45) NOT NULL,
  `nombre` varchar(45) default NULL,
  `direccion` varchar(45) default NULL,
  `num_afiliacion` varchar(45) default NULL,
  `telefono` varchar(45) default NULL,
  `sexo` varchar(45) default NULL,
  `estadoCivil` varchar(45) default NULL,
  `fechaNacimiento` date default NULL,
  `municipios_codigo` int(11) NOT NULL,
  `profesiones_codigo` int(11) NOT NULL,
  PRIMARY KEY  (`idpersona`),
  KEY `fk_paciente_municipios1` (`municipios_codigo`),
  KEY `fk_paciente_profesiones1` (`profesiones_codigo`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Volcar la base de datos para la tabla `paciente`
-- 

INSERT INTO `paciente` VALUES ('1047565684', 'Pedro Jose Payares Mendez', 'Bocagrande Avenida san martin Nº 15 29', '104759568466', '6812555', 'masculino', 'soltero', '1986-02-24', 13001, 2135);
INSERT INTO `paciente` VALUES ('98765432', 'Juan gabriel', 'centro', '98765432', '6776767', 'masculino', 'casado', '2013-03-21', 13001, 311);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `plantratamiento`
-- 

CREATE TABLE `plantratamiento` (
  `idplanTratamiento` int(11) NOT NULL auto_increment,
  `nombre` varchar(45) default NULL,
  PRIMARY KEY  (`idplanTratamiento`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=11 ;

-- 
-- Volcar la base de datos para la tabla `plantratamiento`
-- 

INSERT INTO `plantratamiento` VALUES (1, 'Semiologia');
INSERT INTO `plantratamiento` VALUES (2, 'Promocion y Prevencion');
INSERT INTO `plantratamiento` VALUES (3, 'Operatoria');
INSERT INTO `plantratamiento` VALUES (4, 'Endodoncia');
INSERT INTO `plantratamiento` VALUES (5, 'Periodoncia');
INSERT INTO `plantratamiento` VALUES (6, 'Cirugia');
INSERT INTO `plantratamiento` VALUES (7, 'Odontopedriatia');
INSERT INTO `plantratamiento` VALUES (8, 'Rehabilitacion');
INSERT INTO `plantratamiento` VALUES (9, 'Ortodoncia');
INSERT INTO `plantratamiento` VALUES (10, 'Otros');

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `preparacionbiomedica`
-- 

CREATE TABLE `preparacionbiomedica` (
  `idpreparacionBiomedica` int(11) NOT NULL auto_increment,
  `canal` varchar(45) character set utf8 default NULL,
  `referencia` varchar(45) character set utf8 default NULL,
  `la` varchar(45) character set utf8 default NULL,
  `lri` varchar(45) character set utf8 default NULL,
  `lrt` varchar(45) character set utf8 default NULL,
  `instInicial` varchar(45) character set utf8 default NULL,
  `limaRetroceso` varchar(45) character set utf8 default NULL,
  `preApical` varchar(45) character set utf8 default NULL,
  `historiaClinica_idhistoriaClinica` int(11) NOT NULL,
  PRIMARY KEY  (`idpreparacionBiomedica`),
  KEY `fk_preparacionBiomedica_historiaClinica1` (`historiaClinica_idhistoriaClinica`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

-- 
-- Volcar la base de datos para la tabla `preparacionbiomedica`
-- 

INSERT INTO `preparacionbiomedica` VALUES (1, '12', '12', '21', '15', '15', '15', '34', '34', 6);
INSERT INTO `preparacionbiomedica` VALUES (2, '1', '1', '24', '27', '24', '40', '1', '1', 7);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `profesiones`
-- 

CREATE TABLE `profesiones` (
  `profesion` varchar(255) default NULL,
  `codigo` int(11) NOT NULL,
  PRIMARY KEY  (`codigo`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Volcar la base de datos para la tabla `profesiones`
-- 

INSERT INTO `profesiones` VALUES ('Personal Directivo de la Administración Pública', 12);
INSERT INTO `profesiones` VALUES ('Directores y Gerentes Generales de Servicios Financieros, de Telecomunicaciones y Otros Servicios', 13);
INSERT INTO `profesiones` VALUES ('Directores y Gerentes Generales de Salud, Educación, Servicios Social y Comunitario y Organizaciones', 14);
INSERT INTO `profesiones` VALUES ('Directores y Gerentes Generales de Comercio, Medios de Comunicación y Otros Servicios', 15);
INSERT INTO `profesiones` VALUES ('Directores y Gerentes Generales de Producción de Bienes, Servicios Públicos, Transporte y Construcción', 16);
INSERT INTO `profesiones` VALUES ('Gerentes Financieros', 111);
INSERT INTO `profesiones` VALUES ('Gerentes de Recursos Humanos', 112);
INSERT INTO `profesiones` VALUES ('Gerentes de Compras y Adquisiciones', 113);
INSERT INTO `profesiones` VALUES ('Gerentes de Otros Servicios Administrativos', 114);
INSERT INTO `profesiones` VALUES ('Gerentes de Seguros, Bienes Raíces y Corretaje Financiero', 121);
INSERT INTO `profesiones` VALUES ('Gerentes de Banca, Crédito e Inversiones', 122);
INSERT INTO `profesiones` VALUES ('Gerentes de Otros Servicios a las Empresas', 123);
INSERT INTO `profesiones` VALUES ('Gerentes de Empresas de Telecomunicaciones', 131);
INSERT INTO `profesiones` VALUES ('Gerentes de Servicios de Correo y Mensajería', 132);
INSERT INTO `profesiones` VALUES ('Gerentes de Ingeniería', 211);
INSERT INTO `profesiones` VALUES ('Gerentes de Investigación y Desarrollo en Ciencias Naturales y Aplicadas', 212);
INSERT INTO `profesiones` VALUES ('Gerentes de Sistemas de Información y Procesamiento de Datos', 213);
INSERT INTO `profesiones` VALUES ('Gerentes de Servicios a la Salud', 311);
INSERT INTO `profesiones` VALUES ('Gerentes de Programas de Política Social y de Salud', 411);
INSERT INTO `profesiones` VALUES ('Gerentes de Programas de Política de Desarrollo Económico', 412);
INSERT INTO `profesiones` VALUES ('Gerentes de Programas de Política Educativa', 413);
INSERT INTO `profesiones` VALUES ('Otros Gerentes de Administración Pública', 414);
INSERT INTO `profesiones` VALUES ('Administradores de Educación Superior y Formación para el Trabajo', 421);
INSERT INTO `profesiones` VALUES ('Directores y Administradores de Educación Básica y Media', 422);
INSERT INTO `profesiones` VALUES ('Gerentes de Servicios Social, Comunitario y Correccional', 423);
INSERT INTO `profesiones` VALUES ('Gerentes de Biblioteca, Archivo, Museo y Galería de Arte', 511);
INSERT INTO `profesiones` VALUES ('Gerentes de Medios de Comunicación y Artes Escénicas', 512);
INSERT INTO `profesiones` VALUES ('Directores de Programas de Esparcimiento y Deportes', 513);
INSERT INTO `profesiones` VALUES ('Gerentes de Ventas, Mercadeo y Publicidad', 611);
INSERT INTO `profesiones` VALUES ('Gerentes de Servicios de Comercio Exterior', 612);
INSERT INTO `profesiones` VALUES ('Gerentes de Comercio al Por Menor', 621);
INSERT INTO `profesiones` VALUES ('Gerentes de Restaurantes y Servicios de Alimentos', 631);
INSERT INTO `profesiones` VALUES ('Gerentes de Servicios de Alojamiento', 632);
INSERT INTO `profesiones` VALUES ('Gerentes de Otros Servicios', 651);
INSERT INTO `profesiones` VALUES ('Gerentes de Producción Primaria ', 711);
INSERT INTO `profesiones` VALUES ('Gerentes de Construcción', 811);
INSERT INTO `profesiones` VALUES ('Gerentes de Transporte y Distribución', 812);
INSERT INTO `profesiones` VALUES ('Gerentes de Operación de Instalaciones Físicas', 821);
INSERT INTO `profesiones` VALUES ('Gerentes de Mantenimiento', 822);
INSERT INTO `profesiones` VALUES ('Gerentes de Producción Industrial', 911);
INSERT INTO `profesiones` VALUES ('Gerentes de Empresas de Servicios Públicos', 912);
INSERT INTO `profesiones` VALUES ('Contadores y Auditores', 1111);
INSERT INTO `profesiones` VALUES ('Analistas y Agentes de Inversiones y Finanzas', 1112);
INSERT INTO `profesiones` VALUES ('Profesionales en Recursos Humanos', 1121);
INSERT INTO `profesiones` VALUES ('Profesionales en Organización y Administración de las Empresas', 1122);
INSERT INTO `profesiones` VALUES ('Supervisores, Empleados de Apoyo Administrativo', 1211);
INSERT INTO `profesiones` VALUES ('Supervisores, Empleados de Seguros y Finanzas', 1212);
INSERT INTO `profesiones` VALUES ('Supervisores, Empleados de Información y Servicio al Cliente', 1213);
INSERT INTO `profesiones` VALUES ('Supervisores, Empleados de Correo y Mensajería', 1214);
INSERT INTO `profesiones` VALUES ('Supervisores, Empleados de Registro, Distribución y Programación', 1215);
INSERT INTO `profesiones` VALUES ('Asistentes Administrativos', 1221);
INSERT INTO `profesiones` VALUES ('Administradores de Inmuebles', 1222);
INSERT INTO `profesiones` VALUES ('Asistentes de Personal y Selección', 1223);
INSERT INTO `profesiones` VALUES ('Asistentes de Compras y Adquisiciones', 1224);
INSERT INTO `profesiones` VALUES ('Asistentes de Juzgados Tribunales y Afines', 1225);
INSERT INTO `profesiones` VALUES ('Funcionarios de Aduanas, Impuestos, Inmigración y Seguridad Social', 1226);
INSERT INTO `profesiones` VALUES ('Asistentes de Comercio Exterior', 1227);
INSERT INTO `profesiones` VALUES ('Organizadores de Eventos', 1228);
INSERT INTO `profesiones` VALUES ('Analistas de Crédito y Cobranzas', 1231);
INSERT INTO `profesiones` VALUES ('Avaluadores y Liquidadores de Seguros', 1233);
INSERT INTO `profesiones` VALUES ('Agentes de Aduana', 1234);
INSERT INTO `profesiones` VALUES ('Secretarias', 1311);
INSERT INTO `profesiones` VALUES ('Auxiliares de Oficina', 1312);
INSERT INTO `profesiones` VALUES ('Recepcionistas y Operadores de Conmutador', 1313);
INSERT INTO `profesiones` VALUES ('Digitadores', 1321);
INSERT INTO `profesiones` VALUES ('Transcriptores y Relatores', 1322);
INSERT INTO `profesiones` VALUES ('Auxiliares Contables', 1331);
INSERT INTO `profesiones` VALUES ('Cajeros de Servicios Financieros', 1332);
INSERT INTO `profesiones` VALUES ('Auxiliares de Banca, Seguros y Otros Servicios Financieros', 1333);
INSERT INTO `profesiones` VALUES ('Auxiliares de Cartera y Cobranzas', 1334);
INSERT INTO `profesiones` VALUES ('Auxiliares Administrativos', 1341);
INSERT INTO `profesiones` VALUES ('Auxiliares de Personal', 1342);
INSERT INTO `profesiones` VALUES ('Auxiliares de Tribunales', 1343);
INSERT INTO `profesiones` VALUES ('Auxiliares de Archivo y Registro', 1344);
INSERT INTO `profesiones` VALUES ('Auxiliares de Biblioteca', 1345);
INSERT INTO `profesiones` VALUES ('Auxiliares de Publicación y Afines', 1346);
INSERT INTO `profesiones` VALUES ('Auxiliares de Información y Servicio al Cliente', 1353);
INSERT INTO `profesiones` VALUES ('Auxiliares de Estadísticas y Encuestadores', 1354);
INSERT INTO `profesiones` VALUES ('Auxiliares de Correo y Servicio Postal', 1361);
INSERT INTO `profesiones` VALUES ('Auxiliares de Almacén y Bodega', 1371);
INSERT INTO `profesiones` VALUES ('Auxiliares de Compras e Inventarios', 1372);
INSERT INTO `profesiones` VALUES ('Operadores de Radio y Despachadores', 1373);
INSERT INTO `profesiones` VALUES ('Programadores de Rutas y Tripulaciones', 1374);
INSERT INTO `profesiones` VALUES ('Operadores Telefónicos', 1375);
INSERT INTO `profesiones` VALUES ('Físicos y Astrónomos', 2111);
INSERT INTO `profesiones` VALUES ('Químicos', 2112);
INSERT INTO `profesiones` VALUES ('Geólogos, Geoquímicas y Geofísicos', 2113);
INSERT INTO `profesiones` VALUES ('Meteorólogos', 2114);
INSERT INTO `profesiones` VALUES ('Biólogos, Botánicos, Zoólogos y Relacionados', 2121);
INSERT INTO `profesiones` VALUES ('Expertos Forestales ', 2122);
INSERT INTO `profesiones` VALUES ('Expertos Agrícolas y Pecuarios', 2123);
INSERT INTO `profesiones` VALUES ('Ingenieros en Construcción y Obras Civiles', 2131);
INSERT INTO `profesiones` VALUES ('Ingenieros Mecánicos', 2132);
INSERT INTO `profesiones` VALUES ('Ingenieros Electricistas', 2133);
INSERT INTO `profesiones` VALUES ('Ingenieros Electrónicos y de Telecomunicaciones', 2134);
INSERT INTO `profesiones` VALUES ('Ingenieros Químicos', 2135);
INSERT INTO `profesiones` VALUES ('Ingenieros Industriales y de Fabricación', 2141);
INSERT INTO `profesiones` VALUES ('Ingenieros de Materiales y Metalurgia', 2142);
INSERT INTO `profesiones` VALUES ('Ingenieros de Minas', 2143);
INSERT INTO `profesiones` VALUES ('Ingenieros de Petróleos', 2144);
INSERT INTO `profesiones` VALUES ('Ingenieros de Sistemas, Informática y Computación', 2145);
INSERT INTO `profesiones` VALUES ('Otros Ingenieros ', 2146);
INSERT INTO `profesiones` VALUES ('Arquitectos', 2151);
INSERT INTO `profesiones` VALUES ('Urbanistas y Planificadores del Uso del Suelo', 2152);
INSERT INTO `profesiones` VALUES ('Profesionales Topográficos ', 2153);
INSERT INTO `profesiones` VALUES ('Matemáticos, Estadísticos y Actuarios ', 2161);
INSERT INTO `profesiones` VALUES ('Analistas de Sistemas Informáticos', 2171);
INSERT INTO `profesiones` VALUES ('Administradores de Sistemas Informáticos', 2172);
INSERT INTO `profesiones` VALUES ('Programadores de Aplicaciones Informáticas', 2173);
INSERT INTO `profesiones` VALUES ('Técnicos en Química Aplicada', 2211);
INSERT INTO `profesiones` VALUES ('Técnicos en Geología y Minería', 2212);
INSERT INTO `profesiones` VALUES ('Técnicos en Meteorología', 2213);
INSERT INTO `profesiones` VALUES ('Técnicos en Ciencias Biológicas ', 2221);
INSERT INTO `profesiones` VALUES ('Técnicos Forestales y de Recursos Naturales', 2222);
INSERT INTO `profesiones` VALUES ('Técnicos en Construcción y Arquitectura', 2231);
INSERT INTO `profesiones` VALUES ('Técnicos en Mecánica y Construcción Mecánica', 2232);
INSERT INTO `profesiones` VALUES ('Técnicos en Fabricación Industrial', 2233);
INSERT INTO `profesiones` VALUES ('Técnicos en Electricidad', 2241);
INSERT INTO `profesiones` VALUES ('Técnicos en Electrónica y Telecomunicaciones', 2242);
INSERT INTO `profesiones` VALUES ('Técnicos en Instrumentos Industriales', 2243);
INSERT INTO `profesiones` VALUES ('Técnicos en Instrumentos de Aeronavegación', 2244);
INSERT INTO `profesiones` VALUES ('Diseñadores Industriales', 2251);
INSERT INTO `profesiones` VALUES ('Dibujantes Técnicos', 2252);
INSERT INTO `profesiones` VALUES ('Topógrafos ', 2253);
INSERT INTO `profesiones` VALUES ('Técnicos en Cartografía', 2254);
INSERT INTO `profesiones` VALUES ('Inspectores de Pruebas No destructivas', 2261);
INSERT INTO `profesiones` VALUES ('Inspectores de Sanidad, Seguridad y Salud Ocupacional', 2262);
INSERT INTO `profesiones` VALUES ('Inspectores de Construcción', 2263);
INSERT INTO `profesiones` VALUES ('Inspectores de Equipos de Transporte e Instrumentos de Medición ', 2264);
INSERT INTO `profesiones` VALUES ('Inspectores de Productos Agrícolas, Pecuarios y de Pesca', 2265);
INSERT INTO `profesiones` VALUES ('Pilotos, Ingenieros e Instructores de Vuelo', 2271);
INSERT INTO `profesiones` VALUES ('Controladores de Tráfico Aéreo', 2272);
INSERT INTO `profesiones` VALUES ('Capitanes y Oficiales de Cubierta', 2273);
INSERT INTO `profesiones` VALUES ('Oficiales de Máquinas', 2274);
INSERT INTO `profesiones` VALUES ('Controladores de Tráfico Ferroviario y Marítimo', 2275);
INSERT INTO `profesiones` VALUES ('Técnicos de Sistemas', 2281);
INSERT INTO `profesiones` VALUES ('Médicos Especialistas', 3111);
INSERT INTO `profesiones` VALUES ('Médicos Generales', 3112);
INSERT INTO `profesiones` VALUES ('Odontólogos', 3113);
INSERT INTO `profesiones` VALUES ('Veterinarios', 3114);
INSERT INTO `profesiones` VALUES ('Optómetras', 3121);
INSERT INTO `profesiones` VALUES ('Otras Ocupaciones Profesionales en Diagnóstico y Tratamiento de la Salud n.c.a.', 3122);
INSERT INTO `profesiones` VALUES ('Farmacéuticos', 3131);
INSERT INTO `profesiones` VALUES ('Dietistas y Nutricionistas', 3132);
INSERT INTO `profesiones` VALUES ('Audiólogos y Terapeutas del Lenguaje', 3141);
INSERT INTO `profesiones` VALUES ('Fisioterapeutas', 3142);
INSERT INTO `profesiones` VALUES ('Terapeutas Ocupacionales', 3143);
INSERT INTO `profesiones` VALUES ('Enfermeros', 3151);
INSERT INTO `profesiones` VALUES ('Técnicos de Laboratorio Médico y Patología', 3211);
INSERT INTO `profesiones` VALUES ('Técnicos en Terapia Respiratoria y Cardiovascular', 3212);
INSERT INTO `profesiones` VALUES ('Técnicos en Imágenes Diagnósticas', 3213);
INSERT INTO `profesiones` VALUES ('Técnicos en Radioterapia y Medicina Nuclear', 3214);
INSERT INTO `profesiones` VALUES ('Instrumentador Quirúrgico', 3215);
INSERT INTO `profesiones` VALUES ('Técnicos Dentales', 3221);
INSERT INTO `profesiones` VALUES ('Higienistas Dentales', 3222);
INSERT INTO `profesiones` VALUES ('Técnicos Ópticos', 3231);
INSERT INTO `profesiones` VALUES ('Practicantes de Medicina Alternativa', 3232);
INSERT INTO `profesiones` VALUES ('Asistentes de Ambulancia y Otras Ocupaciones Paramédicas', 3233);
INSERT INTO `profesiones` VALUES ('Otras Ocupaciones Técnicas en Terapia y Valoración', 3234);
INSERT INTO `profesiones` VALUES ('Auxiliares de Enfermería', 3311);
INSERT INTO `profesiones` VALUES ('Auxiliares de Odontología', 3312);
INSERT INTO `profesiones` VALUES ('Promotores de Salud', 3313);
INSERT INTO `profesiones` VALUES ('Auxiliares de Laboratorio Clínico', 3314);
INSERT INTO `profesiones` VALUES ('Auxiliares de Droguería y Farmacia', 3315);
INSERT INTO `profesiones` VALUES ('Jueces', 4111);
INSERT INTO `profesiones` VALUES ('Abogados', 4112);
INSERT INTO `profesiones` VALUES ('Profesores de Educación Superior', 4121);
INSERT INTO `profesiones` VALUES ('Especialistas en Métodos Pedagógicos y Material Didáctico', 4122);
INSERT INTO `profesiones` VALUES ('Instructores de Formación para el Trabajo', 4131);
INSERT INTO `profesiones` VALUES ('Profesores de Educación Básica Secundaria y Media', 4141);
INSERT INTO `profesiones` VALUES ('Profesores de Educación Básica Primaria', 4142);
INSERT INTO `profesiones` VALUES ('Profesores de Preescolar', 4143);
INSERT INTO `profesiones` VALUES ('Orientadores Educativos', 4144);
INSERT INTO `profesiones` VALUES ('Psicólogos', 4151);
INSERT INTO `profesiones` VALUES ('Trabajadores Sociales y Consultores de Familia', 4152);
INSERT INTO `profesiones` VALUES ('Sociólogos, Antropólogos y Afines', 4161);
INSERT INTO `profesiones` VALUES ('Filósofos, Filólogos y Afines', 4162);
INSERT INTO `profesiones` VALUES ('Consultores, Investigadores y Analistas de Política Económica', 4171);
INSERT INTO `profesiones` VALUES ('Consultores y Funcionarios de Desarrollo Económico y Comercial', 4172);
INSERT INTO `profesiones` VALUES ('Investigadores, Consultores y Funcionarios de Políticas Sociales, de  Salud y de Educación ', 4173);
INSERT INTO `profesiones` VALUES ('Funcionarios de Programas Exclusivos de la Administración Pública', 4174);
INSERT INTO `profesiones` VALUES ('Investigadores, Consultores y Funcionarios de Políticas de Ciencias Naturales y Aplicadas', 4175);
INSERT INTO `profesiones` VALUES ('Asistentes en Servicios Social y Comunitario', 4211);
INSERT INTO `profesiones` VALUES ('Consejeros de Servicios de Empleo', 4212);
INSERT INTO `profesiones` VALUES ('Instructores y Profesores de Personas Discapacitadas', 4213);
INSERT INTO `profesiones` VALUES ('Otros Instructores', 4214);
INSERT INTO `profesiones` VALUES ('Asistentes Legales y Afines', 4216);
INSERT INTO `profesiones` VALUES ('Bibliotecarios', 5111);
INSERT INTO `profesiones` VALUES ('Restauradores y Curadores', 5112);
INSERT INTO `profesiones` VALUES ('Archivistas', 5113);
INSERT INTO `profesiones` VALUES ('Escritores', 5121);
INSERT INTO `profesiones` VALUES ('Editores', 5122);
INSERT INTO `profesiones` VALUES ('Periodistas', 5123);
INSERT INTO `profesiones` VALUES ('Traductores e Interpretes', 5124);
INSERT INTO `profesiones` VALUES ('Ocupaciones Profesionales en Relaciones Públicas y Comunicaciones', 5125);
INSERT INTO `profesiones` VALUES ('Productores, Directores Artísticos, Coreógrafos y Ocupaciones Relacionadas', 5131);
INSERT INTO `profesiones` VALUES ('Directores Musicales, Compositores y Arreglistas', 5132);
INSERT INTO `profesiones` VALUES ('Músicos y Cantantes', 5133);
INSERT INTO `profesiones` VALUES ('Bailarines', 5134);
INSERT INTO `profesiones` VALUES ('Actores', 5135);
INSERT INTO `profesiones` VALUES ('Pintores, Escultores y Otros Artistas Visuales', 5136);
INSERT INTO `profesiones` VALUES ('Ocupaciones Técnicas Relacionadas con Museos y Galerías', 5211);
INSERT INTO `profesiones` VALUES ('Técnicos en Biblioteca y Archivo', 5212);
INSERT INTO `profesiones` VALUES ('Fotógrafos', 5221);
INSERT INTO `profesiones` VALUES ('Operadores de Cámara de Cine y Televisión', 5222);
INSERT INTO `profesiones` VALUES ('Técnicos de Arte Gráfico', 5223);
INSERT INTO `profesiones` VALUES ('Técnicos en Transmisión de Radio y Televisión', 5224);
INSERT INTO `profesiones` VALUES ('Técnicos en Grabación de Audio y Video', 5225);
INSERT INTO `profesiones` VALUES ('Otras Ocupaciones Técnicas en Cine, TV y Artes Escénicas', 5226);
INSERT INTO `profesiones` VALUES ('Ocupaciones de Asistencia en Cine, TV y Artes Escénicas  ', 5227);
INSERT INTO `profesiones` VALUES ('Anunciadores y Locutores', 5231);
INSERT INTO `profesiones` VALUES ('Diseñadores Gráficos y Dibujantes Artísticos', 5241);
INSERT INTO `profesiones` VALUES ('Diseñadores de Interiores', 5242);
INSERT INTO `profesiones` VALUES ('Diseñadores de Teatro, Moda, Exhibición, y Otros Diseñadores Creativos', 5243);
INSERT INTO `profesiones` VALUES ('Artesanos', 5244);
INSERT INTO `profesiones` VALUES ('Patronistas –Productos de Tela, Cuero y Piel', 5245);
INSERT INTO `profesiones` VALUES ('Entrenadores y Preparadores Físicos', 5252);
INSERT INTO `profesiones` VALUES ('Supervisores de Ventas', 6211);
INSERT INTO `profesiones` VALUES ('Supervisores de Servicios de Alimentos', 6213);
INSERT INTO `profesiones` VALUES ('Supervisores de Personal ', 6214);
INSERT INTO `profesiones` VALUES ('Técnicos Criminalisticos y Judiciales', 6224);
INSERT INTO `profesiones` VALUES ('Agentes y Corredores de Seguros', 6231);
INSERT INTO `profesiones` VALUES ('Agentes de Bienes Raíces', 6232);
INSERT INTO `profesiones` VALUES ('Vendedores –Ventas Técnicas', 6233);
INSERT INTO `profesiones` VALUES ('Agentes de Compras e Intermediarios', 6234);
INSERT INTO `profesiones` VALUES ('Chef', 6241);
INSERT INTO `profesiones` VALUES ('Vendedores –Ventas no Técnicas', 6311);
INSERT INTO `profesiones` VALUES ('Vendedores de Mostrador', 6321);
INSERT INTO `profesiones` VALUES ('Mercaderistas e Impulsadores', 6322);
INSERT INTO `profesiones` VALUES ('Cajeros de Comercio', 6323);
INSERT INTO `profesiones` VALUES ('Modelos', 6324);
INSERT INTO `profesiones` VALUES ('Agentes de Viajes', 6331);
INSERT INTO `profesiones` VALUES ('Empleados de Ventas y Servicios de Líneas Aéreas, Marítimas y Terrestres', 6332);
INSERT INTO `profesiones` VALUES ('Auxiliares de Vuelo y Sobrecargos', 6333);
INSERT INTO `profesiones` VALUES ('Empleados de Recepción Hotelera', 6334);
INSERT INTO `profesiones` VALUES ('Guías de Viaje y Turismo', 6341);
INSERT INTO `profesiones` VALUES ('Recreacionistas', 6342);
INSERT INTO `profesiones` VALUES ('Operadores de Juegos Mecánicos y de Salón', 6343);
INSERT INTO `profesiones` VALUES ('Cortadores de Carne –Comercio Mayorista y al Detal', 6351);
INSERT INTO `profesiones` VALUES ('Panaderos y Pasteleros', 6352);
INSERT INTO `profesiones` VALUES ('Meseros y Capitán de Meseros', 6353);
INSERT INTO `profesiones` VALUES ('Barman', 6354);
INSERT INTO `profesiones` VALUES ('Cocineros', 6355);
INSERT INTO `profesiones` VALUES ('Funcionarios de Regulación', 6362);
INSERT INTO `profesiones` VALUES ('Bomberos', 6364);
INSERT INTO `profesiones` VALUES ('Guardianes de Prisión', 6365);
INSERT INTO `profesiones` VALUES ('Auxiliares del Cuidado de Niños', 6372);
INSERT INTO `profesiones` VALUES ('Estilistas, Esteticistas y Afines', 6373);
INSERT INTO `profesiones` VALUES ('Trabajadores del Cuidado de Animales', 6374);
INSERT INTO `profesiones` VALUES ('Empleados de Pompas Fúnebres', 6375);
INSERT INTO `profesiones` VALUES ('Trabajadores de Estación de Servicio', 6611);
INSERT INTO `profesiones` VALUES ('Otras Ocupaciones Elementales de las Ventas', 6612);
INSERT INTO `profesiones` VALUES ('Ayudantes de Cocina y Cafetería', 6621);
INSERT INTO `profesiones` VALUES ('Aseadores  ', 6631);
INSERT INTO `profesiones` VALUES ('Aseadores Especializados y Fumigadores', 6632);
INSERT INTO `profesiones` VALUES ('Auxiliares de Servicios a Viajeros', 6641);
INSERT INTO `profesiones` VALUES ('Auxiliares de Servicios de Recreación y Deporte', 6642);
INSERT INTO `profesiones` VALUES ('Empleados de Lavandería', 6643);
INSERT INTO `profesiones` VALUES ('Otras Ocupaciones Elementales de los Servicios ', 6644);
INSERT INTO `profesiones` VALUES ('Supervisores, Minería y Canteras', 7211);
INSERT INTO `profesiones` VALUES ('Supervisores, Perforación y Servicios –Pozos de Petróleo y Gas', 7212);
INSERT INTO `profesiones` VALUES ('Supervisores, Producción Agrícola', 7221);
INSERT INTO `profesiones` VALUES ('Supervisores, Producción Pecuaria', 7222);
INSERT INTO `profesiones` VALUES ('Supervisores, Explotación Forestal y Silvicultura', 7223);
INSERT INTO `profesiones` VALUES ('Agricultores y Administradores Agropecuarios', 7231);
INSERT INTO `profesiones` VALUES ('Contratistas de Servicios Agrícolas y Relacionados', 7232);
INSERT INTO `profesiones` VALUES ('Contratistas y Supervisores de Servicios de Jardinería y Viverismo', 7233);
INSERT INTO `profesiones` VALUES ('Administradores de Explotación Acuícola', 7234);
INSERT INTO `profesiones` VALUES ('Capitanes y Patrones de Pesca', 7241);
INSERT INTO `profesiones` VALUES ('Operarios de Apoyo y Servicios en Minería Bajo Tierra', 7311);
INSERT INTO `profesiones` VALUES ('Operarios de Apoyo y Servicios en Perforación de Petróleo y Gas', 7312);
INSERT INTO `profesiones` VALUES ('Mineros –Producción Bajo Tierra', 7313);
INSERT INTO `profesiones` VALUES ('Perforadores de Pozos de Gas y Petróleo y Trabajadores Relacionados', 7314);
INSERT INTO `profesiones` VALUES ('Trabajadores de Explotación Forestal', 7321);
INSERT INTO `profesiones` VALUES ('Trabajadores de Silvicultura y Forestación', 7322);
INSERT INTO `profesiones` VALUES ('Trabajadores Agrícolas', 7331);
INSERT INTO `profesiones` VALUES ('Trabajadores Pecuarios', 7332);
INSERT INTO `profesiones` VALUES ('Trabajadores de Plantas de Incubación Artificial ', 7335);
INSERT INTO `profesiones` VALUES ('Pescadores', 7341);
INSERT INTO `profesiones` VALUES ('Obreros y Ayudantes de Minería', 7611);
INSERT INTO `profesiones` VALUES ('Obreros y Ayudantes de Producción en Pozos de Petróleo y Gas', 7612);
INSERT INTO `profesiones` VALUES ('Obreros Agropecuarios ', 7613);
INSERT INTO `profesiones` VALUES ('Jardineros', 7614);
INSERT INTO `profesiones` VALUES ('Contratistas y Supervisores, Ajustadores de Maquinas-Herramientas y Ocupaciones Relacionadas', 8211);
INSERT INTO `profesiones` VALUES ('Contratistas y Supervisores, Electricidad y Telecomunicaciones', 8212);
INSERT INTO `profesiones` VALUES ('Contratistas y Supervisores, Instalación de Tuberías ', 8213);
INSERT INTO `profesiones` VALUES ('Contratistas y Supervisores, Moldeo, Forja y Montaje de Estructuras Metálicas', 8214);
INSERT INTO `profesiones` VALUES ('Contratistas y Supervisores, Carpintería', 8215);
INSERT INTO `profesiones` VALUES ('Contratistas y Supervisores, Mecánica', 8216);
INSERT INTO `profesiones` VALUES ('Contratistas y Supervisores, Operación de Equipo Pesado', 8217);
INSERT INTO `profesiones` VALUES ('Contratistas y Supervisores, Construcción y Otras Ocupaciones de Instalación y Reparación', 8218);
INSERT INTO `profesiones` VALUES ('Supervisores de Operación de Transporte Ferroviario', 8221);
INSERT INTO `profesiones` VALUES ('Supervisores de Operación de Transporte Terrestre (no ferroviario)', 8222);
INSERT INTO `profesiones` VALUES ('Ajustadores de Maquinas-Herramientas', 8311);
INSERT INTO `profesiones` VALUES ('Modelistas y Matriceros', 8312);
INSERT INTO `profesiones` VALUES ('Electricistas Industriales', 8321);
INSERT INTO `profesiones` VALUES ('Electricistas Residenciales', 8322);
INSERT INTO `profesiones` VALUES ('Instaladores de Redes de Energía Eléctrica', 8323);
INSERT INTO `profesiones` VALUES ('Instaladores y Reparadores de Redes y Líneas de Telecomunicaciones', 8324);
INSERT INTO `profesiones` VALUES ('Trabajadores de Instalación y Reparación de Equipos de Telecomunicaciones', 8325);
INSERT INTO `profesiones` VALUES ('Técnicos de Mantenimiento y Servicio de Televisión por Cable', 8326);
INSERT INTO `profesiones` VALUES ('Plomeros', 8331);
INSERT INTO `profesiones` VALUES ('Instaladores de Tuberías y Sistemas de Aspersión', 8332);
INSERT INTO `profesiones` VALUES ('Instaladores de Redes  y Equipos a Gas', 8333);
INSERT INTO `profesiones` VALUES ('Chapistas y Caldereros', 8341);
INSERT INTO `profesiones` VALUES ('Soldadores', 8342);
INSERT INTO `profesiones` VALUES ('Montadores de Estructuras Metálicas', 8343);
INSERT INTO `profesiones` VALUES ('Ornamentistas y Forjadores', 8344);
INSERT INTO `profesiones` VALUES ('Carpinteros', 8351);
INSERT INTO `profesiones` VALUES ('Ebanistas', 8352);
INSERT INTO `profesiones` VALUES ('Oficiales de Construcción', 8361);
INSERT INTO `profesiones` VALUES ('Trabajadores en Hormigón y Enfoscado', 8362);
INSERT INTO `profesiones` VALUES ('Enchapadores ', 8363);
INSERT INTO `profesiones` VALUES ('Techadores', 8364);
INSERT INTO `profesiones` VALUES ('Instaladores de Material Aislante', 8365);
INSERT INTO `profesiones` VALUES ('Pintores y Empapeladores', 8366);
INSERT INTO `profesiones` VALUES ('Instaladores de Pisos', 8367);
INSERT INTO `profesiones` VALUES ('Revocadores', 8368);
INSERT INTO `profesiones` VALUES ('Mecánicos Industriales', 8371);
INSERT INTO `profesiones` VALUES ('Mecánicos de Maquinaria Textil', 8372);
INSERT INTO `profesiones` VALUES ('Mecánicos de Equipo Pesado', 8373);
INSERT INTO `profesiones` VALUES ('Mecánicos de Aviación', 8374);
INSERT INTO `profesiones` VALUES ('Mecánicos de Aire Acondicionado y Refrigeración', 8375);
INSERT INTO `profesiones` VALUES ('Mecánicos de Vehículos Automotores', 8381);
INSERT INTO `profesiones` VALUES ('Electricistas de Vehículos Automotores', 8382);
INSERT INTO `profesiones` VALUES ('Mecánicos de Motos', 8383);
INSERT INTO `profesiones` VALUES ('Latoneros', 8384);
INSERT INTO `profesiones` VALUES ('Reparadores de Aparatos Electrodomésticos', 8391);
INSERT INTO `profesiones` VALUES ('Mecánicos Electricistas', 8392);
INSERT INTO `profesiones` VALUES ('Ajustadores y Reparadores de Equipos Electrónicos', 8393);
INSERT INTO `profesiones` VALUES ('Mecánicos de Otros Pequeñas Máquinas y Motores', 8394);
INSERT INTO `profesiones` VALUES ('Instaladores Residenciales y Comerciales', 8411);
INSERT INTO `profesiones` VALUES ('Operarios de Mantenimiento -Instalaciones de Abastecimiento de Agua y Gas', 8412);
INSERT INTO `profesiones` VALUES ('Vidrieros', 8413);
INSERT INTO `profesiones` VALUES ('Otros Reparadores', 8414);
INSERT INTO `profesiones` VALUES ('Tapiceros', 8421);
INSERT INTO `profesiones` VALUES ('Sastres, Modistos, Plateros y Sombrereros', 8422);
INSERT INTO `profesiones` VALUES ('Zapateros y Afines', 8423);
INSERT INTO `profesiones` VALUES ('Joyeros y Relojeros', 8424);
INSERT INTO `profesiones` VALUES ('Tipógrafos', 8425);
INSERT INTO `profesiones` VALUES ('Cerrajeros y Otros Oficios', 8426);
INSERT INTO `profesiones` VALUES ('Buzos', 8427);
INSERT INTO `profesiones` VALUES ('Operadores de Maquinas Estacionarias y Equipo Auxiliar', 8431);
INSERT INTO `profesiones` VALUES ('Operadores de Plantas de Generación y Distribución de Energía', 8432);
INSERT INTO `profesiones` VALUES ('Operadores de Grúa', 8441);
INSERT INTO `profesiones` VALUES ('Perforadores y Operarios de Voladura –Minería de Superficie, Canteras y Construcción', 8442);
INSERT INTO `profesiones` VALUES ('Perforadores de Pozos de Agua', 8443);
INSERT INTO `profesiones` VALUES ('Operadores de Equipo Pesado (excepto grúa)', 8451);
INSERT INTO `profesiones` VALUES ('Operadores de Equipo para Limpieza de Vías y Alcantarillado', 8452);
INSERT INTO `profesiones` VALUES ('Operadores de Maquinaria Agrícola', 8453);
INSERT INTO `profesiones` VALUES ('Maquinistas de Transporte Ferroviario', 8461);
INSERT INTO `profesiones` VALUES ('Guardafrenos y Otros Operadores Ferroviarios', 8462);
INSERT INTO `profesiones` VALUES ('Marineros de Cubierta', 8481);
INSERT INTO `profesiones` VALUES ('Marineros de Sala de Máquinas', 8482);
INSERT INTO `profesiones` VALUES ('Operadores de Pequeñas Embarcaciones', 8483);
INSERT INTO `profesiones` VALUES ('Operarios de Rampa –Transporte Aéreo', 8484);
INSERT INTO `profesiones` VALUES ('Operarios Portuarios', 8491);
INSERT INTO `profesiones` VALUES ('Operarios de Cargue y Descargue de Materiales', 8492);
INSERT INTO `profesiones` VALUES ('Ayudantes y Obreros de Construcción', 8611);
INSERT INTO `profesiones` VALUES ('Ayudantes de Otros Oficios ', 8612);
INSERT INTO `profesiones` VALUES ('Obreros de Mantenimiento de Obras Públicas', 8621);
INSERT INTO `profesiones` VALUES ('Ayudantes de Transporte Automotor ', 8622);
INSERT INTO `profesiones` VALUES ('Supervisores Tratamiento de Metales y Minerales', 9211);
INSERT INTO `profesiones` VALUES ('Supervisores, Procesamiento de Químicos, Petróleo, Gas y Tratamiento de Agua y Generación de Energía', 9212);
INSERT INTO `profesiones` VALUES ('Supervisores, Procesamiento de Alimentos, Bebidas y Tabaco', 9213);
INSERT INTO `profesiones` VALUES ('Supervisores, Fabricación de Productos de Plástico y Caucho', 9214);
INSERT INTO `profesiones` VALUES ('Supervisores, Procesamiento de la Madera y Producción de Pulpa y Papel', 9215);
INSERT INTO `profesiones` VALUES ('Supervisores, Procesamiento Textil', 9216);
INSERT INTO `profesiones` VALUES ('Supervisores, Ensamble de Vehículos de Motor', 9221);
INSERT INTO `profesiones` VALUES ('Supervisores, Fabricación de Productos Electrónicos', 9222);
INSERT INTO `profesiones` VALUES ('Supervisores, Fabricación de Productos Eléctricos', 9223);
INSERT INTO `profesiones` VALUES ('Supervisores, Fabricación de Muebles y Accesorios', 9224);
INSERT INTO `profesiones` VALUES ('Supervisores, Fabricación de Productos de Tela, Cuero y Piel', 9225);
INSERT INTO `profesiones` VALUES ('Supervisores, Impresión y Ocupaciones Relacionadas', 9226);
INSERT INTO `profesiones` VALUES ('Supervisores, Fabricación de Otros Productos Mecánicos y Metálicos', 9227);
INSERT INTO `profesiones` VALUES ('Supervisores, Fabricación  Ensamble de Otros Productos n.c.a', 9228);
INSERT INTO `profesiones` VALUES ('Operadores de Control Central de Procesos, Tratamiento de Metales y Minerales', 9231);
INSERT INTO `profesiones` VALUES ('Operadores de Procesos, Químicos, Gas y Petróleo', 9232);
INSERT INTO `profesiones` VALUES ('Operadores de Control de Procesos, Producción de Pulpa', 9233);
INSERT INTO `profesiones` VALUES ('Operadores de Control de Procesos, Fabricación de Papel', 9234);
INSERT INTO `profesiones` VALUES ('Operadores de Maquinas, Tratamiento de Metales y Minerales', 9311);
INSERT INTO `profesiones` VALUES ('Trabajadores de Fundición', 9312);
INSERT INTO `profesiones` VALUES ('Operadores de Fabricación, Moldeo y Acabado del Vidrio', 9313);
INSERT INTO `profesiones` VALUES ('Operadores de Moldeo de Arcilla, Piedra y Concreto', 9314);
INSERT INTO `profesiones` VALUES ('Inspectores de Control de Calidad, Tratamiento de Metales y Minerales', 9315);
INSERT INTO `profesiones` VALUES ('Operadores de Máquinas de Planta Química', 9321);
INSERT INTO `profesiones` VALUES ('Operadores de Máquinas para Procesamiento de Plásticos', 9322);
INSERT INTO `profesiones` VALUES ('Operadores de Máquinas y Trabajadores Relacionados con el Procesamiento del Caucho', 9323);
INSERT INTO `profesiones` VALUES ('Operadores de Plantas de Tratamiento de Aguas y Desechos', 9324);
INSERT INTO `profesiones` VALUES ('Operadores de Máquinas para Procesamiento de la Madera', 9331);
INSERT INTO `profesiones` VALUES ('Operadores de Máquinas para la Producción de Pulpa', 9332);
INSERT INTO `profesiones` VALUES ('Operadores de Máquinas para la Fabricación de Papel', 9333);
INSERT INTO `profesiones` VALUES ('Operadores de Máquinas para la Fabricación de Productos de Papel', 9334);
INSERT INTO `profesiones` VALUES ('Inspectores de Control de Calidad, Procesamiento de la Madera', 9335);
INSERT INTO `profesiones` VALUES ('Operadores de Máquinas para la Preparación de Fibras Textiles', 9341);
INSERT INTO `profesiones` VALUES ('Operadores de Telares y Otras Máquinas Tejedoras', 9342);
INSERT INTO `profesiones` VALUES ('Operadores de Máquinas de Tintura y Acabado Textil', 9343);
INSERT INTO `profesiones` VALUES ('Analistas de  Calidad Textiles', 9344);
INSERT INTO `profesiones` VALUES ('Operadores de Máquinas para Coser', 9351);
INSERT INTO `profesiones` VALUES ('Cortadores de Tela, Cuero y Piel', 9352);
INSERT INTO `profesiones` VALUES ('Operadores de Máquinas y Trabajadores Relacionados con la Fabricación de Calzado y Marroquinería ', 9353);
INSERT INTO `profesiones` VALUES ('Operarios del Tratamiento de Pieles y Cueros', 9354);
INSERT INTO `profesiones` VALUES ('Inspectores de Control de Calidad, Fabricación de Productos de Tela, Piel y Cuero', 9355);
INSERT INTO `profesiones` VALUES ('Operadores de Control de Procesos y Máquinas para la Elaboración de Alimentos y Bebidas', 9361);
INSERT INTO `profesiones` VALUES ('Operarios de Planta de Beneficio Animal', 9362);
INSERT INTO `profesiones` VALUES ('Operarios de Planta de Procesamiento y Empaque de Pescado', 9363);
INSERT INTO `profesiones` VALUES ('Operadores de Máquinas para la Elaboración de Productos de Tabaco', 9364);
INSERT INTO `profesiones` VALUES ('Inspectores de Control de Calidad, Procesamiento de Alimentos y Bebidas', 9365);
INSERT INTO `profesiones` VALUES ('Operadores de Máquinas de Impresión', 9371);
INSERT INTO `profesiones` VALUES ('Grabadores y Otras Ocupaciones de Pre-impresión', 9372);
INSERT INTO `profesiones` VALUES ('Operadores de Máquinas de Encuadernación y Acabado', 9373);
INSERT INTO `profesiones` VALUES ('Procesadores Fotográficos y de Películas', 9374);
INSERT INTO `profesiones` VALUES ('Ensambladores e Inspectores de Vehículos a Automotor', 9381);
INSERT INTO `profesiones` VALUES ('Ensambladores, Fabricantes e Inspectores de Equipos y Componentes Electrónicos', 9382);
INSERT INTO `profesiones` VALUES ('Ensambladores e Inspectores de Aparatos y Equipo Eléctrico', 9383);
INSERT INTO `profesiones` VALUES ('Ensambladores, Fabricantes e Inspectores de Transformadores y Motores Eléctricos Industriales', 9384);
INSERT INTO `profesiones` VALUES ('Ensambladores e Inspectores de Productos Mecánicos', 9385);
INSERT INTO `profesiones` VALUES ('Ensambladores e Inspectores de Ensamble de Aeronaves', 9386);
INSERT INTO `profesiones` VALUES ('Operadores de Máquinas e Inspectores de la Fabricación de Productos y Componentes Eléctricos', 9387);
INSERT INTO `profesiones` VALUES ('Ensambladores e Inspectores de Embarcaciones', 9391);
INSERT INTO `profesiones` VALUES ('Ensambladores e Inspectores de Muebles y Accesorios', 9392);
INSERT INTO `profesiones` VALUES ('Operarios de Acabado de Muebles', 9393);
INSERT INTO `profesiones` VALUES ('Ensambladores de Productos Plásticos e Inspectores', 9394);
INSERT INTO `profesiones` VALUES ('Operarios de Recubrimientos Metálicos', 9395);
INSERT INTO `profesiones` VALUES ('Pintores en Procesos de Manufactura', 9396);
INSERT INTO `profesiones` VALUES ('Operadores de Máquinas Herramientas', 9411);
INSERT INTO `profesiones` VALUES ('Operadores de Máquinas para el Trabajo de la Madera', 9412);
INSERT INTO `profesiones` VALUES ('Operadores de Máquinas para el Trabajo del Metal', 9413);
INSERT INTO `profesiones` VALUES ('Operadores de Máquinas para Forja', 9414);
INSERT INTO `profesiones` VALUES ('Operadores de Máquinas de Soldadura', 9415);
INSERT INTO `profesiones` VALUES ('Operadores de Máquinas para la Fabricación de Otros Productos Metálicos', 9416);
INSERT INTO `profesiones` VALUES ('Obreros y Ayudantes en el Tratamiento de Metales y Minerales', 9611);
INSERT INTO `profesiones` VALUES ('Ayudantes en la Fabricación Metálica', 9612);
INSERT INTO `profesiones` VALUES ('Obreros y Ayudantes de Planta Química', 9613);
INSERT INTO `profesiones` VALUES ('Obreros y Ayudantes en el Procesamiento de la Madera y Producción de Pulpa y Papel', 9614);
INSERT INTO `profesiones` VALUES ('Obreros y Ayudantes en la Elaboración de Alimentos y Bebidas', 9615);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `radiografia`
-- 

CREATE TABLE `radiografia` (
  `idradiografia` int(11) NOT NULL,
  `nombre` varchar(45) default NULL,
  `ruta` varchar(255) default NULL,
  `datosConsulta_iddatosConsulta` int(11) NOT NULL,
  PRIMARY KEY  (`idradiografia`),
  KEY `fk_radiografia_datosConsulta1` (`datosConsulta_iddatosConsulta`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Volcar la base de datos para la tabla `radiografia`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `remision`
-- 

CREATE TABLE `remision` (
  `idremision` int(11) NOT NULL,
  `remision` varchar(45) default NULL,
  PRIMARY KEY  (`idremision`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Volcar la base de datos para la tabla `remision`
-- 

INSERT INTO `remision` VALUES (1, 'Semiologia');
INSERT INTO `remision` VALUES (2, 'Promocion y Prevencion');
INSERT INTO `remision` VALUES (3, 'Operatoria');
INSERT INTO `remision` VALUES (4, 'Endodoncia');
INSERT INTO `remision` VALUES (5, 'Periodoncia');
INSERT INTO `remision` VALUES (6, 'Cirugia');
INSERT INTO `remision` VALUES (7, 'Odontopedriatia');
INSERT INTO `remision` VALUES (8, 'Rehabilitacion');
INSERT INTO `remision` VALUES (9, 'Ortodoncia');
INSERT INTO `remision` VALUES (10, 'Otros');

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `remision_has_datosconsulta`
-- 

CREATE TABLE `remision_has_datosconsulta` (
  `remision_idremision` int(11) NOT NULL,
  `datosConsulta_iddatosConsulta` int(11) NOT NULL,
  PRIMARY KEY  (`remision_idremision`,`datosConsulta_iddatosConsulta`),
  KEY `fk_remision_has_datosConsulta_datosConsulta1` (`datosConsulta_iddatosConsulta`),
  KEY `fk_remision_has_datosConsulta_remision1` (`remision_idremision`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Volcar la base de datos para la tabla `remision_has_datosconsulta`
-- 

INSERT INTO `remision_has_datosconsulta` VALUES (1, 21);
INSERT INTO `remision_has_datosconsulta` VALUES (5, 22);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `tratamiento`
-- 

CREATE TABLE `tratamiento` (
  `idtratamiento` int(11) NOT NULL auto_increment,
  `tratamiento` varchar(255) default NULL,
  `presupuesto` varchar(45) default NULL,
  PRIMARY KEY  (`idtratamiento`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2104 ;

-- 
-- Volcar la base de datos para la tabla `tratamiento`
-- 

INSERT INTO `tratamiento` VALUES (101, 'Historia Clinica, impresión para modelo, Rx panoramica digital', '32000');
INSERT INTO `tratamiento` VALUES (102, 'Historia Clinica, impresión para modelo, sin Rx panoramica digital', '12000');
INSERT INTO `tratamiento` VALUES (103, 'Historia Clinica Reevaluacion', '10000');
INSERT INTO `tratamiento` VALUES (104, 'Historia Clinica de niño (incluye face higienica, control de placa, primera impresión, modelo inicial) incluye 1 Rx periapical niño', '13000');
INSERT INTO `tratamiento` VALUES (105, 'Historia Clinica de niños - Reevaluacion paquete: Fase Higienica, Control de placa y Cubeta de fluorogel, alginato, modelo inicial', '6500');
INSERT INTO `tratamiento` VALUES (106, 'Terapeutica con Fluor de Estaño', '8000');
INSERT INTO `tratamiento` VALUES (107, 'Terapeutica con Fluor Neutro', '5000');
INSERT INTO `tratamiento` VALUES (108, 'Historia Clinica de Flap sin aparatologia', '20000');
INSERT INTO `tratamiento` VALUES (109, 'Urgencias C/Rx periapical', '10000');
INSERT INTO `tratamiento` VALUES (110, 'Rx Periapical adulto institucional', '1000');
INSERT INTO `tratamiento` VALUES (111, 'Rx Periapical adulto ambulatoria', '6000');
INSERT INTO `tratamiento` VALUES (112, 'Rx Pediatrica institucional', '1000');
INSERT INTO `tratamiento` VALUES (113, 'Rx Pediatrica (Ambulatoria)', '4000');
INSERT INTO `tratamiento` VALUES (114, 'Rx Oclusal Institucional', '9000');
INSERT INTO `tratamiento` VALUES (115, 'Rx Oclusal (Ambulatoria)', '13000');
INSERT INTO `tratamiento` VALUES (116, 'Rx Panoramica digital Institucional', '20000');
INSERT INTO `tratamiento` VALUES (117, 'Rx Panoramica digital (Ambulatoria)', '22000');
INSERT INTO `tratamiento` VALUES (118, 'Reimpresion Rx Panoramica digital', '10000');
INSERT INTO `tratamiento` VALUES (119, 'Rx Panoramica digital mas Rx lateral institucional', '40000');
INSERT INTO `tratamiento` VALUES (120, 'Rx Panoramica digital mas Rx lateral Ambulatoria', '44000');
INSERT INTO `tratamiento` VALUES (201, 'Procedimiento obturacion en amalgama (una superficie)', '5000');
INSERT INTO `tratamiento` VALUES (202, 'Procedimiento Obturacion en amalgama (dos o mas superficies)', '8000');
INSERT INTO `tratamiento` VALUES (203, 'Procedimiento Obturacion en  resinas (una superficie)', '12000');
INSERT INTO `tratamiento` VALUES (204, 'Procedimiento obturacion en resinas (dos o mas superficies)', '15000');
INSERT INTO `tratamiento` VALUES (205, 'Procedimiento lonómero de vidrio Vitremer adulto (base cavitaria Muñón, Obturacion definitiva, etc.)', '10000');
INSERT INTO `tratamiento` VALUES (206, 'lonomero Cementante (porcion)', '3500');
INSERT INTO `tratamiento` VALUES (207, 'Lonomero Reconstructor', '15000');
INSERT INTO `tratamiento` VALUES (208, 'Sellantes porcion (incluido eyector, tela de caucho, etc)', '4300');
INSERT INTO `tratamiento` VALUES (209, 'Resina Fluida', '7300');
INSERT INTO `tratamiento` VALUES (210, 'Cementacion Duall', '12000');
INSERT INTO `tratamiento` VALUES (301, 'Godiva para sellado periferico', '1700');
INSERT INTO `tratamiento` VALUES (302, 'Pasta Zinquenólica C/impresión', '10000');
INSERT INTO `tratamiento` VALUES (303, 'Pasta Zinquenólica C/Pro porcion apra  rebasar', '3700');
INSERT INTO `tratamiento` VALUES (304, 'Silicona pesada y liviana por porcion', '17200');
INSERT INTO `tratamiento` VALUES (305, 'Silicona masilla porcion', '11600');
INSERT INTO `tratamiento` VALUES (306, 'Silicona liviana porcion', '8000');
INSERT INTO `tratamiento` VALUES (307, 'Vitrebond', '7200');
INSERT INTO `tratamiento` VALUES (308, 'Duralay y Muñon molar, premolar, central, etc. Porcion', '1300');
INSERT INTO `tratamiento` VALUES (309, 'Temblond cemento provisional, porcion', '700');
INSERT INTO `tratamiento` VALUES (310, 'Hidróxido de Ca. Pasta cementante provisional (porcion)', '700');
INSERT INTO `tratamiento` VALUES (311, 'Ionomero de Auto Vitremer, cementante definitivo (porcion adicional)', '1300');
INSERT INTO `tratamiento` VALUES (312, 'Fosfato de Zinc, Cemento Smith Polvo liquido (porcion)', '700');
INSERT INTO `tratamiento` VALUES (313, 'Lamina de Cera', '300');
INSERT INTO `tratamiento` VALUES (314, 'Alambre de Ortodoncia No. 6, 7, 8 cada pie', '750');
INSERT INTO `tratamiento` VALUES (315, 'Porcion de conos', '1900');
INSERT INTO `tratamiento` VALUES (316, 'Tela de Caucho', '750');
INSERT INTO `tratamiento` VALUES (317, 'Acrilico Jet Provisionales, colores N° Porcion polvo, liquido', '1200');
INSERT INTO `tratamiento` VALUES (318, 'Cemento Dual porcion', '4800');
INSERT INTO `tratamiento` VALUES (401, 'Exodincia sin incluir Rx periapical', '7000');
INSERT INTO `tratamiento` VALUES (402, 'Exodincia incluida Rx periapical', '8000');
INSERT INTO `tratamiento` VALUES (403, 'Cirugia oral programada pregrado', '27000');
INSERT INTO `tratamiento` VALUES (404, 'Cirugia oral programada postgrado sin historia clinica', '60000');
INSERT INTO `tratamiento` VALUES (405, 'Exodoncia en niños', '8500');
INSERT INTO `tratamiento` VALUES (501, 'Pulpectomía C/R', '8500');
INSERT INTO `tratamiento` VALUES (502, 'Pulpotomía C/R', '6000');
INSERT INTO `tratamiento` VALUES (503, 'Recubrimiento Pulpar (pediatría)', '6100');
INSERT INTO `tratamiento` VALUES (504, 'Endodoncia Monorradicular C/Rx', '17000');
INSERT INTO `tratamiento` VALUES (505, 'Endodoncia Birradicular C/Rx', '19000');
INSERT INTO `tratamiento` VALUES (506, 'Endodoncia Multirradicular C/Rx', '30000');
INSERT INTO `tratamiento` VALUES (507, 'Retratamiento Desobturacion y tratamiento de conducto', '20000');
INSERT INTO `tratamiento` VALUES (508, 'Retratamiento Desobturacion y tratamiento de conducto en diente birradicular', '20000');
INSERT INTO `tratamiento` VALUES (509, 'Endodoncia Monorradicular C/Rx Especializada', '40000');
INSERT INTO `tratamiento` VALUES (510, 'Endodoncia Birradicular C/Rx Especializada', '45000');
INSERT INTO `tratamiento` VALUES (511, 'Endodoncia Multirradicular C/Rx Especializada', '65000');
INSERT INTO `tratamiento` VALUES (512, 'Anestesico adicional', '500');
INSERT INTO `tratamiento` VALUES (513, 'Aguja adicional', '200');
INSERT INTO `tratamiento` VALUES (601, 'Periodoncia, fase higienica y motivacion', '6000');
INSERT INTO `tratamiento` VALUES (602, 'uso de ultrasonido', '5500');
INSERT INTO `tratamiento` VALUES (701, 'Mantenedores de espacio (fijo, removible, boton de Nance)', '14000');
INSERT INTO `tratamiento` VALUES (702, 'Materiales para Placa de Hawley', '14000');
INSERT INTO `tratamiento` VALUES (703, 'Materiales para Placa con tornillo de expansion, superior e inferior cada uno', '24000');
INSERT INTO `tratamiento` VALUES (704, 'Mentonera', '20000');
INSERT INTO `tratamiento` VALUES (705, 'Bandas metalicas cada una', '6000');
INSERT INTO `tratamiento` VALUES (706, 'Tubos juego (2 unidades)', '7000');
INSERT INTO `tratamiento` VALUES (707, 'Materiales para placa con tornillo triple', '35000');
INSERT INTO `tratamiento` VALUES (708, 'Materiales para placa con tornillo Hyrax', '47000');
INSERT INTO `tratamiento` VALUES (709, 'Materiales para placa Obturatriz incluye material de impresión', '14000');
INSERT INTO `tratamiento` VALUES (710, 'Materiales para Aparato Ortopedico y funcionales', '23200');
INSERT INTO `tratamiento` VALUES (711, 'Con tornillo Disyuntor', '41700');
INSERT INTO `tratamiento` VALUES (712, 'Alginato Superior e Inferior, Modelo para Aparatologia de Ortodoncia', '1200');
INSERT INTO `tratamiento` VALUES (801, 'Primera fase quirúrgica (1 Implante)', '150000');
INSERT INTO `tratamiento` VALUES (802, 'Primera fase quirúrgica (2 - 3 Implantes)', '200000');
INSERT INTO `tratamiento` VALUES (803, 'Primera fase quirúrgica (4 o mas Implantes)', '250000');
INSERT INTO `tratamiento` VALUES (804, 'Segunda fase quirúrgica (1 Pilar)', '100000');
INSERT INTO `tratamiento` VALUES (805, 'Segunda fase quirúrgica (2 - 3 Pilares)', '130000');
INSERT INTO `tratamiento` VALUES (806, 'Segunda fase quirúrgica (4 o mas  Pilares)', '180000');
INSERT INTO `tratamiento` VALUES (807, 'Cirugia de Regeneracion ósea (sin material)', '100000');
INSERT INTO `tratamiento` VALUES (901, 'Historia Clinica', '35000');
INSERT INTO `tratamiento` VALUES (902, 'Estudios de modelos superior e inferior', '15000');
INSERT INTO `tratamiento` VALUES (903, 'Control de Placa', '9000');
INSERT INTO `tratamiento` VALUES (904, 'Topicacion Fluor', '12000');
INSERT INTO `tratamiento` VALUES (905, 'Sellantes por cuadrante', '16000');
INSERT INTO `tratamiento` VALUES (906, 'Sellante por diente', '4500');
INSERT INTO `tratamiento` VALUES (907, 'Pulpectomia (temp)', '22000');
INSERT INTO `tratamiento` VALUES (908, 'Resina ', '15000');
INSERT INTO `tratamiento` VALUES (909, 'Resina Adicional', '6000');
INSERT INTO `tratamiento` VALUES (910, 'Ionomero', '12000');
INSERT INTO `tratamiento` VALUES (911, 'Urgencia', '18000');
INSERT INTO `tratamiento` VALUES (912, 'Terapia fluor con fluor de estaño', '15000');
INSERT INTO `tratamiento` VALUES (913, 'Exodoncia temporal', '10000');
INSERT INTO `tratamiento` VALUES (914, 'Corona acero', '42000');
INSERT INTO `tratamiento` VALUES (915, 'Formas platicas', '26000');
INSERT INTO `tratamiento` VALUES (916, 'Mantenedor de espacio fijo por 2', '100000');
INSERT INTO `tratamiento` VALUES (917, 'Placas activas superior e inferior', '180000');
INSERT INTO `tratamiento` VALUES (918, 'Protesis total', '80000');
INSERT INTO `tratamiento` VALUES (919, 'Cirugia', '65000');
INSERT INTO `tratamiento` VALUES (920, 'Topicacion con fluoruro acidulado', '12000');
INSERT INTO `tratamiento` VALUES (921, 'Tratamiento barniz fluor', '20000');
INSERT INTO `tratamiento` VALUES (1001, 'Yeso comun, superior e inferior cada uno', '1000');
INSERT INTO `tratamiento` VALUES (1002, 'Yeso extraduro c/imp', '2300');
INSERT INTO `tratamiento` VALUES (1003, 'Yeso tipo III C/u impresión - porcion', '1200');
INSERT INTO `tratamiento` VALUES (1004, 'Yeso tipo IV C/u impresión - porcion', '2300');
INSERT INTO `tratamiento` VALUES (1005, 'Porcion de Acrilico autopolimerizante polvo', '1200');
INSERT INTO `tratamiento` VALUES (1006, 'Porcion de Acrilico autopolimerizante liquido', '1200');
INSERT INTO `tratamiento` VALUES (1007, 'Porcion de Acrilico termocurado liquido', '3500');
INSERT INTO `tratamiento` VALUES (1008, 'Porcion de Acrilico termocurado polvo', '3500');
INSERT INTO `tratamiento` VALUES (1009, 'Lamina de Cera rosada', '300');
INSERT INTO `tratamiento` VALUES (1101, 'Historia clinica + Rx periapical', '20000');
INSERT INTO `tratamiento` VALUES (1102, 'Endodoncia molares', '65000');
INSERT INTO `tratamiento` VALUES (1103, 'Endodoncia premolares', '45000');
INSERT INTO `tratamiento` VALUES (1104, 'Endodoncia incisivos', '40000');
INSERT INTO `tratamiento` VALUES (1105, 'Urgencia', '25000');
INSERT INTO `tratamiento` VALUES (1106, 'Cirugia apical', '60000');
INSERT INTO `tratamiento` VALUES (1107, 'Ferulizacion en trauma dentoalveolar', '35000');
INSERT INTO `tratamiento` VALUES (1108, 'Apicoformacion por cita', '25000');
INSERT INTO `tratamiento` VALUES (1109, 'Blanqueamiento interno por cita', '20000');
INSERT INTO `tratamiento` VALUES (1110, 'Capsula de Amalgama', '1000');
INSERT INTO `tratamiento` VALUES (1111, 'Porcion de Conos gutapercha', '1400');
INSERT INTO `tratamiento` VALUES (1112, 'Cemento de grosman', '600');
INSERT INTO `tratamiento` VALUES (1113, 'Rx periapical', '1000');
INSERT INTO `tratamiento` VALUES (1201, 'Tratamiento Ortodoncia', '995000');
INSERT INTO `tratamiento` VALUES (1202, 'Tratamiento Ortodoncia (sin incluir aparatologia)', '440000');
INSERT INTO `tratamiento` VALUES (1203, 'Tratamiento Ortodoncia (Brackets autoligado)', '1500000');
INSERT INTO `tratamiento` VALUES (1204, 'Tratamiento Fisurado ', '50000');
INSERT INTO `tratamiento` VALUES (1301, 'Historia Clinica C/Rx', '35000');
INSERT INTO `tratamiento` VALUES (1302, 'Historia Clinica S/Rx', '15000');
INSERT INTO `tratamiento` VALUES (2001, 'NEUROLOGIA TRIGEMINAL POR SESION', '40000');
INSERT INTO `tratamiento` VALUES (2002, 'TRASTORNOS DE ATM POR SESION', '40000');
INSERT INTO `tratamiento` VALUES (2003, 'PARALISIS FACIAL POR SESION', '40000');
INSERT INTO `tratamiento` VALUES (2004, 'DOLORES DE CUELLO, CABEZA, ESPALDA POR SESION', '40000');
INSERT INTO `tratamiento` VALUES (2005, 'HERPES ZOSTER O STOMATITIS AFTOSA POR AFTAS MAYORES POR SESION', '40000');
INSERT INTO `tratamiento` VALUES (2101, 'TRATAMIENTO COMPLETO HIPERSENSIBILIDAD DENTINARIA (HASTA 3 ORGANOS DENTARIOS) POR 3 SESIONES', '40000');
INSERT INTO `tratamiento` VALUES (2102, 'TRATAMIENTO COMPLETO DE HERPES SIMPLE POR 4 SESIONES', '60000');
INSERT INTO `tratamiento` VALUES (2103, 'TRATAMIENTO COMPLETO POR AFTAS POR 4 SESIONES', '60000');
